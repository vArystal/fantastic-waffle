import { describe, expect, it } from "vitest";
import {
  clamp,
  formatCount,
  formatDuration,
  formatFull,
  formatRelative,
  formatUptime,
  initials,
  percent,
} from "../src/lib/utils";

describe("formatCount", () => {
  it("keeps small numbers intact", () => {
    expect(formatCount(0)).toBe("0");
    expect(formatCount(842)).toBe("842");
  });

  it("compacts thousands and millions", () => {
    expect(formatCount(9_400)).toBe("9.4K");
    expect(formatCount(24_837)).toBe("25K");
    expect(formatCount(412_800)).toBe("413K");
    expect(formatCount(3_140_000)).toBe("3.1M");
  });

  it("never renders NaN to the viewer", () => {
    expect(formatCount(Number.NaN)).toBe("—");
    expect(formatCount(-4)).toBe("—");
  });
});

describe("formatDuration", () => {
  it("formats under an hour without an hour segment", () => {
    expect(formatDuration(0)).toBe("0:00");
    expect(formatDuration(5)).toBe("0:05");
    expect(formatDuration(125)).toBe("2:05");
  });

  it("formats hours with zero padding", () => {
    expect(formatDuration(3_725)).toBe("1:02:05");
  });

  it("clamps invalid input", () => {
    expect(formatDuration(-10)).toBe("0:00");
    expect(formatDuration(Number.POSITIVE_INFINITY)).toBe("0:00");
  });
});

describe("formatRelative", () => {
  const now = new Date("2026-10-27T12:00:00Z").getTime();

  it("describes the past", () => {
    expect(formatRelative(new Date(now - 5_000).toISOString(), now)).toBe("just now");
    expect(formatRelative(new Date(now - 300_000).toISOString(), now)).toBe("5m ago");
    expect(formatRelative(new Date(now - 7_200_000).toISOString(), now)).toBe("2h ago");
  });

  it("describes future timestamps (poll and prediction deadlines)", () => {
    expect(formatRelative(new Date(now + 240_000).toISOString(), now)).toBe("in 4m");
    expect(formatRelative(new Date(now + 7_200_000).toISOString(), now)).toBe("in 2h");
  });
});

describe("formatUptime / formatFull", () => {
  it("measures stream duration from startedAt", () => {
    const start = new Date("2026-10-27T10:00:00Z").toISOString();
    const now = new Date("2026-10-27T12:02:05Z").getTime();
    expect(formatUptime(start, now)).toBe("2:02:05");
    expect(formatUptime(null)).toBe("0:00");
  });

  it("groups large numbers for detail views", () => {
    expect(formatFull(412_800)).toBe("412,800");
  });
});

describe("helpers", () => {
  it("clamps and computes percentages defensively", () => {
    expect(clamp(5, 0, 3)).toBe(3);
    expect(clamp(-1, 0, 3)).toBe(0);
    expect(percent(1, 0)).toBe(0);
    expect(percent(1, 4)).toBe(25);
    expect(percent(9, 4)).toBe(100);
  });

  it("derives avatar initials", () => {
    // single-token handles collapse to one glyph; spaced names take two
    expect(initials("v0lt")).toBe("V");
    expect(initials("kirin.exe")).toBe("K");
    expect(initials("Shadow Reaper")).toBe("SR");
    expect(initials("")).toBe("");
  });
});
