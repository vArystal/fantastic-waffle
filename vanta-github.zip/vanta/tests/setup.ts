import "@testing-library/jest-dom/vitest";
import { afterEach, beforeEach, vi } from "vitest";
import { cleanup } from "@testing-library/react";
import { __resetDemoState } from "../src/api/mockApi";

afterEach(() => {
  cleanup();
});

beforeEach(() => {
  localStorage.clear();
  // the demo store keeps module-level state; reset it to defaults each test
  localStorage.setItem(
    "vanta.demo.v1",
    JSON.stringify({ network: "fast", persona: "subscriber", forcedStreamState: "auto", chatOffline: false }),
  );
  vi.useRealTimers();
  __resetDemoState();
});

// jsdom has no media playback implementation
Object.defineProperty(HTMLMediaElement.prototype, "play", {
  configurable: true,
  value: vi.fn().mockResolvedValue(undefined),
});
Object.defineProperty(HTMLMediaElement.prototype, "pause", {
  configurable: true,
  value: vi.fn(),
});
Object.defineProperty(HTMLMediaElement.prototype, "load", {
  configurable: true,
  value: vi.fn(),
});
