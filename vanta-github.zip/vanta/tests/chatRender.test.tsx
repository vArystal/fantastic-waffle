import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ChatMessageRow } from "../src/components/chat/ChatMessageRow";
import { PlayerProvider, usePlayer } from "../src/components/player/PlayerContext";
import type { ChatMessage, Emote, Stream, User } from "../src/types";
import { streamBySlug } from "../src/api/seed";

const emotes = new Map<string, Emote>([
  ["gg", { id: "e1", code: "gg", url: "/media/emotes/gg.png", subscriberOnly: false }],
]);

const author: User = {
  id: "u1",
  login: "shadez",
  displayName: "shadez",
  avatarUrl: null,
  color: "#f04452",
  roles: ["viewer"],
  verified: false,
};

const makeMessage = (overrides: Partial<ChatMessage> = {}): ChatMessage => ({
  id: "m1",
  streamId: "st_v0lt",
  author,
  kind: "chat",
  text: "hello world",
  createdAt: new Date().toISOString(),
  badges: [],
  replyTo: null,
  emotes: [],
  mentions: [],
  isPinned: false,
  canDelete: false,
  deletedBy: null,
  ...overrides,
});

const handlers = {
  canModerate: false,
  onDelete: vi.fn(),
  onTimeout: vi.fn(),
  onBan: vi.fn(),
  onPin: vi.fn(),
  onReply: vi.fn(),
  onReport: vi.fn(),
  onRetry: vi.fn(),
  onDismiss: vi.fn(),
  onOpenProfile: vi.fn(),
};

describe("ChatMessageRow", () => {
  it("renders user content as text, never as HTML", () => {
    const payload = '<img src=x onerror="window.__xss=1"><script>alert(1)</script>';
    const { container } = render(
      <ChatMessageRow message={makeMessage({ text: payload })} emotes={emotes} handlers={handlers} selfId={null} />,
    );
    expect(container.querySelector("script")).toBeNull();
    expect(container.querySelector('img[src="x"]')).toBeNull();
    expect(screen.getByText(/onerror/)).toBeInTheDocument();
    expect((window as unknown as { __xss?: number }).__xss).toBeUndefined();
  });

  it("resolves emotes into images and mentions into buttons", () => {
    const { container } = render(
      <ChatMessageRow
        message={makeMessage({
          text: "nice :gg: @miko",
          emotes: ["gg"],
          mentions: [{ login: "miko", displayName: "miko" }],
        })}
        emotes={emotes}
        handlers={handlers}
        selfId={null}
      />,
    );
    expect(container.querySelector(".chat-emote")).toBeTruthy();
    expect(screen.getByRole("button", { name: "@miko" })).toBeInTheDocument();
  });

  it("shows role badges with an accessible label", () => {
    render(
      <ChatMessageRow
        message={makeMessage({ badges: [{ kind: "moderator" }, { kind: "subscriber", label: "14m" }] })}
        emotes={emotes}
        handlers={handlers}
        selfId={null}
      />,
    );
    expect(screen.getByLabelText("Moderator")).toBeInTheDocument();
    expect(screen.getByLabelText("Subscriber · 14m")).toBeInTheDocument();
  });

  it("renders removed messages as a tombstone, not a hole", () => {
    render(
      <ChatMessageRow
        message={makeMessage({ deletedBy: "kirin.exe" })}
        emotes={emotes}
        handlers={handlers}
        selfId={null}
      />,
    );
    expect(screen.getByText(/Message removed by kirin.exe/)).toBeInTheDocument();
  });

  it("offers moderation actions only when the viewer may moderate", () => {
    const { rerender } = render(
      <ChatMessageRow message={makeMessage()} emotes={emotes} handlers={handlers} selfId={null} />,
    );
    expect(screen.queryByRole("group", { name: "Moderation actions" })).toBeNull();

    rerender(
      <ChatMessageRow
        message={makeMessage()}
        emotes={emotes}
        handlers={{ ...handlers, canModerate: true }}
        selfId={null}
      />,
    );
    expect(screen.getByRole("group", { name: "Moderation actions" })).toBeInTheDocument();
  });

  it("surfaces a failed send with its server reason and a retry", async () => {
    const onRetry = vi.fn();
    render(
      <ChatMessageRow
        message={makeMessage({ deliveryState: "failed", failureReason: "Slow mode is on: wait 3s between messages." })}
        emotes={emotes}
        handlers={{ ...handlers, canModerate: true, onRetry }}
        selfId="u1"
      />,
    );
    expect(screen.getByText(/Slow mode is on/)).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: /Retry/i }));
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it("renders system and moderation notices distinctly", () => {
    render(
      <ChatMessageRow
        message={makeMessage({ kind: "moderation", author: null, text: "kirin.exe timed out @brk for 600s" })}
        emotes={emotes}
        handlers={handlers}
        selfId={null}
      />,
    );
    expect(screen.getByRole("note")).toHaveTextContent("timed out @brk");
  });
});

/* -------------------------------------------------------------------------- */
/* player defaults                                                            */
/* -------------------------------------------------------------------------- */

function PlayerProbe() {
  const state = usePlayer();
  return (
    <div>
      <span data-testid="muted">{String(state.muted)}</span>
      <span data-testid="phase">{state.phase}</span>
      <span data-testid="captions">{String(state.captionsEnabled)}</span>
      <span data-testid="quality">{state.qualityId}</span>
    </div>
  );
}

describe("PlayerProvider", () => {
  const live = streamBySlug("v0lt") as Stream;
  const offline = streamBySlug("n0va") as Stream;

  it("starts muted so audio never autoplays", () => {
    render(
      <PlayerProvider stream={live}>
        <PlayerProbe />
      </PlayerProvider>,
    );
    expect(screen.getByTestId("muted")).toHaveTextContent("true");
  });

  it("does not enter a playing phase for an offline stream", () => {
    render(
      <PlayerProvider stream={offline}>
        <PlayerProbe />
      </PlayerProvider>,
    );
    expect(screen.getByTestId("phase")).toHaveTextContent("idle");
  });

  it("selects the highest rendition by default and keeps captions off", () => {
    render(
      <PlayerProvider stream={live}>
        <PlayerProbe />
      </PlayerProvider>,
    );
    expect(screen.getByTestId("quality")).toHaveTextContent("r720");
    expect(screen.getByTestId("captions")).toHaveTextContent("false");
  });
});
