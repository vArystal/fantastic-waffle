import { beforeEach, describe, expect, it } from "vitest";
import { api } from "../src/api/mockApi";
import { demoStore } from "../src/api/demo";
import { ApiError } from "../src/types";

/**
 * These tests target the security-critical behaviour: permissions, validation,
 * idempotency and rate limiting. They must pass against the real backend too —
 * the mock exists to make that contract executable.
 */
const asPersona = (persona: "guest" | "viewer" | "subscriber" | "moderator" | "streamer") =>
  demoStore.set({ persona, network: "fast" });

const expectApiError = async (promise: Promise<unknown>, code: string) => {
  await expect(promise).rejects.toBeInstanceOf(ApiError);
  await promise.catch((err: ApiError) => expect(err.code).toBe(code));
};

beforeEach(() => {
  asPersona("subscriber");
});

describe("session", () => {
  it("returns the signed-in user and permissions", async () => {
    asPersona("subscriber");
    const session = await api.getSession();
    expect(session.user?.roles).toContain("subscriber");
    expect(session.canGoLive).toBe(false);
  });

  it("returns no user for guests", async () => {
    asPersona("guest");
    const session = await api.getSession();
    expect(session.user).toBeNull();
  });

  it("only grants canGoLive to the broadcaster", async () => {
    asPersona("streamer");
    expect((await api.getSession()).canGoLive).toBe(true);
    asPersona("moderator");
    expect((await api.getSession()).canGoLive).toBe(false);
  });
});

describe("follow", () => {
  it("requires authentication", async () => {
    asPersona("guest");
    await expectApiError(api.setFollow("ch_v0lt", true), "unauthenticated");
  });

  it("rejects a duplicate follow instead of double counting", async () => {
    // ch_v0lt starts followed in the seeded state
    await expectApiError(api.setFollow("ch_v0lt", true), "conflict");
  });

  it("follows and unfollows with a consistent follower count", async () => {
    const before = await api.getChannel("miko");
    expect(before.viewerIsFollowing).toBe(false);

    const followed = await api.setFollow("ch_miko", true);
    expect(followed.following).toBe(true);
    expect(followed.followerCount).toBe(before.followerCount + 1);

    const after = await api.getChannel("miko");
    expect(after.viewerIsFollowing).toBe(true);

    const unfollowed = await api.setFollow("ch_miko", false);
    expect(unfollowed.followerCount).toBe(before.followerCount);
  });

  it("rejects unknown channels", async () => {
    await expectApiError(api.setFollow("ch_nope", true), "not_found");
  });

  it("requires a follow before notification preferences can change", async () => {
    await expectApiError(api.setFollowAlerts("ch_miko", "none"), "validation_failed");
  });
});

describe("chat sending", () => {
  it("requires authentication", async () => {
    asPersona("guest");
    await expectApiError(api.sendMessage("st_v0lt", "hello"), "unauthenticated");
  });

  it("rejects empty and oversized messages", async () => {
    asPersona("moderator");
    await expectApiError(api.sendMessage("st_v0lt", "   "), "validation_failed");
    await expectApiError(api.sendMessage("st_v0lt", "x".repeat(501)), "validation_failed");
  });

  it("blocks links and banned terms server-side", async () => {
    asPersona("moderator");
    await expectApiError(api.sendMessage("st_v0lt", "visit https://spam.example"), "validation_failed");
    await expectApiError(api.sendMessage("st_v0lt", "free-followers now"), "validation_failed");
  });

  it("rejects a message that repeats the previous one", async () => {
    asPersona("moderator");
    const text = `duplicate probe ${Date.now()}`;
    await api.sendMessage("st_v0lt", text);
    // wait past the minimum send interval so the duplicate detector, not the
    // flood limiter, is what rejects the second message
    await new Promise((r) => setTimeout(r, 750));
    await expectApiError(api.sendMessage("st_v0lt", text), "conflict");
  });

  it("enforces slow mode for regular viewers", async () => {
    asPersona("viewer");
    await expect(api.sendMessage("st_v0lt", `viewer one ${Date.now()}`)).resolves.toBeTruthy();
    // the channel runs a 3s slow mode; a second send inside that window fails
    await expectApiError(api.sendMessage("st_v0lt", `viewer two ${Date.now()}`), "rate_limited");
  });

  it("moderators bypass slow mode", async () => {
    asPersona("moderator");
    const a = await api.sendMessage("st_v0lt", `mod one ${Date.now()}`);
    expect(a.id).toBeTruthy();
    await new Promise((r) => setTimeout(r, 750));
    const b = await api.sendMessage("st_v0lt", `mod two ${Date.now()}`);
    expect(b.id).toBeTruthy();
  });
});

describe("moderation permissions", () => {
  it("a viewer cannot delete someone else's message", async () => {
    const page = await api.getChatHistory("st_v0lt");
    const foreign = page.messages.find((m) => m.author && m.kind === "chat");
    expect(foreign).toBeTruthy();
    asPersona("viewer");
    await expectApiError(api.deleteMessage("st_v0lt", foreign!.id), "forbidden");
  });

  it("a viewer cannot clear chat, pin, timeout or ban", async () => {
    asPersona("viewer");
    await expectApiError(api.clearChat("st_v0lt"), "forbidden");
    await expectApiError(api.pinMessage("st_v0lt", "msg_1"), "forbidden");
    await expectApiError(api.timeoutUser("st_v0lt", "usr_miko", 60), "forbidden");
    await expectApiError(api.banUser("st_v0lt", "usr_miko"), "forbidden");
  });

  it("a moderator can time out a viewer but not a peer", async () => {
    asPersona("moderator");
    await expect(api.timeoutUser("st_v0lt", "usr_miko", 600, "test")).resolves.toBeUndefined();
    await expectApiError(api.timeoutUser("st_v0lt", "usr_kirin", 600), "forbidden");
    await expectApiError(api.timeoutUser("st_v0lt", "usr_v0lt", 600), "forbidden");
  });

  it("validates timeout durations", async () => {
    asPersona("moderator");
    await expectApiError(api.timeoutUser("st_v0lt", "usr_miko", 0), "validation_failed");
    await expectApiError(api.timeoutUser("st_v0lt", "usr_miko", 99_999_999), "validation_failed");
  });

  it("only the broadcaster can close or create polls", async () => {
    const poll = await api.getPoll("st_v0lt");
    asPersona("moderator");
    await expectApiError(api.closePoll(poll.id), "forbidden");
    await expectApiError(api.createPoll("st_v0lt", "Next?", ["a", "b"]), "forbidden");
    asPersona("streamer");
    await expect(api.createPoll("st_v0lt", "Next game?", ["ranked", "customs"])).resolves.toBeTruthy();
  });
});

describe("polls", () => {
  it("records a single vote and rejects duplicates", async () => {
    const poll = await api.getPoll("st_v0lt");
    const option = poll.options[0];
    const voted = await api.votePoll(poll.id, option.id);
    expect(voted.viewerVote).toBe(option.id);
    expect(voted.totalVotes).toBe(poll.totalVotes + 1);
    await expectApiError(api.votePoll(poll.id, poll.options[1].id), "conflict");
  });

  it("rejects unknown options", async () => {
    const poll = await api.getPoll("st_v0lt");
    await expectApiError(api.votePoll(poll.id, "po_missing"), "validation_failed");
  });

  it("requires authentication to vote", async () => {
    const poll = await api.getPoll("st_v0lt");
    asPersona("guest");
    await expectApiError(api.votePoll(poll.id, poll.options[0].id), "unauthenticated");
  });
});

describe("widgets that need missing services", () => {
  it("prediction entries are unsupported rather than faked", async () => {
    const prediction = await api.getPrediction("st_v0lt");
    expect(prediction.spendEnabled).toBe(false);
    await expectApiError(api.enterPrediction(prediction.id, prediction.outcomes[0].id), "unsupported");
  });

  it("reward redemption is unsupported rather than faked", async () => {
    const rewards = await api.getRewards("st_v0lt");
    expect(rewards.redemptionEnabled).toBe(false);
    await expectApiError(api.redeemReward(rewards.rewards[0].id), "unsupported");
  });

  it("hides non-public goals and respects leaderboard opt-out", async () => {
    const goals = await api.getGoals("st_v0lt");
    expect(goals.every((g) => g.visibility === "public")).toBe(true);

    const visible = await api.getLeaderboard("st_v0lt");
    expect(visible.entries.some((e) => e.isSelf)).toBe(true);

    const hidden = await api.setLeaderboardOptOut(true);
    expect(hidden.viewerOptedOut).toBe(true);
    expect(hidden.entries.some((e) => e.isSelf)).toBe(false);
  });
});

describe("clips", () => {
  it("rejects clips on streams without DVR", async () => {
    const vodStream = await api.getStreamBySlug("kirin");
    expect(vodStream.playback).toBeNull();
    await expectApiError(
      api.createClip({ streamId: vodStream.id, startSeconds: 0, endSeconds: 20, title: "test clip" }),
      "unsupported",
    );
  });

  it("validates clip length and title", async () => {
    await expectApiError(
      api.createClip({ streamId: "st_v0lt", startSeconds: 0, endSeconds: 2, title: "short" }),
      "validation_failed",
    );
    await expectApiError(
      api.createClip({ streamId: "st_v0lt", startSeconds: 0, endSeconds: 20, title: "no" }),
      "validation_failed",
    );
  });

  it("creates a clip for a valid request", async () => {
    const clip = await api.createClip({ streamId: "st_v0lt", startSeconds: 0, endSeconds: 25, title: "great hold" });
    expect(clip.title).toBe("great hold");
    expect(clip.durationSeconds).toBe(25);
  });
});

describe("stream projection", () => {
  it("drops playback for non-playable states", async () => {
    demoStore.set({ forcedStreamState: "offline" });
    const stream = await api.getStreamBySlug("v0lt");
    expect(stream.state).toBe("offline");
    expect(stream.playback).toBeNull();
    demoStore.set({ forcedStreamState: "auto" });
  });

  it("reports unknown channels as not found", async () => {
    await expectApiError(api.getStreamBySlug("does-not-exist"), "not_found");
  });

  it("exposes real renditions and caption tracks", async () => {
    const stream = await api.getStreamBySlug("v0lt");
    expect(stream.playback?.renditions).toHaveLength(3);
    expect(stream.playback?.renditions.map((r) => r.label)).toEqual(["720p", "480p", "360p"]);
    expect(stream.playback?.captions[0]?.src).toContain(".vtt");
    expect(stream.playback?.dvr.enabled).toBe(true);
  });
});

describe("network profiles surface the documented error codes", () => {
  it("offline rejects with a network error", async () => {
    demoStore.set({ network: "offline" });
    await expectApiError(api.getStreamBySlug("v0lt"), "network");
    demoStore.set({ network: "fast" });
  });
});
