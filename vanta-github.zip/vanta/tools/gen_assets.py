#!/usr/bin/env python3
"""
VANTA demo asset generator.

Produces deterministic, licence-free media used by the demo dataset so that the
UI has *real* video files, *real* renditions, *real* audio and *real* captions
without any network dependency (the sandboxed preview has no network access).

Outputs (relative to public/media):
  demo/stream-720.mp4   1280x720 @30fps source rendition
  demo/stream-480.mp4    854x480 rendition
  demo/stream-360.mp4    640x360 rendition
  demo/poster.jpg        poster frame
  demo/stream.en.vtt     WebVTT captions for the bundled ambient track
  thumbs/*.jpg           16:9 channel / clip thumbnails
  avatars/*.jpg          channel avatars
  categories/*.jpg       category art
  emotes/*.png           transparent emote glyphs (140x140)

The three renditions are genuine separate encodes of the same source, so the
player's quality selector performs real source switching rather than faking it.
"""
import math
import os
import random
import subprocess
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from imageio_ffmpeg import get_ffmpeg_exe

FFMPEG = get_ffmpeg_exe()
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "public", "media")

W, H = 1280, 720
SS = 1.5  # supersample factor
RW, RH = int(W * SS), int(H * SS)
FPS = 30
DURATION = 26.0
NFRAMES = int(FPS * DURATION)

VIOLET = (139, 124, 255)
TEAL = (70, 224, 192)
RED = (240, 68, 82)
AMBER = (255, 180, 87)
INK = (7, 8, 12)

FONT_BOLD = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
FONT_REG = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"


def font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def ease(t):
    return t * t * (3 - 2 * t)


# --------------------------------------------------------------------------- #
# Gameplay scene
# --------------------------------------------------------------------------- #
def project(x, y, z, horizon=RH * 0.42):
    """Miniature pseudo-3D projection for the arena floor and its actors."""
    k = 1.0 / (0.60 + 0.80 * z)
    return (RW / 2 + x * RW * 0.5 * k, horizon + y * RH * 0.9 * k)


class Entity:
    def __init__(self, x, y, color, radius, phase, speed, kind="enemy"):
        self.x, self.y = x, y
        self.color = color
        self.radius = radius
        self.phase = phase
        self.speed = speed
        self.kind = kind
        self.hp = 100.0

    def at(self, t):
        # Lissajous wander, deterministic per-entity
        x = self.x + math.sin(t * self.speed + self.phase) * 0.29
        y = self.y + math.cos(t * self.speed * 0.77 + self.phase * 1.7) * 0.17
        return clamp(x, -0.72, 0.72), clamp(y, -0.4, 0.4)


_MASK_CACHE = {}


def _static_masks():
    if _MASK_CACHE:
        return _MASK_CACHE
    yy, xx = np.mgrid[0:RH, 0:RW]
    nx = (xx - RW / 2) / (RW / 2)
    ny = (yy - RH / 2) / (RH / 2)
    vig = np.clip(1.06 - 0.42 * (nx ** 2 * 0.75 + ny ** 2 * 0.9), 0, 1.15)[..., None].astype(np.float32)
    scan = np.ones((RH, RW, 1), dtype=np.float32)
    scan[::3] = 0.90
    _MASK_CACHE["vig"] = vig
    _MASK_CACHE["scan"] = scan
    return _MASK_CACHE


def draw_frame(i):
    t = i / FPS
    img = Image.new("RGB", (RW, RH), INK)
    d = ImageDraw.Draw(img, "RGBA")

    # ---- sky / backdrop glow ------------------------------------------------
    for k in range(14):  # cheap vertical gradient
        v = k / 13.0
        y0 = int(RH * v * 0.55)
        y1 = int(RH * (v + 0.06) * 0.55)
        d.rectangle([0, y0, RW, y1 + 2],
                    fill=(int(11 + 14 * (1 - v)), int(12 + 10 * (1 - v)), int(20 + 26 * (1 - v))))

    # distant aurora band
    band_h = int(RH * 0.30)
    for y in range(band_h):
        v = y / band_h
        a = int(50 * math.sin(math.pi * v) ** 2)
        d.line([(0, y), (RW, y)], fill=(70, 60, 160, a))

    # ---- floor grid with perspective ---------------------------------------
    horizon = RH * 0.44
    horizon_wobble = math.sin(t * 0.35) * 6 * SS
    for gx in range(-14, 15):
        x0 = gx * 0.16
        p_near = project(x0, 1.0, 0.0, horizon)
        p_far = project(x0 * 0.2, 0.2, 8.0, horizon)
        d.line([p_far, p_near], fill=(104, 92, 214, 78), width=max(1, int(1 * SS)))
    for gz in range(0, 15):
        z = gz * 0.55
        y = 0.2 + z * 0.055
        p_l = project(-1.6, y, z, horizon)
        p_r = project(1.6, y, z, horizon)
        alpha = int(105 * max(0.0, 1 - z / 8.0))
        d.line([p_l, p_r], fill=(90, 80, 190, alpha), width=max(1, int(1 * SS)))

    # ---- central arena ring (rotating) -------------------------------------
    cx, cy = RW / 2, RH * 0.60
    ring_r = RH * 0.30
    spin = t * 0.5
    for layer, (rr, col, wd) in enumerate([
        (1.0, (*VIOLET, 90), 3),
        (0.86, (*TEAL, 55), 2),
        (0.60, (*VIOLET, 40), 2),
    ]):
        pts = []
        sides = 6 if layer != 1 else 24
        for s in range(sides + 1):
            a = spin * (1 if layer % 2 == 0 else -1.4) + s * 2 * math.pi / sides
            pts.append((cx + math.cos(a) * ring_r * rr, cy + math.sin(a) * ring_r * rr * 0.42))
        d.line(pts, fill=col, width=int(wd * SS))

    # pulsing rune ticks
    for s in range(12):
        a = -spin * 2 + s * math.pi / 6
        x1 = cx + math.cos(a) * ring_r * 1.02
        y1 = cy + math.sin(a) * ring_r * 1.02 * 0.42
        x2 = cx + math.cos(a) * ring_r * 1.10
        y2 = cy + math.sin(a) * ring_r * 1.10 * 0.42
        pulse = 0.4 + 0.6 * abs(math.sin(t * 2.2 + s))
        d.line([(x1, y1), (x2, y2)], fill=(*TEAL, int(150 * pulse)), width=int(2 * SS))

    # ---- entities -----------------------------------------------------------
    enemies = [
        Entity(-0.62, -0.26, RED, 21 * SS, 1.1, 0.9),
        Entity(0.66, -0.20, AMBER, 19 * SS, 2.7, 1.15),
        Entity(0.30, 0.30, RED, 23 * SS, 4.2, 0.7),
        Entity(-0.38, 0.24, VIOLET, 18 * SS, 5.6, 1.3),
        Entity(0.02, -0.34, RED, 30 * SS, 0.4, 0.55),
    ]

    def world_pt(ex, ey, z=1.2):
        return project(ex, ey + 0.16, z, horizon)

    hx, hy = 0.0, 0.02
    hxp, hyp = world_pt(hx, hy)

    # ground glow pool beneath the arena
    glow_pool = Image.new("RGBA", (RW, RH), (0, 0, 0, 0))
    gp = ImageDraw.Draw(glow_pool)
    gp.ellipse([RW / 2 - 330 * SS, cy - 70 * SS, RW / 2 + 330 * SS, cy + 150 * SS],
               fill=(70, 58, 150, 60))
    img = Image.alpha_composite(img.convert("RGBA"), glow_pool.filter(
        ImageFilter.GaussianBlur(40 * SS))).convert("RGB")
    d = ImageDraw.Draw(img, "RGBA")

    # ---- entities & combat ------------------------------------------------
    glows = Image.new("RGBA", (RW, RH), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glows)

    for idx, e in enumerate(enemies):
        ex, ey = e.at(t)
        exp, eyp = world_pt(ex, ey)

        # projectile chain hero -> enemy
        for v in range(3):
            phase = (t * 1.9 + idx * 0.21 + v * 0.33) % 1.0
            px = hxp + (exp - hxp) * phase
            py = hyp + (eyp - hyp) * phase - math.sin(phase * math.pi) * 34 * SS
            if phase < 0.92:
                gd.ellipse([px - 7 * SS, py - 7 * SS, px + 7 * SS, py + 7 * SS], fill=(*TEAL, 200))
                d.line([(px - 26 * SS, py + 6 * SS), (px, py)], fill=(*TEAL, 110), width=int(3 * SS))
            else:
                r = (phase - 0.92) * 190 * SS
                a = int(230 * (1 - (phase - .92) * 12.5))
                d.ellipse([px - r, py - r, px + r, py + r], outline=(*AMBER, max(a, 0)),
                          width=int(3 * SS))

        # ground shadow
        d.ellipse([exp - e.radius * 1.3, eyp + e.radius * 0.9,
                   exp + e.radius * 1.3, eyp + e.radius * 1.45], fill=(0, 0, 0, 95))
        # glow halo
        gd.ellipse([exp - e.radius * 2.1, eyp - e.radius * 2.1,
                    exp + e.radius * 2.1, eyp + e.radius * 2.1], fill=(*e.color, 78))
        # body
        d.ellipse([exp - e.radius, eyp - e.radius, exp + e.radius, eyp + e.radius],
                  fill=(*e.color, 240), outline=(255, 255, 255, 70), width=int(2 * SS))
        d.ellipse([exp - e.radius * 0.46, eyp - e.radius * 0.46,
                   exp + e.radius * 0.46, eyp + e.radius * 0.46], fill=(255, 255, 255, 220))
        # hp pip
        hpw = e.radius * 2.6
        d.rectangle([exp - hpw / 2, eyp - e.radius - 16 * SS, exp + hpw / 2, eyp - e.radius - 10 * SS],
                    fill=(0, 0, 0, 160))
        frac = 0.32 + 0.62 * abs(math.sin(t * 0.6 + e.phase))
        d.rectangle([exp - hpw / 2, eyp - e.radius - 16 * SS,
                     exp - hpw / 2 + hpw * frac, eyp - e.radius - 10 * SS], fill=(*RED, 235))

        # damage number, one per enemy, rising on its own cycle
        phase = (t * 1.15 + idx * 0.19) % 1.0
        y = eyp - e.radius - 26 * SS - phase * 74 * SS
        a = int(255 * (1 - phase) ** 1.6)
        val = int(120 + 44 * (idx + 1) + 38 * math.sin(t * 1.7 + idx))
        d.text((exp + e.radius * 0.9, y), f"{val}", font=font(FONT_BOLD, int(15 * SS)),
               fill=(255, 255, 255, a))

    # hero trail + body
    for k in range(10):
        tt = t - k * 0.032
        tx, ty = math.sin(tt * 0.6) * 0.22, math.cos(tt * 0.45) * 0.05 + 0.02
        px, py = world_pt(tx, ty)
        gd.ellipse([px - 26 * SS, py - 26 * SS, px + 26 * SS, py + 26 * SS],
                   fill=(*TEAL, int(42 * (1 - k / 10))))
    gd.ellipse([hxp - 66 * SS, hyp - 66 * SS, hxp + 66 * SS, hyp + 66 * SS], fill=(*TEAL, 90))

    img = Image.alpha_composite(img.convert("RGBA"), glows.filter(
        ImageFilter.GaussianBlur(13 * SS))).convert("RGB")
    d = ImageDraw.Draw(img, "RGBA")

    # hero sprite (drawn after glow composite for crispness)
    d.ellipse([hxp - 60 * SS, hyp + 58 * SS, hxp + 60 * SS, hyp + 84 * SS], fill=(0, 0, 0, 120))
    d.ellipse([hxp - 26 * SS, hyp - 26 * SS, hxp + 26 * SS, hyp + 26 * SS],
              fill=(*TEAL, 245), outline=(255, 255, 255, 120), width=int(2 * SS))
    d.ellipse([hxp - 11 * SS, hyp - 11 * SS, hxp + 11 * SS, hyp + 11 * SS], fill=(255, 255, 255, 240))
    # hero health ring
    arc = 0.62 + 0.12 * math.sin(t * 1.1)
    d.arc([hxp - 40 * SS, hyp - 40 * SS, hxp + 40 * SS, hyp + 40 * SS], start=-90,
          end=-90 + 360 * arc, fill=(*TEAL, 190), width=int(3 * SS))

    # ---- HUD ---------------------------------------------------------------
    # scanline overlay
    for y in range(0, RH, 3):
        d.line([(0, y), (RW, y)], fill=(0, 0, 0, 26))

    hud_font = font(FONT_BOLD, int(13 * SS))
    hud_small = font(FONT_REG, int(11 * SS))
    monof = font(FONT_MONO, int(12 * SS))

    # top-left: tournament bug
    d.rectangle([18 * SS, 16 * SS, 246 * SS, 52 * SS], fill=(0, 0, 0, 120))
    d.rectangle([18 * SS, 16 * SS, 22 * SS, 52 * SS], fill=(*VIOLET, 255))
    d.text((32 * SS, 22 * SS), "RIFT PROTOCOL", font=hud_font, fill=(255, 255, 255, 240))
    d.text((32 * SS, 36 * SS), "RANKED · ASCENT · WAVE 3/5", font=hud_small, fill=(170, 180, 200, 230))

    # top-centre round timer
    tsec = 8 * 60 - int(t * 1.0)
    d.text((RW / 2 - 26 * SS, 18 * SS), f"{tsec // 60}:{tsec % 60:02d}",
           font=font(FONT_MONO, int(20 * SS)), fill=(255, 255, 255, 235))

    # top-right killfeed
    feed = [
        ("v0lt", "shadez", "HEADSHOT"),
        ("kirin.exe", "n0va", "AR-9"),
        ("miko", "brk", "SKILL"),
    ]
    for k, (a, b, how) in enumerate(feed):
        if (i + k * 37) % 260 < 200:
            y = (20 + k * 20) * SS
            txt = f"{a}  ▸ {b}"
            d.text((RW - 176 * SS, y), txt, font=hud_small, fill=(235, 240, 250, 220))
            d.text((RW - 176 * SS, y + 9 * SS), how, font=font(FONT_REG, int(9 * SS)),
                   fill=(*AMBER, 200))

    # bottom-left vitals
    bx, by = 18 * SS, (H - 62) * SS
    hp = 0.62 + 0.16 * math.sin(t * 1.3)
    en = 0.5 + 0.3 * math.sin(t * 0.7 + 1)
    d.rectangle([bx, by, bx + 210 * SS, by + 13 * SS], fill=(0, 0, 0, 150))
    d.rectangle([bx, by, bx + 210 * SS * hp, by + 13 * SS], fill=(*TEAL, 235))
    d.rectangle([bx, by + 20 * SS, bx + 210 * SS, by + 28 * SS], fill=(0, 0, 0, 150))
    d.rectangle([bx, by + 20 * SS, bx + 210 * SS * en, by + 28 * SS], fill=(*VIOLET, 235))
    d.rectangle([bx - 2 * SS, by - 17 * SS, bx + 124 * SS, by - 3 * SS], fill=(0, 0, 0, 150))
    d.text((bx + 2 * SS, by - 16 * SS), "HP 1,840 / 2,400", font=hud_small, fill=(215, 225, 240, 235))

    # bottom-centre abilities
    for k in range(4):
        ax = RW / 2 - 110 * SS + k * 58 * SS
        ay = (H - 56) * SS
        cd = (math.sin(t * 0.9 + k * 1.7) + 1) / 2
        d.rounded_rectangle([ax, ay, ax + 44 * SS, ay + 44 * SS], radius=8 * SS,
                            fill=(0, 0, 0, 150), outline=(140, 150, 175, 90), width=int(1 * SS))
        if cd > 0.15:
            d.rectangle([ax, ay + 44 * SS * (1 - cd), ax + 44 * SS, ay + 44 * SS], fill=(*VIOLET, 70))
        d.text((ax + 8 * SS, ay + 14 * SS), "QWE R"[k], font=hud_font, fill=(230, 235, 245, 210))

    # bottom-right minimap
    mx, my, ms = RW - 130 * SS, (H - 130) * SS, 108 * SS
    d.rounded_rectangle([mx, my, mx + ms, my + ms], radius=6 * SS, fill=(0, 0, 0, 150),
                        outline=(120, 130, 160, 90))
    for gx in range(1, 4):
        d.line([(mx + ms * gx / 4, my), (mx + ms * gx / 4, my + ms)], fill=(120, 130, 160, 50))
        d.line([(mx, my + ms * gx / 4), (mx + ms, my + ms * gx / 4)], fill=(120, 130, 160, 50))
    for e in enemies:
        ex, ey = e.at(t)
        px = mx + ms / 2 + ex * ms * 0.45
        py = my + ms / 2 + ey * ms * 0.9
        d.ellipse([px - 2.5 * SS, py - 2.5 * SS, px + 2.5 * SS, py + 2.5 * SS], fill=(*RED, 230))
    px = mx + ms / 2 + math.sin(t * 0.6) * ms * 0.19
    py = my + ms / 2 + math.cos(t * 0.45) * ms * 0.05
    d.ellipse([px - 3.5 * SS, py - 3.5 * SS, px + 3.5 * SS, py + 3.5 * SS], fill=(*TEAL, 255))

    # wave banner (fades in/out cyclically)
    bp = (t % 13.0) / 13.0
    if bp < 0.28:
        a = int(255 * math.sin(bp / 0.28 * math.pi))
        d.text((RW / 2 - 88 * SS, RH * 0.20), "WAVE 3", font=font(FONT_BOLD, int(38 * SS)),
               fill=(255, 255, 255, a))
        d.text((RW / 2 - 74 * SS, RH * 0.20 + 46 * SS), "THE HOLLOW GATE", font=font(FONT_REG, int(14 * SS)),
               fill=(*AMBER, a))

    # ---- post: bloom, vignette, scanlines, grain ---------------------------
    small = img.resize((RW // 4, RH // 4), Image.BILINEAR)
    bright = np.clip(np.asarray(small).astype(np.float32) - 132.0, 0, 255)
    bl = Image.fromarray(bright.astype(np.uint8)).filter(ImageFilter.GaussianBlur(9)).resize(
        (RW, RH), Image.BILINEAR)
    masks = _static_masks()
    arr = np.asarray(img).astype(np.float32)
    arr = 255 - (255 - arr) * (255 - np.asarray(bl).astype(np.float32) * 0.62) / 255
    arr *= masks["vig"] * masks["scan"]
    rng = np.random.default_rng(i)
    arr += rng.normal(0, 2.6, arr.shape)
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    return Image.fromarray(arr).resize((W, H), Image.LANCZOS)


def build_video():
    os.makedirs(os.path.join(OUT, "demo"), exist_ok=True)
    tmp = os.path.join(OUT, "demo", "_frames.mp4")
    silent = os.path.join(OUT, "demo", "_silent.mp4")
    print(f"rendering {NFRAMES} frames ...")
    cmd = [
        FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
        "-an", "-c:v", "libx264", "-preset", "medium", "-crf", "26", "-pix_fmt", "yuv420p",
        silent,
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    poster = None
    for i in range(NFRAMES):
        frame = draw_frame(i)
        if i == int(FPS * 5.5):
            poster = frame.copy()
        proc.stdin.write(frame.tobytes())
        if i % 60 == 0:
            print(f"  frame {i}/{NFRAMES}", flush=True)
    proc.stdin.close()
    proc.wait()

    # ambient soundtrack (procedural, deterministic)
    audio = os.path.join(OUT, "demo", "_audio.m4a")
    expr = (
        "0.16*sin(2*PI*55*t)+0.09*sin(2*PI*82.5*t)*sin(2*PI*0.25*t)"
        "+0.07*sin(2*PI*110*t)*exp(-7*mod(t\\,0.5))"
        "+0.05*sin(2*PI*164.81*t)*exp(-16*mod(t\\,0.25))"
        "+0.035*(random(0)*2-1)*exp(-38*mod(t\\,0.25))"
        "+0.03*(random(0)*2-1)*exp(-3*mod(t\\,4))"
    )
    subprocess.run([
        FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", f"aevalsrc={expr}:s=44100:d={DURATION}",
        "-af", "lowpass=f=4200,volume=0.85,afade=t=in:st=0:d=1.5,afade=t=out:st={}:d=2".format(DURATION - 2),
        "-c:a", "aac", "-b:a", "96k", audio,
    ], check=True)

    renditions = [("stream-720.mp4", 1280, 720, "1500k"), ("stream-480.mp4", 854, 480, "900k"),
                  ("stream-360.mp4", 640, 360, "550k")]
    for name, w, h, br in renditions:
        out = os.path.join(OUT, "demo", name)
        subprocess.run([
            FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
            "-i", silent, "-i", audio,
            "-vf", f"scale={w}:{h}:flags=lanczos",
            "-c:v", "libx264", "-preset", "medium", "-crf", "28", "-maxrate", br, "-bufsize", "2M",
            "-pix_fmt", "yuv420p", "-profile:v", "main", "-g", "60",
            "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", "-shortest", out,
        ], check=True)
        print("  wrote", name, os.path.getsize(out) // 1024, "KiB")

    if poster is not None:
        poster.save(os.path.join(OUT, "demo", "poster.jpg"), quality=86)
    for f in (tmp, silent, audio):
        if os.path.exists(f):
            os.remove(f)


def write_captions():
    cues = [
        (0.0, 6.5, "[ambient synth score]"),
        (6.5, 11.0, "[pulsing bass, distant impacts]"),
        (11.0, 15.5, "[wave three begins]"),
        (15.5, 20.0, "[ability cast, energy surge]"),
        (20.0, 26.0, "[music fades out]"),
    ]

    def ts(x):
        hh = int(x // 3600)
        mm = int(x % 3600 // 60)
        ss = x % 60
        return f"{hh:02d}:{mm:02d}:{ss:06.3f}"

    lines = ["WEBVTT", "", "NOTE Generated by tools/gen_assets.py — captions describe the "
             "bundled ambient score, which contains no speech.", ""]
    for a, b, text in cues:
        lines += [f"{ts(a)} --> {ts(b)}", text, ""]
    with open(os.path.join(OUT, "demo", "stream.en.vtt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


# --------------------------------------------------------------------------- #
# Card art
# --------------------------------------------------------------------------- #
def mesh_gradient(seed, w, h, palette):
    rng = random.Random(seed)
    small = Image.new("RGB", (9, 6))
    px = small.load()
    for y in range(6):
        for x in range(9):
            # bias toward the palette's dominant tones so each set feels related
            c = palette[rng.randrange(len(palette))] if rng.random() < 0.55 else palette[1 + rng.randrange(2)]
            px[x, y] = c
    img = small.resize((w, h), Image.BICUBIC)
    return img.filter(ImageFilter.GaussianBlur(w / 170))


def add_grain(img, amount=10, seed=0):
    arr = np.asarray(img).astype(np.float32)
    rng = np.random.default_rng(seed)
    arr += rng.normal(0, amount, arr.shape)
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


def add_vignette(img):
    w, h = img.size
    arr = np.asarray(img).astype(np.float32)
    yy, xx = np.mgrid[0:h, 0:w]
    nx = (xx - w / 2) / (w / 2)
    ny = (yy - h / 2) / (h / 2)
    vig = np.clip(1.05 - 0.40 * (nx ** 2 * 0.8 + ny ** 2), 0, 1.1)[..., None]
    return Image.fromarray(np.clip(arr * vig, 0, 255).astype(np.uint8))


PALETTES = [
    [(18, 16, 34), (74, 46, 140), (139, 124, 255), (24, 20, 40)],          # violet
    [(10, 24, 30), (18, 92, 90), (70, 224, 192), (8, 18, 26)],             # teal
    [(30, 12, 20), (120, 30, 60), (240, 68, 82), (22, 10, 16)],            # crimson
    [(28, 20, 10), (140, 92, 24), (255, 180, 87), (20, 14, 8)],            # amber
    [(14, 18, 34), (36, 62, 140), (108, 168, 255), (10, 12, 26)],          # blue
    [(24, 14, 30), (88, 30, 120), (206, 120, 255), (16, 10, 22)],          # magenta
]


def make_thumb(seed, w=640, h=360):
    rng = random.Random(seed * 977 + 13)
    pal = PALETTES[seed % len(PALETTES)]
    img = mesh_gradient(seed, w, h, pal).convert("RGBA")
    d = ImageDraw.Draw(img, "RGBA")

    # diagonal hairlines give the art a technical, UI-like texture
    for k in range(7):
        y0 = int(h * (k / 7))
        d.line([(0, y0), (w, y0 - int(h * 0.2))], fill=(255, 255, 255, 8), width=1)
    for k in range(5):
        x0 = int(w * (k / 5))
        d.line([(x0, 0), (x0 + int(w * 0.32), h)], fill=(255, 255, 255, 6), width=1)

    # geometric strata
    for _ in range(rng.randint(3, 5)):
        kind = rng.random()
        col = (*pal[rng.randrange(1, 3)], rng.randint(40, 110))
        if kind < 0.4:
            cx, cy = rng.randint(0, w), rng.randint(0, h)
            r = rng.randint(int(h * 0.25), int(h * 0.8))
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col, width=rng.randint(2, 6))
        elif kind < 0.7:
            pts = [(rng.randint(-40, w + 40), rng.randint(-40, h + 40)) for _ in range(3)]
            d.polygon(pts, fill=(*pal[rng.randrange(1, 3)], rng.randint(24, 60)))
        else:
            y = rng.randint(int(h * .2), int(h * .8))
            d.line([(0, y), (w, y + rng.randint(-24, 24))], fill=col, width=rng.randint(2, 5))

    # diagonal light sweep
    sweep = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(sweep)
    sd.polygon([(w * .1, h), (w * .45, 0), (w * .62, 0), (w * .27, h)], fill=(255, 255, 255, 16))
    img = Image.alpha_composite(img, sweep.filter(ImageFilter.GaussianBlur(6)))

    # corner brackets (house style)
    d = ImageDraw.Draw(img, "RGBA")
    m, l = 10, 22
    for (x0, y0, x1, y1) in [(m, m, m + l, m), (m, m, m, m + l)]:
        d.line([(x0, y0), (x1, y1)], fill=(255, 255, 255, 90), width=2)
    for (x0, y0, x1, y1) in [(w - m - l, h - m, w - m, h - m), (w - m, h - m - l, w - m, h - m)]:
        d.line([(x0, y0), (x1, y1)], fill=(255, 255, 255, 90), width=2)

    # bottom scrim keeps overlaid card text legible
    scrim = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    sd2 = ImageDraw.Draw(scrim)
    for yy in range(int(h * 0.45), h):
        v = max(0.0, (yy - h * 0.45) / (h * 0.55))
        a = int(150 * v ** 1.4)
        sd2.line([(0, yy), (w, yy)], fill=(0, 0, 0, a))
    img = Image.alpha_composite(img, scrim)

    out = add_vignette(add_grain(img.convert("RGB"), 6, seed))
    from PIL import ImageEnhance
    out = ImageEnhance.Color(out).enhance(1.28)
    out = ImageEnhance.Contrast(out).enhance(1.22)
    return out


def make_avatar(seed, size=192):
    rng = random.Random(seed * 31 + 7)
    pal = PALETTES[seed % len(PALETTES)]
    img = mesh_gradient(seed + 40, size, size, pal).convert("RGBA")
    d = ImageDraw.Draw(img, "RGBA")
    for _ in range(rng.randint(2, 4)):
        cx, cy = rng.randint(0, size), rng.randint(0, size)
        r = rng.randint(size // 6, size // 2)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(*pal[rng.randrange(1, 3)], rng.randint(50, 120)))
    img = img.filter(ImageFilter.GaussianBlur(size / 55))
    d = ImageDraw.Draw(img, "RGBA")
    # monogram ring + glyph
    glyph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[seed % 36]
    f = font(FONT_BOLD, int(size * 0.42))
    tw = d.textlength(glyph, font=f)
    d.text(((size - tw) / 2, size * 0.28), glyph, font=f, fill=(255, 255, 255, 235))
    d.ellipse([2, 2, size - 3, size - 3], outline=(255, 255, 255, 40), width=2)
    return add_grain(img.convert("RGB"), 4, seed)


def make_emote(text, color, path, size=140):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([6, 18, size - 6, size - 18], radius=26,
                        fill=(*color, 232), outline=(255, 255, 255, 90), width=3)
    f = font(FONT_BOLD, int(size * (0.42 if len(text) <= 3 else 0.30)))
    tw = d.textlength(text, font=f)
    bbox = f.getbbox(text)
    d.text(((size - tw) / 2, (size - (bbox[3] - bbox[1])) / 2 - bbox[1]), text, font=f,
           fill=(12, 14, 20, 245))
    return img


def build_cards():
    for sub in ("thumbs", "avatars", "categories", "emotes"):
        os.makedirs(os.path.join(OUT, sub), exist_ok=True)
    for i in range(18):
        make_thumb(i).save(os.path.join(OUT, "thumbs", f"t{i:02d}.jpg"), quality=82)
    for i in range(14):
        make_avatar(i).save(os.path.join(OUT, "avatars", f"a{i:02d}.jpg"), quality=86)
    for i in range(8):
        make_thumb(100 + i, 480, 270).save(os.path.join(OUT, "categories", f"c{i:02d}.jpg"), quality=84)
    emotes = [("GG", (139, 124, 255)), ("POG", (70, 224, 192)), ("LUL", (255, 180, 87)),
              ("RIP", (240, 68, 82)), ("EZ", (108, 168, 255)), ("CLUTCH", (206, 120, 255)),
              ("HYPE", (255, 212, 87)), ("NOOB", (150, 160, 180))]
    for name, col in emotes:
        make_emote(name, col, os.path.join(OUT, "emotes", f"{name.lower()}.png"))
    print("cards + emotes written")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    if what in ("all", "cards"):
        build_cards()
    if what in ("all", "video"):
        build_video()
        write_captions()
    print("done")
