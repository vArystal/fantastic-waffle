import { useCallback, useEffect, useState } from "react";
import { api } from "./api/mockApi";
import { demoStore } from "./api/demo";
import type { AppSession } from "./types";
import { cx, useMediaQuery } from "./lib/utils";
import { routes, useRoute } from "./lib/router";
import { useAsync } from "./state/useAsync";
import { useDemoState } from "./state/useDemo";
import { ToastProvider } from "./components/ui/Toast";
import { AppHeader } from "./components/layout/AppHeader";
import { Sidebar } from "./components/layout/Sidebar";
import { DemoPanel } from "./components/dialogs/Dialogs";
import { StreamPage } from "./pages/StreamPage";
import { BrowsePage, FollowingPage, HomePage } from "./pages/DiscoveryPages";
import { IconCompass, IconHeart, IconHome, IconUser } from "./components/icons";
import { Avatar } from "./components/ui/primitives";

function MobileNav({ session }: { session: AppSession | null }) {
  const route = useRoute();
  return (
    <nav className="mobile-nav" aria-label="Primary">
      <a className={cx("mobile-nav__item", route.name === "home" && "is-active")} href={routes.home()}>
        <IconHome size={19} />
        <span>Home</span>
      </a>
      <a className={cx("mobile-nav__item", route.name === "browse" && "is-active")} href={routes.browse()}>
        <IconCompass size={19} />
        <span>Browse</span>
      </a>
      <a className={cx("mobile-nav__item", route.name === "following" && "is-active")} href={routes.following()}>
        <IconHeart size={19} />
        <span>Following</span>
      </a>
      <a
        className={cx("mobile-nav__item", route.name === "stream" && "is-active")}
        href={session?.user ? routes.following() : routes.home()}
      >
        {session?.user ? (
          <Avatar src={session.user.avatarUrl} name={session.user.displayName} size={19} />
        ) : (
          <IconUser size={19} />
        )}
        <span>Profile</span>
      </a>
    </nav>
  );
}

function Shell() {
  const route = useRoute();
  const demo = useDemoState();
  const isMobile = useMediaQuery("(max-width: 767px)");
  const showSidebar = useMediaQuery("(min-width: 1400px)");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [demoOpen, setDemoOpen] = useState(false);

  const session = useAsync<AppSession>(() => api.getSession(), [demo.persona]);
  const discovery = useAsync(() => api.getDiscovery(), [demo.persona, demo.forcedStreamState]);

  /* close the mobile drawer whenever the route changes */
  useEffect(() => {
    setSidebarOpen(false);
  }, [route]);

  /* the document title follows the route; the stream page narrows it further */
  useEffect(() => {
    const base = "VANTA — Live streaming, built for focus";
    document.title =
      route.name === "browse"
        ? route.category
          ? `${route.category} live channels · VANTA`
          : "Browse live channels · VANTA"
        : route.name === "following"
          ? "Following · VANTA"
          : route.name === "stream"
            ? "Watch · VANTA"
            : base;
  }, [route]);

  /* keep demo state and session consistent when the persona flips */
  useEffect(() => {
    if (!demo.persona) demoStore.set({ persona: "subscriber" });
  }, [demo.persona]);

  const openDemo = useCallback(() => setDemoOpen(true), []);

  const page = (() => {
    switch (route.name) {
      case "stream":
        return <StreamPage slug={route.slug} session={session.data} onOpenDemo={openDemo} />;
      case "browse":
        return <BrowsePage category={route.category} />;
      case "following":
        return <FollowingPage session={session.data} />;
      default:
        return <HomePage session={session.data} onOpenDemo={openDemo} />;
    }
  })();

  return (
    <div className={cx("app", route.name === "stream" && "app--stream")}>
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>

      <AppHeader session={session.data} onOpenDemo={openDemo} onOpenSidebar={() => setSidebarOpen(true)} />

      <div className="app__body">
        <Sidebar
          discovery={discovery}
          open={isMobile || !showSidebar ? sidebarOpen : false}
          onClose={() => setSidebarOpen(false)}
          inline={showSidebar}
        />

        <main id="main-content" className="app__main" tabIndex={-1}>
          {page}
        </main>
      </div>

      {isMobile && <MobileNav session={session.data} />}

      <DemoPanel open={demoOpen} onClose={() => setDemoOpen(false)} stream={null} />

      <button className="demo-trigger" onClick={openDemo} aria-label="Open demo controls and role switcher">
        Demo
      </button>
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  );
}
