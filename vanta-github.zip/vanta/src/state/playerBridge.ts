/**
 * Tiny imperative bridge for the demo controls.
 *
 * The demo panel lives in the app shell (outside the player provider) but needs
 * to trigger a playback interruption. Rather than lift the whole player context
 * to the app root — which would couple every page to playback — the provider
 * registers a handler here on mount.
 */
export const playerBridge: {
  interrupt: (() => void) | null;
  isPlayable: () => boolean;
} = {
  interrupt: null,
  isPlayable: () => false,
};
