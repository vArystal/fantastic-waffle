import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, chatTransport, type ChatConnectionStatus } from "../api/mockApi";
import { ApiError, type ChatMessage, type Stream } from "../types";
import { uid } from "../lib/utils";

export type ChatStatus = ChatConnectionStatus | "idle";

/**
 * Chat state.
 *
 * Deliberately independent from playback: a dropped chat socket must never
 * interrupt the video, and pausing the video must never stop message delivery.
 */
export function useChat(stream: Stream) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [status, setStatus] = useState<ChatStatus>("idle");
  const [paused, setPaused] = useState(false);
  const [pinned, setPinned] = useState<ChatMessage | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [historyError, setHistoryError] = useState<ApiError | null>(null);
  const [olderCursor, setOlderCursor] = useState<string | null>(null);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [unread, setUnread] = useState(0);
  const [slowUntil, setSlowUntil] = useState(0);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;

  /* ---- initial history ------------------------------------------------ */
  useEffect(() => {
    let cancelled = false;
    setLoadingHistory(true);
    setHistoryError(null);
    setStatus("connecting");

    api
      .getChatHistory(stream.id)
      .then((page) => {
        if (cancelled) return;
        setMessages(page.messages);
        setOlderCursor(page.olderCursor);
      })
      .catch((err) => {
        if (cancelled) return;
        setHistoryError(err instanceof ApiError ? err : new ApiError("server_error", "Chat history failed to load."));
      })
      .finally(() => {
        if (!cancelled) setLoadingHistory(false);
      });

    api
      .getPinned(stream.id)
      .then((p) => !cancelled && setPinned(p))
      .catch(() => undefined);

    return () => {
      cancelled = true;
    };
  }, [stream.id]);

  /* ---- transport ------------------------------------------------------ */
  useEffect(() => {
    chatTransport.connect(stream.id);
    const offStatus = chatTransport.onStatus((s) => setStatus(s));
    const offEvents = chatTransport.onEvent((event) => {
      switch (event.type) {
        case "message":
          if (pausedRef.current) setUnread((u) => u + 1);
          setMessages((prev) => {
            // de-dupe by id: the send path and the socket echo can both deliver
            // the same message, and reconnects replay the tail
            if (prev.some((m) => m.id === event.message.id)) {
              return prev.map((m) =>
                m.id === event.message.id ? { ...event.message, deliveryState: "sent" as const } : m,
              );
            }
            return [...prev.slice(-300), event.message];
          });
          break;
        case "update":
          setMessages((prev) => prev.map((m) => (m.id === event.message.id ? event.message : m)));
          break;
        case "remove":
          setMessages((prev) => prev.filter((m) => m.id !== event.id));
          break;
        case "clear":
          setUnread(0);
          void api
            .getChatHistory(stream.id)
            .then((page) => setMessages(page.messages))
            .catch(() => undefined);
          break;
        case "pin":
          setPinned(event.message);
          break;
        default:
          break;
      }
    });

    return () => {
      offStatus();
      offEvents();
      chatTransport.disconnect(true);
    };
  }, [stream.id]);

  /* ---- sending -------------------------------------------------------- */
  const send = useCallback(
    async (text: string, replyTo: ChatMessage["replyTo"]) => {
      const optimisticId = uid("local");
      const optimistic: ChatMessage = {
        id: optimisticId,
        streamId: stream.id,
        author: null,
        kind: "chat",
        text,
        createdAt: new Date().toISOString(),
        badges: [],
        replyTo,
        emotes: [],
        mentions: [],
        isPinned: false,
        canDelete: false,
        deletedBy: null,
        deliveryState: "sending",
      };
      setMessages((prev) => [...prev, optimistic]);
      try {
        const sent = await api.sendMessage(stream.id, text, replyTo ?? undefined);
        setMessages((prev) => {
          // the socket echo may already have landed; never keep two copies
          const rest = prev.filter((m) => m.id !== optimisticId);
          if (rest.some((m) => m.id === sent.id)) {
            return rest.map((m) => (m.id === sent.id ? { ...m, deliveryState: "sent" as const } : m));
          }
          return [...rest, { ...sent, deliveryState: "sent" as const }];
        });
        return { ok: true as const };
      } catch (err) {
        const error = err instanceof ApiError ? err : new ApiError("server_error", "Message failed to send.");
        setMessages((prev) =>
          prev.map((m) =>
            m.id === optimisticId ? { ...m, deliveryState: "failed", failureReason: error.message } : m,
          ),
        );
        if (error.code === "rate_limited" && error.retryAfter) {
          setSlowUntil(Date.now() + error.retryAfter * 1000);
        }
        return { ok: false as const, error };
      }
    },
    [stream.id],
  );

  const retryFailed = useCallback(
    async (message: ChatMessage) => {
      setMessages((prev) => prev.filter((m) => m.id !== message.id));
      await send(message.text, message.replyTo);
    },
    [send],
  );

  const dismissFailed = useCallback((messageId: string) => {
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
  }, []);

  /* ---- moderation ----------------------------------------------------- */
  const deleteMessage = useCallback(
    async (messageId: string) => {
      await api.deleteMessage(stream.id, messageId);
    },
    [stream.id],
  );

  const clearChat = useCallback(async () => {
    await api.clearChat(stream.id);
  }, [stream.id]);

  const pinMessage = useCallback(
    async (messageId: string | null) => {
      const next = await api.pinMessage(stream.id, messageId);
      setPinned(next);
    },
    [stream.id],
  );

  const timeoutUser = useCallback(
    async (userId: string, seconds: number, reason?: string) => {
      await api.timeoutUser(stream.id, userId, seconds, reason);
    },
    [stream.id],
  );

  const banUser = useCallback(
    async (userId: string) => {
      await api.banUser(stream.id, userId);
    },
    [stream.id],
  );

  const loadOlder = useCallback(async () => {
    if (!olderCursor || loadingOlder) return;
    setLoadingOlder(true);
    try {
      const page = await api.getChatHistory(stream.id, olderCursor);
      setMessages((prev) => {
        const existing = new Set(prev.map((m) => m.id));
        return [...page.messages.filter((m) => !existing.has(m.id)), ...prev];
      });
      setOlderCursor(page.olderCursor);
    } finally {
      setLoadingOlder(false);
    }
  }, [olderCursor, loadingOlder, stream.id]);

  const resume = useCallback(() => {
    setPaused(false);
    setUnread(0);
  }, []);

  const reconnect = useCallback(() => {
    chatTransport.connect(stream.id);
    setStatus("connecting");
  }, [stream.id]);

  return useMemo(
    () => ({
      messages,
      status,
      paused,
      setPaused,
      pinned,
      loadingHistory,
      historyError,
      loadOlder,
      hasOlder: Boolean(olderCursor),
      loadingOlder,
      unread,
      resume,
      reconnect,
      slowUntil,
      send,
      retryFailed,
      dismissFailed,
      deleteMessage,
      clearChat,
      pinMessage,
      timeoutUser,
      banUser,
    }),
    [
      messages, status, paused, pinned, loadingHistory, historyError, loadOlder, olderCursor,
      loadingOlder, unread, resume, reconnect, slowUntil, send, retryFailed, dismissFailed,
      deleteMessage, clearChat, pinMessage, timeoutUser, banUser,
    ],
  );
}

export type ChatApi = ReturnType<typeof useChat>;
