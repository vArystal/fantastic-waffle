import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError } from "../types";

export interface AsyncState<T> {
  data: T | null;
  error: ApiError | null;
  loading: boolean;
  /** true only for the first load, so refreshes don't flash skeletons */
  initialLoading: boolean;
}

/**
 * Generic async resource hook.
 *
 * - ignores results from stale requests (race-condition safe)
 * - de-duplicates concurrent reloads
 * - keeps previous data visible while refetching
 * - never sets state after unmount
 */
export function useAsync<T>(
  fetcher: () => Promise<T>,
  deps: unknown[],
  options: { enabled?: boolean } = {},
) {
  const enabled = options.enabled ?? true;
  const [state, setState] = useState<AsyncState<T>>({
    data: null,
    error: null,
    loading: enabled,
    initialLoading: enabled,
  });

  const requestId = useRef(0);
  const mounted = useRef(true);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;
  const inFlight = useRef(false);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const run = useCallback(async (opts: { silent?: boolean } = {}) => {
    if (inFlight.current) return;
    inFlight.current = true;
    const id = ++requestId.current;
    if (!opts.silent) {
      setState((prev) => ({ ...prev, loading: true, error: null }));
    }
    try {
      const data = await fetcherRef.current();
      if (!mounted.current || id !== requestId.current) return;
      setState({ data, error: null, loading: false, initialLoading: false });
    } catch (err) {
      if (!mounted.current || id !== requestId.current) return;
      const apiError =
        err instanceof ApiError
          ? err
          : new ApiError("server_error", err instanceof Error ? err.message : "Something went wrong.");
      setState((prev) => ({ ...prev, error: apiError, loading: false, initialLoading: false }));
    } finally {
      inFlight.current = false;
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;
    void run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, enabled]);

  const setData = useCallback((updater: T | ((prev: T | null) => T)) => {
    setState((prev) => ({
      ...prev,
      data: typeof updater === "function" ? (updater as (p: T | null) => T)(prev.data) : updater,
    }));
  }, []);

  return {
    ...state,
    reload: () => run(),
    refresh: () => run({ silent: true }),
    setData,
  };
}
