import { useSyncExternalStore } from "react";
import { demoStore, type DemoState } from "../api/demo";

/** Subscribe a component to demo switches (network, persona, forced state). */
export function useDemoState(): DemoState {
  return useSyncExternalStore(
    (listener) => demoStore.subscribe(listener),
    () => demoStore.get(),
    () => demoStore.get(),
  );
}
