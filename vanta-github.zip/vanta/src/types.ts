/**
 * VANTA — domain contracts.
 *
 * These types are the *integration contract* with a future backend. Every field
 * here is what a real API is expected to return; the mock service implements
 * exactly this shape. Nothing in the UI reaches around these types.
 */

export type Role = "guest" | "viewer" | "subscriber" | "moderator" | "streamer";

export interface User {
  id: string;
  login: string;
  displayName: string;
  avatarUrl: string | null;
  /** deterministic chat name colour, assigned server-side */
  color: string;
  roles: Role[];
  verified: boolean;
  /** true when the account is the authenticated viewer's own record */
  isSelf?: boolean;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  artUrl: string | null;
  /** live viewer count across the whole category */
  viewers: number;
  tags: string[];
}

export interface SocialLink {
  kind: "x" | "youtube" | "discord" | "instagram" | "website" | "tiktok";
  label: string;
  href: string;
}

export interface ScheduleEntry {
  /** ISO weekday index, 0 = Sunday */
  dayOfWeek: number;
  startTime: string; // "19:00"
  durationMinutes: number;
  title: string;
  categoryName: string;
}

export interface Channel {
  id: string;
  slug: string;
  displayName: string;
  avatarUrl: string | null;
  bannerUrl: string | null;
  bio: string;
  verified: boolean;
  followerCount: number;
  subscriberCount: number | null;
  subscriptionsEnabled: boolean;
  socials: SocialLink[];
  categoryId: string | null;
  language: string;
  schedule: ScheduleEntry[];
  createdAt: string;
  /** present when the viewer has previously followed/watched this channel */
  viewerIsFollowing?: boolean;
  viewerFollowAlerts?: FollowAlerts;
  lastWatchedAt?: string | null;
}

export type FollowAlerts = "all" | "live" | "none";

export type StreamState =
  | "live"
  | "offline"
  | "scheduled"
  | "ended"
  | "restricted"
  | "unavailable";

export interface Rendition {
  id: string;
  /** display label, e.g. "720p" */
  label: string;
  height: number;
  /** progressive MP4 URL for this rendition */
  src: string;
  bitrateKbps: number;
}

export interface CaptionTrack {
  id: string;
  label: string;
  language: string;
  src: string;
  default?: boolean;
}

export interface DvrWindow {
  enabled: boolean;
  /** rolling window length in seconds */
  windowSeconds: number;
}

export interface PlaybackSource {
  /**
   * "progressive" = separate MP4 renditions, quality switch = explicit source
   * swap (what the demo uses). "hls" = adaptive bitrate, requires an HLS
   * player; `hlsUrl` is the manifest and `renditions` becomes informational.
   */
  kind: "progressive" | "hls";
  hlsUrl?: string;
  renditions: Rendition[];
  captions: CaptionTrack[];
  posterUrl: string | null;
  dvr: DvrWindow;
  lowLatency: boolean;
  aspectRatio?: string;
}

export interface ChatSettings {
  slowModeSeconds: number;
  subscribersOnly: boolean;
  followersOnly: boolean;
  /**
   * Whether the channel requires a verified account before chatting.
   * Enforced by the auth/profile service at send time; the player surface only
   * needs it to explain why a send was rejected.
   */
  requiresVerifiedEmail: boolean;
}

export interface StreamStats {
  peakViewers: number;
  followerGain: number;
  /** 30 one-minute samples, oldest first — drives the trend sparkline */
  viewerTrend: number[];
}

export interface Stream {
  id: string;
  slug: string;
  title: string;
  channel: Channel;
  category: Category | null;
  state: StreamState;
  /** ISO timestamp for live streams */
  startedAt: string | null;
  scheduledFor: string | null;
  /** set when state === "ended" */
  endedAt: string | null;
  viewerCount: number;
  language: string;
  tags: string[];
  isMature: boolean;
  playback: PlaybackSource | null;
  stats: StreamStats;
  chatSettings: ChatSettings;
  /** reason shown when state is restricted/unavailable */
  stateReason: string | null;
  /** viewer-specific permission, computed server-side */
  viewerCanModerate: boolean;
  viewerCanCreateClip: boolean;
}

export type ChatMessageKind =
  | "chat"
  | "system"
  | "announcement"
  | "moderation"
  | "subscription";

export interface ChatBadge {
  kind: "streamer" | "moderator" | "subscriber" | "verified" | "founder";
  /** months subscribed / duration label */
  label?: string;
}

export interface ChatMention {
  login: string;
  displayName: string;
}

export interface ChatMessage {
  id: string;
  streamId: string;
  /** null for system / moderation messages */
  author: User | null;
  kind: ChatMessageKind;
  text: string;
  createdAt: string;
  badges: ChatBadge[];
  replyTo: { id: string; displayName: string; text: string } | null;
  /** run ids resolved against the emote map, computed server-side */
  emotes: string[];
  mentions: ChatMention[];
  isPinned: boolean;
  /** true when the viewer may delete this message */
  canDelete: boolean;
  /** removed by a moderator — rendered as a tombstone, not deleted from state */
  deletedBy: string | null;
  /** local-only delivery state for optimistic messages */
  deliveryState?: "sending" | "failed" | "sent";
  /** local-only id of the optimistic message this replaces */
  clientId?: string;
  /** local-only reason a send was rejected, shown inline next to the message */
  failureReason?: string;
}

export interface ChatHistoryPage {
  messages: ChatMessage[];
  /** cursor for the previous page; null when the start is reached */
  olderCursor: string | null;
}

export interface PinnedMessage {
  id: string;
  text: string;
  authorDisplayName: string;
  pinnedAt: string;
}

/* -------------------------------------------------------------------------- */
/* community widgets                                                          */
/* -------------------------------------------------------------------------- */

export interface PollOption {
  id: string;
  label: string;
  votes: number;
}

export interface Poll {
  id: string;
  streamId: string;
  question: string;
  options: PollOption[];
  status: "open" | "closed";
  createdAt: string;
  closesAt: string | null;
  totalVotes: number;
  /** option id the viewer voted for, or null */
  viewerVote: string | null;
  canClose: boolean;
  createdBy: string;
}

export interface PredictionOutcome {
  id: string;
  label: string;
  color: "blue" | "pink";
  points: number;
  entries: number;
}

export interface Prediction {
  id: string;
  streamId: string;
  question: string;
  outcomes: PredictionOutcome[];
  status: "open" | "locked" | "resolved" | "cancelled";
  locksAt: string | null;
  resolvedOutcomeId: string | null;
  viewerEntry: { outcomeId: string; points: number } | null;
  /** accrual is disabled in this deployment — see integration notes */
  spendEnabled: boolean;
}

export interface StreamGoal {
  id: string;
  kind: "subscribers" | "followers" | "donation";
  label: string;
  current: number;
  target: number;
  /** donation goals carry a currency; accrual is backend-only */
  unit: string | null;
  visibility: "public" | "hidden";
}

export interface LeaderboardEntry {
  rank: number;
  user: Pick<User, "id" | "login" | "displayName" | "avatarUrl" | "color">;
  score: number;
  /** "bits", "watch time", "messages" */
  metric: string;
  isSelf: boolean;
  anonymous: boolean;
}

export interface Leaderboard {
  id: string;
  title: string;
  period: "session" | "week" | "month" | "all-time";
  metric: string;
  entries: LeaderboardEntry[];
  /** true when the viewer opted out of public listing */
  viewerOptedOut: boolean;
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  cost: number;
  cooldownSeconds: number;
  stock: number | null;
  /** unavailable reasons are explicit rather than hidden */
  unavailableReason: string | null;
}

export interface RewardsState {
  /** null when the points balance cannot be disclosed to the client */
  balance: number | null;
  lifetimeEarned: number;
  rewards: Reward[];
  redemptionEnabled: boolean;
}

export interface Clip {
  id: string;
  title: string;
  thumbnailUrl: string | null;
  durationSeconds: number;
  viewCount: number;
  createdAt: string;
  creatorDisplayName: string;
  gameName: string;
}

export interface Vod {
  id: string;
  title: string;
  thumbnailUrl: string | null;
  durationSeconds: number;
  viewCount: number;
  publishedAt: string;
  categoryName: string;
}

export interface SupportAlert {
  id: string;
  kind: "subscription" | "gift" | "donation" | "raid";
  displayName: string;
  detail: string;
  createdAt: string;
  /** monetary values are display strings from the server, never computed client-side */
  amountLabel: string | null;
}

/* -------------------------------------------------------------------------- */
/* api envelopes                                                              */
/* -------------------------------------------------------------------------- */

export type ApiErrorCode =
  | "unauthenticated"
  | "forbidden"
  | "not_found"
  | "rate_limited"
  | "conflict"
  | "validation_failed"
  | "network"
  | "server_error"
  | "unsupported";

export class ApiError extends Error {
  code: ApiErrorCode;
  status: number;
  /** seconds until retry, for rate limits */
  retryAfter?: number;
  details?: Record<string, string>;

  constructor(
    code: ApiErrorCode,
    message: string,
    status = 400,
    extra?: { retryAfter?: number; details?: Record<string, string> },
  ) {
    super(message);
    this.name = "ApiError";
    this.code = code;
    this.status = status;
    this.retryAfter = extra?.retryAfter;
    this.details = extra?.details;
  }
}

export interface Emote {
  id: string;
  code: string;
  url: string;
  /** only usable by subscribers */
  subscriberOnly: boolean;
}

export interface SearchResults {
  channels: Channel[];
  categories: Category[];
  streams: Stream[];
}

export interface AppSession {
  user: User | null;
  /** role switches are a demo affordance; a real build derives this from auth */
  canGoLive: boolean;
}
