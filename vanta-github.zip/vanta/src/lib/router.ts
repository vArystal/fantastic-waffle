import { useSyncExternalStore } from "react";

/**
 * Minimal hash router.
 *
 * Hash routing keeps the build deployable as static files (and inside the
 * preview iframe) without a server rewrite rule. Swap for the app's real router
 * when integrating — the route shapes below are the contract.
 *
 *   #/                     discovery home
 *   #/browse               categories
 *   #/following            followed channels
 *   #/c/:slug              stream / channel page
 */

export type Route =
  | { name: "home" }
  | { name: "browse"; category?: string }
  | { name: "following" }
  | { name: "stream"; slug: string };

function parse(hash: string): Route {
  const clean = hash.replace(/^#\/?/, "");
  const [path, query] = clean.split("?");
  const segments = path.split("/").filter(Boolean);
  const params = new URLSearchParams(query ?? "");

  if (segments[0] === "c" && segments[1]) return { name: "stream", slug: segments[1] };
  if (segments[0] === "browse") return { name: "browse", category: params.get("category") ?? undefined };
  if (segments[0] === "following") return { name: "following" };
  return { name: "home" };
}

let current = parse(typeof location === "undefined" ? "" : location.hash);
const listeners = new Set<() => void>();

function notify() {
  current = parse(location.hash);
  listeners.forEach((l) => l());
}

if (typeof window !== "undefined") {
  window.addEventListener("hashchange", notify);
}

export function useRoute(): Route {
  return useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => current,
    () => current,
  );
}

export function navigate(to: string, opts: { replace?: boolean; keepScroll?: boolean } = {}) {
  const target = to.startsWith("#") ? to : `#${to}`;
  if (location.hash === target) return;
  if (opts.replace) {
    history.replaceState(null, "", target);
    notify();
  } else {
    location.hash = target;
  }
  if (!opts.keepScroll) window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
}

export const routes = {
  home: () => "#/",
  browse: (category?: string) => (category ? `#/browse?category=${encodeURIComponent(category)}` : "#/browse"),
  following: () => "#/following",
  channel: (slug: string) => `#/c/${slug}`,
};
