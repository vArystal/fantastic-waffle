import { useCallback, useEffect, useState } from "react";
import { api } from "../api/mockApi";
import type { AppSession, ChatMessage, Emote, Stream } from "../types";
import { cx, useMediaQuery } from "../lib/utils";
import { useAsync } from "../state/useAsync";
import { useChat } from "../state/useChat";
import { useDemoState } from "../state/useDemo";
import { PlayerProvider, usePlayer } from "../components/player/PlayerContext";
import { VideoPlayer } from "../components/player/VideoPlayer";
import { StreamHeader } from "../components/stream/StreamHeader";
import { ChannelCard, RelatedStreams, StreamTabs } from "../components/stream/StreamTabs";
import { ChatPanel } from "../components/chat/ChatPanel";
import { PollStrip } from "../components/widgets/Community";
import { ClipDialog, ReportDialog, ShortcutsDialog, SignInDialog, SubscribeDialog } from "../components/dialogs/Dialogs";
import { ErrorState, SkeletonLine, Spinner } from "../components/ui/primitives";
import { IconAlert, IconChat, IconGrid } from "../components/icons";
import { useToast } from "../components/ui/Toast";

/* -------------------------------------------------------------------------- */
/* skeleton                                                                   */
/* -------------------------------------------------------------------------- */

function StreamPageSkeleton() {
  return (
    <div className="stream-page stream-page--loading" aria-busy="true" aria-label="Loading stream">
      <div className="stream-main">
        <div className="watch">
          <div className="watch__player">
            <span className="skeleton player-skeleton" />
            <div className="stream-head-skeleton">
              <SkeletonLine width={52} height={52} radius={26} />
              <div style={{ flex: 1 }}>
                <SkeletonLine width="64%" height={16} />
                <SkeletonLine width="38%" height={11} />
                <SkeletonLine width="46%" height={11} />
              </div>
            </div>
          </div>
          <div className="watch__chat">
            <span className="skeleton chat-skeleton" />
          </div>
        </div>
      </div>
    </div>
  );
}

function RelatedRail({ excludeId }: { excludeId: string }) {
  const discovery = useAsync(() => api.getDiscovery(), []);
  const related = (discovery.data?.recommended ?? []).filter((s) => s.id !== excludeId);
  if (discovery.initialLoading) {
    return (
      <section className="related" aria-busy="true">
        <SkeletonLine width="30%" height={14} />
        <SkeletonLine height={48} style={{ marginTop: 12 }} />
        <SkeletonLine height={48} style={{ marginTop: 8 }} />
      </section>
    );
  }
  if (!related.length) {
    return (
      <section className="related">
        <div className="section-head">
          <h2 className="section-head__title">Related streams</h2>
        </div>
        <p className="related__empty">No other live channels in this category right now.</p>
      </section>
    );
  }
  return <RelatedStreams streams={related} title="Related live channels" />;
}

/* -------------------------------------------------------------------------- */
/* inner (requires a loaded stream so the player provider has a subject)       */
/* -------------------------------------------------------------------------- */

function StreamExperience({
  stream: initialStream,
  session,
  onOpenDemo,
}: {
  stream: Stream;
  session: AppSession | null;
  onOpenDemo: () => void;
}) {
  const [stream, setStream] = useState(initialStream);
  const [emotes, setEmotes] = useState<Emote[]>([]);
  const [mobileTab, setMobileTab] = useState<"chat" | "details">("chat");
  const [reportOpen, setReportOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ type: "stream" | "chat_message"; id: string; label: string }>({
    type: "stream",
    id: initialStream.id,
    label: initialStream.channel.displayName,
  });
  const [clipOpen, setClipOpen] = useState(false);
  const [subscribeOpen, setSubscribeOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [signInOpen, setSignInOpen] = useState(false);

  const isWide = useMediaQuery("(min-width: 1024px)");
  const { theater } = usePlayer();
  const chat = useChat(stream);

  /* theater mode is a page-level layout concern; a document attribute lets the
     shell respond without threading player state through every component */
  useEffect(() => {
    document.documentElement.dataset.theater = theater ? "true" : "false";
    return () => {
      document.documentElement.dataset.theater = "false";
    };
  }, [theater]);
  const user = session?.user ?? null;

  useEffect(() => setStream(initialStream), [initialStream]);

  useEffect(() => {
    void api.getEmotes().then(setEmotes).catch(() => setEmotes([]));
  }, []);

  useEffect(() => {
    void api.markWatched(stream.channel.id).catch(() => undefined);
  }, [stream.channel.id]);

  const onChannelChange = useCallback((next: { following: boolean; followerCount: number }) => {
    setStream((prev) => ({
      ...prev,
      channel: {
        ...prev.channel,
        viewerIsFollowing: next.following,
        followerCount: next.followerCount,
      },
    }));
  }, []);

  const openChatReport = (message: ChatMessage) => {
    setReportTarget({
      type: "chat_message",
      id: message.id,
      label: `${message.author?.displayName ?? "message"}: ${message.text.slice(0, 60)}`,
    });
    setReportOpen(true);
  };

  const chatPanel = (
    <ChatPanel
      stream={stream}
      chat={chat}
      emotes={emotes}
      user={user}
      layout={isWide ? "side" : "embedded"}
      onRequireAuth={() => setSignInOpen(true)}
      onOpenProfile={(login) => {
        const target = stream.channel.slug === login ? stream.channel.slug : login;
        location.hash = `#/c/${target}`;
      }}
      onReport={openChatReport}
    />
  );

  return (
    <>
      <div className={cx("stream-page", stream.state === "live" && "is-live")}>
        <div className="stream-main">
          <div className="watch">
            <div className="watch__player">
              <VideoPlayer stream={stream} onOpenShortcuts={() => setShortcutsOpen(true)} />
              <StreamHeader
                stream={stream}
                user={user}
                onChannelChange={onChannelChange}
                onOpenSubscribe={() => setSubscribeOpen(true)}
                onOpenReport={() => {
                  setReportTarget({ type: "stream", id: stream.id, label: stream.title });
                  setReportOpen(true);
                }}
                onOpenClip={() => setClipOpen(true)}
              />
            </div>

            {isWide && (
              <aside className="watch__chat" aria-label="Chat and polls">
                <PollStrip stream={stream} />
                {chatPanel}
              </aside>
            )}
          </div>

          {isWide ? (
            <>
              <StreamTabs stream={stream} user={user} />
              <div className="stream-secondary">
                <div className="stream-secondary__main">
                  <RelatedRail excludeId={stream.id} />
                </div>
                <ChannelCard stream={stream} />
              </div>
            </>
          ) : (
            <div className="mobile-switcher">
              <div className="mobile-switcher__tabs" role="tablist" aria-label="Stream panels">
                <button
                  role="tab"
                  aria-selected={mobileTab === "chat"}
                  className={cx("mobile-switcher__tab", mobileTab === "chat" && "is-active")}
                  onClick={() => setMobileTab("chat")}
                >
                  <IconChat size={15} /> Chat
                  {chat.unread > 0 && <span className="mobile-switcher__badge">{chat.unread}</span>}
                </button>
                <button
                  role="tab"
                  aria-selected={mobileTab === "details"}
                  className={cx("mobile-switcher__tab", mobileTab === "details" && "is-active")}
                  onClick={() => setMobileTab("details")}
                >
                  <IconGrid size={15} /> Details
                </button>
              </div>
              <div className="mobile-switcher__panel" role="tabpanel">
                {mobileTab === "chat" ? (
                  <>
                    <PollStrip stream={stream} />
                    {chatPanel}
                  </>
                ) : (
                  <>
                    <StreamTabs stream={stream} user={user} />
                    <ChannelCard stream={stream} />
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <ReportDialog
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        targetType={reportTarget.type}
        targetId={reportTarget.id}
        targetLabel={reportTarget.label}
      />
      <ClipDialog open={clipOpen} onClose={() => setClipOpen(false)} stream={stream} />
      <SubscribeDialog open={subscribeOpen} onClose={() => setSubscribeOpen(false)} channel={stream.channel} />
      <ShortcutsDialog open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />
      <SignInDialog open={signInOpen} onClose={() => setSignInOpen(false)} />

      {/* demo entry point kept reachable from the stream view */}
      <button className="demo-fab" onClick={onOpenDemo} aria-label="Open demo controls">
        <IconAlert size={15} />
        <span>Demo</span>
      </button>

      <div className="sr-only" role="status" aria-live="polite">
        {chat.status === "reconnecting" ? "Chat reconnecting" : ""}
      </div>
    </>
  );
}

/* -------------------------------------------------------------------------- */
/* page                                                                      */
/* -------------------------------------------------------------------------- */

export function StreamPage({
  slug,
  session,
  onOpenDemo,
}: {
  slug: string;
  session: AppSession | null;
  onOpenDemo: () => void;
}) {
  const demo = useDemoState();
  const toast = useToast();

  const stream = useAsync<Stream>(
    () => api.getStreamBySlug(slug),
    [slug, demo.persona, demo.forcedStreamState],
  );

  /* title carries the channel so tabs and history entries are identifiable */
  useEffect(() => {
    if (!stream.data) return;
    const s = stream.data;
    document.title =
      s.state === "live"
        ? `${s.channel.displayName} · ${s.title} · VANTA`
        : `${s.channel.displayName} · ${s.state === "ended" ? "Replay" : "Offline"} · VANTA`;
  }, [stream.data]);

  useEffect(() => {
    if (stream.error) {
      // a missing channel is a routing problem, not a retry loop
      if (stream.error.code === "not_found") {
        toast.error("Stream not found", "Check the channel name and try again.");
      }
    }
  }, [stream.error, toast]);

  if (stream.initialLoading) return <StreamPageSkeleton />;

  if (stream.error) {
    return (
      <div className="page-state">
        <ErrorState error={stream.error} onRetry={stream.reload} />
      </div>
    );
  }

  if (!stream.data) {
    return (
      <div className="page-state">
        <Spinner size={22} />
      </div>
    );
  }

  return (
    <PlayerProvider stream={stream.data}>
      <StreamExperience stream={stream.data} session={session} onOpenDemo={onOpenDemo} />
    </PlayerProvider>
  );
}
