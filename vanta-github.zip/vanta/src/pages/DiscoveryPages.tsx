import { useMemo } from "react";
import { api } from "../api/mockApi";
import type { AppSession, Stream } from "../types";
import { formatCount, formatRelative } from "../lib/utils";
import { routes } from "../lib/router";
import { useAsync } from "../state/useAsync";
import { useDemoState } from "../state/useDemo";
import { CategoryCard, StreamCard, type StreamCardData } from "../components/discovery/Cards";
import { CardSkeleton, EmptyState, ErrorState, LiveBadge, SectionHeading, Thumb } from "../components/ui/primitives";
import { IconCompass, IconHeart, IconLive, IconSearch } from "../components/icons";

export function toCardData(s: Stream): StreamCardData {
  return {
    slug: s.slug,
    title: s.title,
    channelName: s.channel.displayName,
    channelSlug: s.channel.slug,
    avatarUrl: s.channel.avatarUrl,
    verified: s.channel.verified,
    thumbnailUrl: s.playback?.posterUrl ?? s.channel.bannerUrl ?? null,
    categoryName: s.category?.name ?? null,
    viewerCount: s.viewerCount,
    tags: s.tags,
    isLive: s.state === "live",
    language: s.language,
    statusLabel:
      s.state === "ended" && s.endedAt
        ? `Ended ${formatRelative(s.endedAt)}`
        : s.state === "scheduled" && s.scheduledFor
          ? `Starts ${formatRelative(s.scheduledFor)}`
          : null,
  };
}

function Rail({ title, streams, loading }: { title: string; streams: Stream[]; loading: boolean }) {
  return (
    <section className="rail" aria-label={title}>
      <SectionHeading title={title} />
      <div className="rail__track">
        {loading
          ? Array.from({ length: 4 }, (_, i) => <CardSkeleton key={i} />)
          : streams.map((s) => <StreamCard key={s.id} data={toCardData(s)} />)}
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/* home                                                                       */
/* -------------------------------------------------------------------------- */

export function HomePage({ onOpenDemo }: { session: AppSession | null; onOpenDemo: () => void }) {
  const demo = useDemoState();
  const discovery = useAsync(() => api.getDiscovery(), [demo.persona, demo.forcedStreamState]);

  const featured = discovery.data?.following.find((s) => s.state === "live") ?? discovery.data?.recommended[0] ?? null;
  const liveCount = useMemo(
    () => (discovery.data ? [...discovery.data.following, ...discovery.data.recommended].filter((s) => s.state === "live").length : 0),
    [discovery.data],
  );

  if (discovery.error) {
    return (
      <div className="page-state">
        <ErrorState error={discovery.error} onRetry={discovery.reload} />
      </div>
    );
  }

  return (
    <div className="home">
      <section className="hero" aria-label="Featured stream">
        {featured ? (
          <a className="hero__card" href={routes.channel(featured.channel.slug)}>
            <Thumb src={featured.playback?.posterUrl ?? featured.channel.bannerUrl} alt="" priority className="hero__art" />
            <div className="hero__scrim" aria-hidden="true" />
            <div className="hero__content">
              <div className="hero__badges">
                <LiveBadge />
                <span className="chip chip--glass">{formatCount(featured.viewerCount)} watching</span>
                {featured.category && <span className="chip chip--glass">{featured.category.name}</span>}
              </div>
              <h1 className="hero__title">{featured.title}</h1>
              <p className="hero__channel">
                {featured.channel.displayName}
                <span className="hero__dot" aria-hidden="true">·</span>
                {featured.channel.followerCount.toLocaleString()} followers
              </p>
              <span className="btn btn--primary hero__cta">
                <IconLive size={16} /> Watch now
              </span>
            </div>
          </a>
        ) : (
          <div className="hero__empty">
            <span className="skeleton hero__art" />
            <div className="hero__content">
              <span className="eyebrow">Nothing live</span>
              <h1 className="hero__title">No featured stream right now</h1>
              <p className="hero__channel">Follow a channel and its next broadcast will show up here.</p>
              <a className="btn btn--ghost hero__cta" href={routes.browse()}>
                <IconCompass size={16} /> Browse categories
              </a>
            </div>
          </div>
        )}
      </section>

      <div className="home__meta">
        <span className="chip chip--accent">
          <IconLive size={12} /> {liveCount} live now
        </span>
        <button className="btn btn--quiet btn--sm" onClick={onOpenDemo}>
          Demo controls
        </button>
      </div>

      <Rail title="Following" streams={discovery.data?.following ?? []} loading={discovery.initialLoading} />
      <Rail title="Recommended live" streams={discovery.data?.recommended ?? []} loading={discovery.initialLoading} />

      <section className="rail" aria-label="Categories">
        <SectionHeading title="Categories" action={<a className="rail__more" href={routes.browse()}>See all</a>} />
        <div className="rail__track rail__track--cats">
          {(discovery.data?.categories ?? []).slice(0, 6).map((c) => (
            <CategoryCard key={c.id} category={c} />
          ))}
        </div>
      </section>

      <section className="rail" aria-label="Recently watched">
        <SectionHeading title="Recently watched" />
        {discovery.data?.recentlyWatched.length ? (
          <div className="home__recent">
            {discovery.data.recentlyWatched.map((c) => (
              <a key={c.id} className="home__recent-item" href={routes.channel(c.slug)}>
                {c.displayName}
              </a>
            ))}
          </div>
        ) : (
          <p className="rail__empty">Channels you watch will appear here.</p>
        )}
      </section>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* browse                                                                     */
/* -------------------------------------------------------------------------- */

export function BrowsePage({ category }: { category?: string }) {
  const demo = useDemoState();
  const discovery = useAsync(() => api.getDiscovery(), [demo.persona, demo.forcedStreamState]);
  const all = useMemo(
    () => (discovery.data ? [...discovery.data.following, ...discovery.data.recommended] : []),
    [discovery.data],
  );
  const active = discovery.data?.categories.find((c) => c.slug === category) ?? null;
  const filtered = category
    ? all.filter((s) => s.category?.slug === category)
    : all.filter((s) => s.state === "live");

  if (discovery.error) {
    return (
      <div className="page-state">
        <ErrorState error={discovery.error} onRetry={discovery.reload} />
      </div>
    );
  }

  return (
    <div className="browse">
      <header className="page-head">
        <div>
          <span className="eyebrow">Discover</span>
          <h1 className="page-head__title">{active ? active.name : "Browse live channels"}</h1>
        </div>
        <a className="btn btn--ghost btn--sm" href={routes.browse()}>
          <IconSearch size={14} /> All categories
        </a>
      </header>

      <div className="browse__cats">
        {(discovery.data?.categories ?? []).map((c) => (
          <a
            key={c.id}
            href={routes.browse(c.slug)}
            className={c.slug === category ? "browse__cat is-active" : "browse__cat"}
          >
            <Thumb src={c.artUrl} alt="" className="browse__cat-art" ratio="1 / 1" />
            <span className="browse__cat-name">{c.name}</span>
            <span className="browse__cat-count mono">{formatCount(c.viewers)}</span>
          </a>
        ))}
      </div>

      <section className="rail">
        <SectionHeading title={active ? `Live in ${active.name}` : "Live now"} />
        <div className="grid">
          {discovery.initialLoading
            ? Array.from({ length: 8 }, (_, i) => <CardSkeleton key={i} />)
            : filtered.map((s) => <StreamCard key={s.id} data={toCardData(s)} />)}
        </div>
        {!discovery.initialLoading && filtered.length === 0 && (
          <EmptyState
            icon={<IconLive size={22} />}
            title={category ? "Nobody is live in this category" : "No live channels"}
            description="Try another category, or check back later."
          />
        )}
      </section>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* following                                                                  */
/* -------------------------------------------------------------------------- */

export function FollowingPage({ session }: { session: AppSession | null }) {
  const demo = useDemoState();
  const discovery = useAsync(() => api.getDiscovery(), [demo.persona, demo.forcedStreamState]);
  const following = discovery.data?.following ?? [];
  const live = following.filter((s) => s.state === "live");
  const offline = following.filter((s) => s.state !== "live");

  if (!session?.user) {
    return (
      <div className="page-state">
        <EmptyState
          icon={<IconHeart size={22} />}
          title="Sign in to see who you follow"
          description="Your followed channels and their notification preferences live on your account."
        />
      </div>
    );
  }

  if (discovery.error) {
    return (
      <div className="page-state">
        <ErrorState error={discovery.error} onRetry={discovery.reload} />
      </div>
    );
  }

  return (
    <div className="following">
      <header className="page-head">
        <div>
          <span className="eyebrow">Your channels</span>
          <h1 className="page-head__title">Following</h1>
        </div>
        <span className="chip chip--accent">
          <IconLive size={12} /> {live.length} live
        </span>
      </header>

      {discovery.initialLoading ? (
        <div className="grid">{Array.from({ length: 4 }, (_, i) => <CardSkeleton key={i} />)}</div>
      ) : following.length === 0 ? (
        <EmptyState
          icon={<IconHeart size={22} />}
          title="You aren't following any channels"
          description="Follow a channel from its stream page to see it here."
          action={
            <a className="btn btn--primary btn--sm" href={routes.browse()}>
              Browse live channels
            </a>
          }
        />
      ) : (
        <>
          <section className="rail">
            <SectionHeading title="Live now" />
            <div className="grid">
              {live.map((s) => (
                <StreamCard key={s.id} data={toCardData(s)} />
              ))}
            </div>
            {live.length === 0 && <p className="rail__empty">None of your channels are live right now.</p>}
          </section>

          {offline.length > 0 && (
            <section className="rail">
              <SectionHeading title="Offline" />
              <div className="grid grid--compact">
                {offline.map((s) => (
                  <a key={s.id} className="offline-row" href={routes.channel(s.channel.slug)}>
                    <span className="offline-row__name">{s.channel.displayName}</span>
                    <span className="offline-row__state">{s.state}</span>
                  </a>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
