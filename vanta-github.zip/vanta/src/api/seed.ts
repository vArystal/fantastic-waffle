import type {
  Category,
  Channel,
  ChatMessage,
  Clip,
  Emote,
  Leaderboard,
  Poll,
  Prediction,
  RewardsState,
  ScheduleEntry,
  Stream,
  StreamGoal,
  SupportAlert,
  User,
  Vod,
} from "../types";

/**
 * Seeded demo dataset.
 *
 * Every record below is shaped exactly like the real API payload described in
 * `docs/API-INTEGRATION.md`. Media is generated locally (tools/gen_assets.py)
 * so the demo works with no network access.
 */

/**
 * Media lives in `public/media`, so it is copied into the build verbatim.
 * Resolve it against the app base rather than hard-coding a root-absolute path:
 * the same build then works at a domain root (`/media/...`) and under a GitHub
 * Pages project subpath (`/vanta/media/...`).
 */
const BASE = import.meta.env.BASE_URL.replace(/\/+$/, "");
const MEDIA = `${BASE}/media`;

/* -------------------------------------------------------------------------- */
/* clock helpers — the demo session is anchored to page load                  */
/* -------------------------------------------------------------------------- */

const T0 = Date.now();

export const isoAgo = (seconds: number) => new Date(T0 - seconds * 1000).toISOString();
export const isoAhead = (seconds: number) => new Date(T0 + seconds * 1000).toISOString();

/* -------------------------------------------------------------------------- */
/* categories                                                                 */
/* -------------------------------------------------------------------------- */

export const categories: Category[] = [
  { id: "cat_rift", slug: "rift-protocol", name: "Rift Protocol", artUrl: `${MEDIA}/categories/c00.jpg`, viewers: 214_800, tags: ["FPS", "Competitive"] },
  { id: "cat_hollow", slug: "hollow-circuit", name: "Hollow Circuit", artUrl: `${MEDIA}/categories/c01.jpg`, viewers: 96_400, tags: ["Roguelike", "Indie"] },
  { id: "cat_neon", slug: "neon-drift", name: "Neon Drift", artUrl: `${MEDIA}/categories/c02.jpg`, viewers: 58_100, tags: ["Racing", "Arcade"] },
  { id: "cat_aster", slug: "siege-of-aster", name: "Siege of Aster", artUrl: `${MEDIA}/categories/c03.jpg`, viewers: 143_700, tags: ["Strategy", "PvP"] },
  { id: "cat_tactical", slug: "tactical-ops-2", name: "Tactical Ops 2", artUrl: `${MEDIA}/categories/c04.jpg`, viewers: 302_900, tags: ["FPS", "Tactical"] },
  { id: "cat_speedrun", slug: "speedruns", name: "Speedruns", artUrl: `${MEDIA}/categories/c05.jpg`, viewers: 41_200, tags: ["Speedrun", "Variety"] },
  { id: "cat_chatting", slug: "just-chatting", name: "Just Chatting", artUrl: `${MEDIA}/categories/c06.jpg`, viewers: 512_300, tags: ["IRL", "Talk"] },
  { id: "cat_art", slug: "art", name: "Art & Design", artUrl: `${MEDIA}/categories/c07.jpg`, viewers: 27_500, tags: ["Creative"] },
];

const categoryById = new Map(categories.map((c) => [c.id, c]));
export const getCategory = (id: string | null) => (id ? categoryById.get(id) ?? null : null);

/* -------------------------------------------------------------------------- */
/* users                                                                      */
/* -------------------------------------------------------------------------- */

const AV = (i: number) => `${MEDIA}/avatars/a${String(i % 14).padStart(2, "0")}.jpg`;

export const demoUsers: Record<"self" | "streamer" | "mod" | "guest", User> = {
  self: {
    id: "usr_self",
    login: "you",
    displayName: "You",
    avatarUrl: AV(3),
    color: "#8b7cff",
    roles: ["subscriber"],
    verified: false,
  },
  streamer: {
    id: "usr_v0lt",
    login: "v0lt",
    displayName: "v0lt",
    avatarUrl: AV(0),
    color: "#f04452",
    roles: ["streamer"],
    verified: true,
  },
  mod: {
    id: "usr_kirin",
    login: "kirin.exe",
    displayName: "kirin.exe",
    avatarUrl: AV(1),
    color: "#36c98f",
    roles: ["moderator", "subscriber"],
    verified: false,
  },
  guest: {
    id: "usr_guest",
    login: "guest",
    displayName: "Guest",
    avatarUrl: null,
    color: "#9aa4b4",
    roles: ["guest"],
    verified: false,
  },
};

export interface ChatPersona extends User {
  badge: "streamer" | "moderator" | "subscriber" | "verified" | null;
  months?: number;
}

const personaSeeds: Array<[string, string, number, ChatPersona["badge"], number?]> = [
  ["n0va", "n0va", 2, "verified"],
  ["brk", "brk", 3, null],
  ["miko", "miko", 4, "subscriber", 14],
  ["shadez", "shadez", 5, null],
  ["lumen", "lumen", 6, "subscriber", 3],
  ["hexa", "hexa", 7, null],
  ["pixelpilot", "PixelPilot", 8, "verified"],
  ["glasscannon", "glasscannon", 9, null],
  ["riff_rat", "riff_rat", 10, "subscriber", 22],
  ["softlock", "softlock", 11, null],
  ["tape_deck", "TapeDeck", 12, null],
  ["voidwalker", "voidwalker", 13, "subscriber", 41],
  ["quietstorm", "quietstorm", 0, null],
  ["atlas_k", "atlas_k", 1, "subscriber", 7],
  ["nine_lives", "nine_lives", 2, null],
  ["gravetide", "gravetide", 3, null],
  ["circuit_breaker", "circuit_breaker", 4, "subscriber", 2],
  ["moth", "moth", 5, null],
  ["ceramic", "ceramic", 6, null],
  ["darkroom", "darkroom", 7, "subscriber", 11],
  ["slow_clap", "slowclap", 8, null],
  ["velocity", "velocity", 9, null],
  ["long_username_test", "xX_ShadowReaper_Overclocked_Xx", 10, null],
  ["sigil", "sigil", 11, "subscriber", 5],
];

const CHAT_COLORS = [
  "#f04452", "#ff8a5c", "#ffd257", "#8ee06a", "#46e0c0",
  "#6ca8ff", "#a68bff", "#e07aff", "#ff7ab8", "#9aa4b4",
];

export const chatPersonas: ChatPersona[] = personaSeeds.map(([login, displayName, av, badge, months], i) => ({
  id: `usr_${login}`,
  login,
  displayName,
  avatarUrl: AV(av),
  color: CHAT_COLORS[i % CHAT_COLORS.length],
  roles: badge === "subscriber" ? ["subscriber"] : ["viewer"],
  verified: badge === "verified",
  badge,
  months,
}));

/* -------------------------------------------------------------------------- */
/* channels                                                                   */
/* -------------------------------------------------------------------------- */

const schedule = (items: Array<[number, string, number, string, string]>): ScheduleEntry[] =>
  items.map(([dayOfWeek, startTime, durationMinutes, title, categoryName]) => ({
    dayOfWeek,
    startTime,
    durationMinutes,
    title,
    categoryName,
  }));

export const channels: Channel[] = [
  {
    id: "ch_v0lt",
    slug: "v0lt",
    displayName: "v0lt",
    avatarUrl: AV(0),
    bannerUrl: `${MEDIA}/thumbs/t00.jpg`,
    bio: "Ranked grinder. Rift Protocol main since the closed beta. I explain my rotations out loud, so the VOD is basically a free coaching session. No rage, no screaming — just very fast decisions.",
    verified: true,
    followerCount: 412_800,
    subscriberCount: 3_140,
    subscriptionsEnabled: true,
    socials: [
      { kind: "x", label: "@v0lt", href: "https://example.com/v0lt" },
      { kind: "youtube", label: "v0lt", href: "https://example.com/v0lt/yt" },
      { kind: "discord", label: "Voltroom", href: "https://example.com/discord" },
    ],
    categoryId: "cat_rift",
    language: "EN",
    schedule: schedule([
      [1, "19:00", 180, "Ranked ladder — climb to Ascendant", "Rift Protocol"],
      [3, "19:00", 180, "Scrim review + ladder", "Rift Protocol"],
      [5, "20:00", 240, "Community night — viewer queue", "Rift Protocol"],
      [6, "17:00", 120, "Chill: patch notes and coffee", "Just Chatting"],
    ]),
    createdAt: "2019-04-12T00:00:00.000Z",
    viewerIsFollowing: true,
    viewerFollowAlerts: "live",
  },
  {
    id: "ch_kirin",
    slug: "kirin",
    displayName: "kirin.exe",
    avatarUrl: AV(1),
    bannerUrl: `${MEDIA}/thumbs/t01.jpg`,
    bio: "Speedrunner, tool-assisted routing nerd, and the person who will explain frame data to you whether or not you asked.",
    verified: false,
    followerCount: 88_400,
    subscriberCount: 640,
    subscriptionsEnabled: true,
    socials: [{ kind: "x", label: "@kirin_exe", href: "https://example.com/kirin" }],
    categoryId: "cat_speedrun",
    language: "EN",
    schedule: schedule([
      [2, "18:30", 150, "Any% practice — Hollow Circuit", "Speedruns"],
      [4, "18:30", 150, "Any% practice — Hollow Circuit", "Speedruns"],
    ]),
    createdAt: "2020-11-02T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "all",
  },
  {
    id: "ch_n0va",
    slug: "n0va",
    displayName: "n0va",
    avatarUrl: AV(2),
    bannerUrl: `${MEDIA}/thumbs/t02.jpg`,
    bio: "Strategy first, mechanics second, tilt never. Siege of Aster coach. Occasionally streams the ladder with commentary.",
    verified: true,
    followerCount: 231_500,
    subscriberCount: 1_890,
    subscriptionsEnabled: true,
    socials: [{ kind: "youtube", label: "n0va", href: "https://example.com/nova" }],
    categoryId: "cat_aster",
    language: "EN",
    schedule: schedule([[0, "16:00", 180, "Ladder Sunday", "Siege of Aster"]]),
    createdAt: "2018-08-20T00:00:00.000Z",
    viewerIsFollowing: true,
    viewerFollowAlerts: "all",
  },
  {
    id: "ch_miko",
    slug: "miko",
    displayName: "miko",
    avatarUrl: AV(4),
    bannerUrl: `${MEDIA}/thumbs/t04.jpg`,
    bio: "Neon Drift time attack. Custom liveries. Loud music, quiet commentary.",
    verified: false,
    followerCount: 64_200,
    subscriberCount: null,
    subscriptionsEnabled: false,
    socials: [],
    categoryId: "cat_neon",
    language: "EN",
    schedule: schedule([[4, "21:00", 120, "Time attack Tuesday", "Neon Drift"]]),
    createdAt: "2021-02-14T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "none",
  },
  {
    id: "ch_brk",
    slug: "brk",
    displayName: "brk",
    avatarUrl: AV(5),
    bannerUrl: `${MEDIA}/thumbs/t05.jpg`,
    bio: "Tactical FPS, dry humour. I will absolutely tell you where you went wrong, kindly.",
    verified: false,
    followerCount: 152_900,
    subscriberCount: 980,
    subscriptionsEnabled: true,
    socials: [],
    categoryId: "cat_tactical",
    language: "EN",
    schedule: schedule([[5, "20:30", 180, "Ranked with the crew", "Tactical Ops 2"]]),
    createdAt: "2019-09-01T00:00:00.000Z",
    viewerIsFollowing: true,
    viewerFollowAlerts: "live",
  },
  {
    id: "ch_shadez",
    slug: "shadez",
    displayName: "shadez",
    avatarUrl: AV(6),
    bannerUrl: `${MEDIA}/thumbs/t06.jpg`,
    bio: "Horror and mature-rated titles. Not for younger viewers.",
    verified: false,
    followerCount: 39_800,
    subscriberCount: null,
    subscriptionsEnabled: false,
    socials: [],
    categoryId: "cat_hollow",
    language: "EN",
    schedule: [],
    createdAt: "2022-10-31T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "none",
  },
  {
    id: "ch_lumen",
    slug: "lumen",
    displayName: "lumen",
    avatarUrl: AV(7),
    bannerUrl: `${MEDIA}/thumbs/t07.jpg`,
    bio: "Illustration, mostly sci-fi environments. Long-form painting with the occasional tutorial.",
    verified: true,
    followerCount: 97_600,
    subscriberCount: 410,
    subscriptionsEnabled: true,
    socials: [{ kind: "instagram", label: "@lumen.draws", href: "https://example.com/lumen" }],
    categoryId: "cat_art",
    language: "EN",
    schedule: schedule([[2, "15:00", 240, "Environment study", "Art & Design"]]),
    createdAt: "2020-01-05T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "all",
  },
  {
    id: "ch_hexa",
    slug: "hexa",
    displayName: "hexa",
    avatarUrl: AV(8),
    bannerUrl: `${MEDIA}/thumbs/t08.jpg`,
    bio: "Variety. Weekly roguelike runs and patch-day streams.",
    verified: false,
    followerCount: 21_300,
    subscriberCount: null,
    subscriptionsEnabled: false,
    socials: [],
    categoryId: "cat_hollow",
    language: "DE",
    schedule: [],
    createdAt: "2023-03-18T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "none",
  },
  {
    id: "ch_pixelpilot",
    slug: "pixelpilot",
    displayName: "PixelPilot",
    avatarUrl: AV(9),
    bannerUrl: `${MEDIA}/thumbs/t09.jpg`,
    bio: "Indie first. I play everything once and finish nothing.",
    verified: true,
    followerCount: 134_700,
    subscriberCount: 720,
    subscriptionsEnabled: true,
    socials: [],
    categoryId: "cat_hollow",
    language: "EN",
    schedule: [],
    createdAt: "2017-06-22T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "all",
  },
  {
    id: "ch_velocity",
    slug: "velocity",
    displayName: "velocity",
    avatarUrl: AV(10),
    bannerUrl: `${MEDIA}/thumbs/t10.jpg`,
    bio: "Genuinely too fast to watch. Racing and speedruns.",
    verified: false,
    followerCount: 45_900,
    subscriberCount: null,
    subscriptionsEnabled: false,
    socials: [],
    categoryId: "cat_neon",
    language: "EN",
    schedule: [],
    createdAt: "2021-07-11T00:00:00.000Z",
    viewerIsFollowing: false,
    viewerFollowAlerts: "none",
  },
];

export const channelBySlug = (slug: string) => channels.find((c) => c.slug === slug) ?? null;

/* -------------------------------------------------------------------------- */
/* playback                                                                   */
/* -------------------------------------------------------------------------- */

const poster = (n: number) => `${MEDIA}/thumbs/t${String(n).padStart(2, "0")}.jpg`;

const demoPlayback = (posterUrl = poster(0)) => ({
  kind: "progressive" as const,
  renditions: [
    { id: "r720", label: "720p", height: 720, src: `${MEDIA}/demo/stream-720.mp4`, bitrateKbps: 1500 },
    { id: "r480", label: "480p", height: 480, src: `${MEDIA}/demo/stream-480.mp4`, bitrateKbps: 900 },
    { id: "r360", label: "360p", height: 360, src: `${MEDIA}/demo/stream-360.mp4`, bitrateKbps: 550 },
  ],
  captions: [
    { id: "cc_en", label: "English", language: "en", src: `${MEDIA}/demo/stream.en.vtt`, default: true },
  ],
  posterUrl,
  dvr: { enabled: true, windowSeconds: 26 },
  lowLatency: false,
  aspectRatio: "16 / 9",
});

/* -------------------------------------------------------------------------- */
/* streams                                                                    */
/* -------------------------------------------------------------------------- */

const trend = (base: number, seed: number) =>
  Array.from({ length: 30 }, (_, i) => {
    const wave = Math.sin((i + seed) / 3.1) * 0.06 + Math.sin((i + seed) / 8.7) * 0.04;
    return Math.round(base * (0.88 + (i / 30) * 0.14 + wave));
  });

const defaultChatSettings = {
  slowModeSeconds: 0,
  subscribersOnly: false,
  followersOnly: false,
  requiresVerifiedEmail: true,
};

export const streams: Stream[] = [
  {
    id: "st_v0lt",
    slug: "v0lt",
    title: "Ascendant push — game 3 of the climb, full rotation commentary (no cam)",
    channel: channels[0],
    category: categories[0],
    state: "live",
    startedAt: isoAgo(8_250),
    scheduledFor: null,
    endedAt: null,
    viewerCount: 24_837,
    language: "EN",
    tags: ["English", "Ranked", "NoBackseating", "Chill"],
    isMature: false,
    playback: demoPlayback(`${MEDIA}/demo/poster.jpg`),
    stats: { peakViewers: 26_940, followerGain: 412, viewerTrend: trend(24_837, 2) },
    chatSettings: { ...defaultChatSettings, slowModeSeconds: 3 },
    stateReason: null,
    viewerCanModerate: false,
    viewerCanCreateClip: true,
  },
  {
    id: "st_miko",
    slug: "miko",
    title: "Neon Drift — new livery showcase",
    channel: channels[3],
    category: categories[2],
    state: "live",
    startedAt: isoAgo(3_420),
    scheduledFor: null,
    endedAt: null,
    viewerCount: 1_284,
    language: "EN",
    tags: ["English", "Racing"],
    isMature: false,
    playback: demoPlayback(poster(4)),
    stats: { peakViewers: 1_512, followerGain: 38, viewerTrend: trend(1_284, 6) },
    chatSettings: { ...defaultChatSettings, slowModeSeconds: 0 },
    stateReason: null,
    viewerCanModerate: false,
    viewerCanCreateClip: true,
  },
  {
    id: "st_brk",
    slug: "brk",
    title: "Ranked with the crew — comms on, coaching mode",
    channel: channels[4],
    category: categories[4],
    state: "live",
    startedAt: isoAgo(5_640),
    scheduledFor: null,
    endedAt: null,
    viewerCount: 8_902,
    language: "EN",
    tags: ["English", "Tactical", "Comms"],
    isMature: false,
    playback: demoPlayback(poster(5)),
    stats: { peakViewers: 9_640, followerGain: 121, viewerTrend: trend(8_902, 9) },
    chatSettings: { ...defaultChatSettings },
    stateReason: null,
    viewerCanModerate: false,
    viewerCanCreateClip: false,
  },
  {
    id: "st_lumen",
    slug: "lumen",
    title: "Environment study — orbital station interior, part 4",
    channel: channels[6],
    category: categories[7],
    state: "live",
    startedAt: isoAgo(1_980),
    scheduledFor: null,
    endedAt: null,
    viewerCount: 2_147,
    language: "EN",
    tags: ["English", "Creative", "Art"],
    isMature: false,
    playback: demoPlayback(poster(7)),
    stats: { peakViewers: 2_410, followerGain: 64, viewerTrend: trend(2_147, 12) },
    chatSettings: { ...defaultChatSettings },
    stateReason: null,
    viewerCanModerate: false,
    viewerCanCreateClip: true,
  },
  {
    id: "st_kirin",
    slug: "kirin",
    title: "Hollow Circuit any% — route practice, splits on",
    channel: channels[1],
    category: categories[5],
    state: "scheduled",
    startedAt: null,
    scheduledFor: isoAhead(5_400),
    endedAt: null,
    viewerCount: 0,
    language: "EN",
    tags: ["English", "Speedrun"],
    isMature: false,
    playback: null,
    stats: { peakViewers: 0, followerGain: 0, viewerTrend: [] },
    chatSettings: { ...defaultChatSettings },
    stateReason: null,
    viewerCanModerate: false,
    viewerCanCreateClip: false,
  },
  {
    id: "st_n0va",
    slug: "n0va",
    title: "Ladder Sunday — Siege of Aster",
    channel: channels[2],
    category: categories[3],
    state: "offline",
    startedAt: null,
    scheduledFor: isoAhead(86_400),
    endedAt: isoAgo(64_800),
    viewerCount: 0,
    language: "EN",
    tags: ["English", "Strategy"],
    isMature: false,
    playback: null,
    stats: { peakViewers: 0, followerGain: 0, viewerTrend: [] },
    chatSettings: { ...defaultChatSettings },
    stateReason: "This channel is offline. The last broadcast ended 18 hours ago.",
    viewerCanModerate: false,
    viewerCanCreateClip: false,
  },
  {
    id: "st_shadez",
    slug: "shadez",
    title: "Hollow Circuit — nightmare run (mature)",
    channel: channels[5],
    category: categories[1],
    state: "restricted",
    startedAt: isoAgo(1_200),
    scheduledFor: null,
    endedAt: null,
    viewerCount: 640,
    language: "EN",
    tags: ["English", "Horror", "Mature"],
    isMature: true,
    playback: null,
    stats: { peakViewers: 700, followerGain: 9, viewerTrend: trend(640, 15) },
    chatSettings: { ...defaultChatSettings },
    stateReason:
      "This stream is marked mature. You need a verified account with the mature-content setting enabled to watch it.",
    viewerCanModerate: false,
    viewerCanCreateClip: false,
  },
  {
    id: "st_ended",
    slug: "velocity",
    title: "Neon Drift — 100% livery unlock run",
    channel: channels[9],
    category: categories[2],
    state: "ended",
    startedAt: isoAgo(16_200),
    scheduledFor: null,
    endedAt: isoAgo(3_600),
    viewerCount: 0,
    language: "EN",
    tags: ["English", "Racing"],
    isMature: false,
    playback: demoPlayback(poster(10)),
    stats: { peakViewers: 3_940, followerGain: 210, viewerTrend: [] },
    chatSettings: { ...defaultChatSettings },
    stateReason: "The broadcast ended an hour ago. The replay is available below.",
    viewerCanModerate: false,
    viewerCanCreateClip: false,
  },
];

export const streamById = (id: string) => streams.find((s) => s.id === id) ?? null;
export const streamBySlug = (slug: string) => streams.find((s) => s.slug === slug) ?? null;

/* -------------------------------------------------------------------------- */
/* chat                                                                       */
/* -------------------------------------------------------------------------- */

const CHAT_SCRIPT: Array<[string, string, number, string?]> = [
  ["miko", "that rotation into the second wave was disgusting", 312, "n0va"],
  ["n0va", "he pre-aimed the corridor before the audio cue, watch it again", 300],
  ["brk", "chat is going to call that lucky lol", 286],
  ["hexa", "it is not luck if you do it every single game", 271],
  ["riff_rat", ":pog: that flick", 258],
  ["lumen", "the lighting on this map still holds up", 244],
  ["shadez", "any chance of a viewer queue tonight?", 231],
  ["softlock", "asking the real questions", 219],
  ["circuit_breaker", ":gg: clean", 205],
  ["tape_deck", "what sens are you on", 190],
  ["velocity", "the answer is always 'low'", 178],
  ["moth", "day 41 of asking for a livery tutorial", 165],
  ["ceramic", "the answer is always 'low' but also stop asking", 152],
  ["darkroom", "the wave 3 spawn pattern changed in the last patch right?", 140],
  ["voidwalker", "yes, they shortened the telegraph by 200ms", 128],
  ["pixelpilot", "that is why the first attempt looked off", 116],
  ["glasscannon", "unplayable, literally unplayable", 104],
  ["nine_lives", ":lul: unplayable but he is top 100", 96],
  ["quietstorm", "mods can we get the clip of the corridor hold", 88],
  ["atlas_k", "seconded", 80],
  ["slow_clap", "clipped it, posting in a sec", 70],
  ["long_username_test", "genuinely the cleanest read of the round so far, the audio cue happens before the portal even finishes opening", 58],
  ["sigil", "long message guy is back", 46],
  ["gravetide", ":clutch:", 40],
  ["miko", "ok that was actually insane", 33],
  ["brk", "chat behaviour is immaculate today", 22],
  ["n0va", "anyone else seeing the fps counter dip", 12],
  ["hexa", "dips to 140, unacceptable", 4],
];

const resolveAuthor = (login: string): User | null => {
  if (login === "v0lt") return demoUsers.streamer;
  if (login === "kirin.exe") return demoUsers.mod;
  return chatPersonas.find((p) => p.login === login) ?? null;
};

const badgesFor = (user: User | null): ChatMessage["badges"] => {
  if (!user) return [];
  const badges: ChatMessage["badges"] = [];
  if (user.roles.includes("streamer")) badges.push({ kind: "streamer" });
  else if (user.roles.includes("moderator")) badges.push({ kind: "moderator" });
  else if (user.roles.includes("subscriber")) {
    const persona = chatPersonas.find((p) => p.login === user.login);
    badges.push({ kind: "subscriber", label: persona?.months ? `${persona.months}m` : undefined });
  }
  if (user.verified) badges.push({ kind: "verified" });
  return badges;
};

const EMOTE_CODES = ["gg", "pog", "lul", "rip", "ez", "clutch", "hype", "noob"];

const detectEmotes = (text: string): string[] => {
  const found = new Set<string>();
  for (const token of text.split(/\s+/)) {
    const code = token.replace(/^:|:$/g, "").toLowerCase();
    if (EMOTE_CODES.includes(code) && /^:[a-z]+:$/.test(token)) found.add(code);
  }
  return [...found];
};

const detectMentions = (text: string): ChatMessage["mentions"] => {
  const out: ChatMessage["mentions"] = [];
  for (const m of text.matchAll(/@([a-z0-9_.]+)/gi)) {
    const login = m[1].toLowerCase();
    const persona = chatPersonas.find((p) => p.login === login);
    if (persona) out.push({ login: persona.login, displayName: persona.displayName });
  }
  return out;
};

export interface SeedChat {
  messages: ChatMessage[];
  pinned: ChatMessage | null;
}

export function seedChat(streamId: string): SeedChat {
  const messages: ChatMessage[] = [];
  const now = Date.now();

  messages.push({
    id: "sys_1",
    streamId,
    author: null,
    kind: "announcement",
    text: "Welcome to the channel. Slow mode is on (3s). Be kind, no backseating.",
    createdAt: new Date(now - 900_000).toISOString(),
    badges: [],
    replyTo: null,
    emotes: [],
    mentions: [],
    isPinned: false,
    canDelete: false,
    deletedBy: null,
  });

  CHAT_SCRIPT.forEach(([login, text, secondsAgo, replyLogin], i) => {
    const author = resolveAuthor(login);
    if (!author) return;
    const replyTo = replyLogin
      ? (() => {
          const target = chatPersonas.find((p) => p.login === replyLogin) ??
            (replyLogin === "n0va" ? chatPersonas[0] : null);
          if (!target) return null;
          return { id: `msg_${i - 1}`, displayName: target.displayName, text: "…" };
        })()
      : null;

    messages.push({
      id: `msg_${i}`,
      streamId,
      author,
      kind: "chat",
      text,
      createdAt: new Date(now - secondsAgo * 1000).toISOString(),
      badges: badgesFor(author),
      replyTo,
      emotes: detectEmotes(text),
      mentions: detectMentions(text),
      isPinned: false,
      canDelete: false,
      deletedBy: null,
    });
  });

  // fixed moderation + subscription system notes
  messages.splice(6, 0, {
    id: "sys_mod_1",
    streamId,
    author: null,
    kind: "moderation",
    text: "kirin.exe timed out @spamposter for 600s — repeated links.",
    createdAt: new Date(now - 260_000).toISOString(),
    badges: [],
    replyTo: null,
    emotes: [],
    mentions: [],
    isPinned: false,
    canDelete: false,
    deletedBy: null,
  });
  messages.splice(14, 0, {
    id: "sys_sub_1",
    streamId,
    author: null,
    kind: "subscription",
    text: "riff_rat subscribed for 22 months. Thank you!",
    createdAt: new Date(now - 150_000).toISOString(),
    badges: [],
    replyTo: null,
    emotes: [],
    mentions: [],
    isPinned: false,
    canDelete: false,
    deletedBy: null,
  });

  const pinnedId = "msg_1";
  const pinned = messages.find((m) => m.id === pinnedId) ?? messages[1];
  if (pinned) pinned.isPinned = true;

  return { messages, pinned: pinned ?? null };
}

/* -------------------------------------------------------------------------- */
/* discovery, clips, vods                                                     */
/* -------------------------------------------------------------------------- */

export const clips: Clip[] = [
  { id: "clip_1", title: "Corridor hold — 4 enemies, no reload", thumbnailUrl: `${MEDIA}/thumbs/t11.jpg`, durationSeconds: 28, viewCount: 41_200, createdAt: isoAgo(1_800), creatorDisplayName: "slow_clap", gameName: "Rift Protocol" },
  { id: "clip_2", title: "this flick should not be possible", thumbnailUrl: `${MEDIA}/thumbs/t12.jpg`, durationSeconds: 12, viewCount: 18_400, createdAt: isoAgo(7_400), creatorDisplayName: "miko", gameName: "Rift Protocol" },
  { id: "clip_3", title: "wave 3 spawn read, explained in 20s", thumbnailUrl: `${MEDIA}/thumbs/t13.jpg`, durationSeconds: 22, viewCount: 9_120, createdAt: isoAgo(18_000), creatorDisplayName: "voidwalker", gameName: "Rift Protocol" },
  { id: "clip_4", title: "the 200ms telegraph change", thumbnailUrl: `${MEDIA}/thumbs/t14.jpg`, durationSeconds: 34, viewCount: 6_300, createdAt: isoAgo(39_000), creatorDisplayName: "n0va", gameName: "Rift Protocol" },
];

export const vods: Vod[] = [
  { id: "vod_1", title: "Ascendant push — full session, 5h 12m", thumbnailUrl: `${MEDIA}/thumbs/t15.jpg`, durationSeconds: 18_720, viewCount: 62_100, publishedAt: isoAgo(93_600), categoryName: "Rift Protocol" },
  { id: "vod_2", title: "Scrim review with n0va", thumbnailUrl: `${MEDIA}/thumbs/t16.jpg`, durationSeconds: 7_260, viewCount: 28_900, publishedAt: isoAgo(260_000), categoryName: "Rift Protocol" },
  { id: "vod_3", title: "Patch day — new map first look", thumbnailUrl: `${MEDIA}/thumbs/t17.jpg`, durationSeconds: 11_400, viewCount: 44_800, publishedAt: isoAgo(604_000), categoryName: "Rift Protocol" },
  { id: "vod_4", title: "Community night — viewer queue", thumbnailUrl: `${MEDIA}/thumbs/t02.jpg`, durationSeconds: 14_180, viewCount: 19_300, publishedAt: isoAgo(950_000), categoryName: "Rift Protocol" },
];

export const emotes: Emote[] = EMOTE_CODES.map((code) => ({
  id: `em_${code}`,
  code,
  url: `${MEDIA}/emotes/${code}.png`,
  subscriberOnly: code === "clutch",
}));

/* -------------------------------------------------------------------------- */
/* widgets                                                                    */
/* -------------------------------------------------------------------------- */

export const seedPoll = (streamId: string): Poll => ({
  id: "poll_1",
  streamId,
  question: "Next game?",
  options: [
    { id: "po_1", label: "Keep climbing ranked", votes: 1_842 },
    { id: "po_2", label: "Viewer queue customs", votes: 1_204 },
    { id: "po_3", label: "Patch notes review", votes: 604 },
  ],
  status: "open",
  createdAt: isoAgo(600),
  closesAt: isoAhead(240),
  totalVotes: 3_650,
  viewerVote: null,
  canClose: false,
  createdBy: "v0lt",
});

export const seedPrediction = (streamId: string): Prediction => ({
  id: "pred_1",
  streamId,
  question: "Does the win streak survive this game?",
  outcomes: [
    { id: "pr_yes", label: "Yes — streak continues", color: "blue", points: 1.42, entries: 2_104 },
    { id: "pr_no", label: "No — streak ends", color: "pink", points: 3.1, entries: 940 },
  ],
  status: "open",
  locksAt: isoAhead(300),
  resolvedOutcomeId: null,
  viewerEntry: null,
  spendEnabled: false,
});

export const seedGoals: StreamGoal[] = [
  { id: "goal_subs", kind: "subscribers", label: "3,500 subscribers", current: 3_140, target: 3_500, unit: null, visibility: "public" },
  { id: "goal_followers", kind: "followers", label: "450K followers", current: 412_800, target: 450_000, unit: null, visibility: "public" },
];

export const seedLeaderboard = (): Leaderboard => ({
  id: "lb_supporters",
  title: "Top supporters",
  period: "week",
  metric: "points",
  viewerOptedOut: false,
  entries: [
    ["usr_riff_rat", "riff_rat", "riff_rat", 3, 18_420],
    ["usr_voidwalker", "voidwalker", "voidwalker", 13, 14_110],
    ["usr_darkroom", "darkroom", "darkroom", 7, 11_940],
    ["usr_miko", "miko", "miko", 4, 9_880],
    ["usr_atlas_k", "atlas_k", "atlas_k", 1, 7_260],
    ["usr_sigil", "sigil", "sigil", 11, 6_004],
    ["usr_circuit_breaker", "circuit_breaker", "circuit_breaker", 4, 5_120],
    ["usr_self", "you", "You", 3, 3_410],
  ].map(([id, login, displayName, av, score], i) => ({
    rank: i + 1,
    user: {
      id: String(id),
      login: String(login),
      displayName: String(displayName),
      avatarUrl: AV(Number(av)),
      color: CHAT_COLORS[i % CHAT_COLORS.length],
    },
    score: Number(score),
    metric: "points",
    isSelf: id === "usr_self",
    anonymous: false,
  })),
});

export const seedRewards = (): RewardsState => ({
  balance: 3_410,
  lifetimeEarned: 41_920,
  redemptionEnabled: false,
  rewards: [
    {
      id: "rw_highlight",
      title: "Highlight my message",
      description: "Pins your next message to the top of chat for 5 minutes.",
      cost: 2_000,
      cooldownSeconds: 900,
      stock: null,
      unavailableReason: null,
    },
    {
      id: "rw_emote",
      title: "Unlock subscriber emote",
      description: "Temporarily unlocks the :clutch: emote for this session.",
      cost: 5_000,
      cooldownSeconds: 3_600,
      stock: 12,
      unavailableReason: null,
    },
    {
      id: "rw_queue",
      title: "Jump the viewer queue",
      description: "Priority slot in the next community game.",
      cost: 8_000,
      cooldownSeconds: 0,
      stock: 0,
      unavailableReason: "Out of stock for this session.",
    },
    {
      id: "rw_vod",
      title: "Request a VOD review",
      description: "The streamer reviews one clip of your play next stream.",
      cost: 12_000,
      cooldownSeconds: 0,
      stock: 3,
      unavailableReason: null,
    },
  ],
});

export const seedAlerts = (): SupportAlert[] => [
  { id: "al_1", kind: "subscription", displayName: "riff_rat", detail: "resubscribed for 22 months", createdAt: isoAgo(150), amountLabel: null },
  { id: "al_2", kind: "gift", displayName: "voidwalker", detail: "gifted 5 subs to the community", createdAt: isoAgo(890), amountLabel: null },
  { id: "al_3", kind: "donation", displayName: "darkroom", detail: "tipped", createdAt: isoAgo(2_300), amountLabel: "€10.00" },
];
