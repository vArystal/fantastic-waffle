/**
 * Mock implementation of the VANTA API contract.
 *
 * Rules this file follows (they matter more than the mock data itself):
 *  1. Every mutation validates *on the server side*, using the session role —
 *     never a flag passed in by the caller.
 *  2. Failures are typed `ApiError`s with the codes the real API will use, so
 *     the UI's error handling does not need rewriting when the backend lands.
 *  3. Mutations are idempotent/guarded: duplicate votes, duplicate follows and
 *     duplicate messages are rejected with `conflict` rather than silently
 *     applied twice.
 *  4. Nothing financial is simulated as a client-side decoration: redemptions
 *     and prediction wagers return `unsupported` until a real economy service
 *     exists.
 */
import {
  ApiError,
  type AppSession,
  type Channel,
  type ChatHistoryPage,
  type ChatMessage,
  type Clip,
  type Emote,
  type FollowAlerts,
  type Leaderboard,
  type Poll,
  type Prediction,
  type RewardsState,
  type SearchResults,
  type Stream,
  type StreamGoal,
  type StreamState,
  type SupportAlert,
  type User,
} from "../types";
import { demoStore, type NetworkProfile, type PersonaId } from "./demo";
import {
  categories,
  channels,
  chatPersonas,
  clips,
  demoUsers,
  emotes,
  seedAlerts,
  seedChat,
  seedGoals,
  seedLeaderboard,
  seedPoll,
  seedPrediction,
  seedRewards,
  streamBySlug,
  streams,
  vods,
} from "./seed";

/* -------------------------------------------------------------------------- */
/* helpers                                                                    */
/* -------------------------------------------------------------------------- */

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function latency(): number {
  switch (demoStore.get().network) {
    case "slow":
      return 900 + Math.random() * 900;
    case "flaky":
      return 250 + Math.random() * 350;
    default:
      return 120 + Math.random() * 200;
  }
}

async function transport(): Promise<void> {
  const profile: NetworkProfile = demoStore.get().network;
  await sleep(latency());
  if (profile === "offline") {
    throw new ApiError("network", "You appear to be offline. Check your connection and try again.", 0);
  }
  if (profile === "flaky" && Math.random() < 0.28) {
    throw new ApiError("network", "The request could not be completed. Please retry.", 0);
  }
}

/** Session resolution — the single source of truth for permissions. */
export function currentUser(): User | null {
  const persona: PersonaId = demoStore.get().persona;
  switch (persona) {
    case "guest":
      return null;
    case "streamer":
      return { ...demoUsers.streamer, isSelf: false };
    case "moderator":
      return demoUsers.mod;
    case "viewer":
      return { ...demoUsers.self, roles: ["viewer"], color: "#6ca8ff" };
    default:
      return demoUsers.self;
  }
}

const hasRole = (roles: string[], ...needed: string[]) => needed.some((r) => roles.includes(r));

function requireAuth(): User {
  const user = currentUser();
  if (!user) throw new ApiError("unauthenticated", "Sign in to do that.", 401);
  return user;
}

function requireModerator(): User {
  const user = requireAuth();
  if (!hasRole(user.roles, "moderator", "streamer")) {
    throw new ApiError("forbidden", "You do not have permission to moderate this channel.", 403);
  }
  return user;
}

function requireStreamer(): User {
  const user = requireAuth();
  if (!hasRole(user.roles, "streamer")) {
    throw new ApiError("forbidden", "Only the broadcaster can do that.", 403);
  }
  return user;
}

/* -------------------------------------------------------------------------- */
/* persisted viewer preferences                                               */
/* -------------------------------------------------------------------------- */

const LS = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : fallback;
    } catch {
      return fallback;
    }
  },
  set(key: string, value: unknown) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* ignore quota errors */
    }
  },
};

const FOLLOW_KEY = "vanta.follows.v1";
type FollowRecord = { following: boolean; alerts: FollowAlerts };

const followState = new Map<string, FollowRecord>(
  Object.entries(
    LS.get<Record<string, FollowRecord>>(FOLLOW_KEY, {
      ch_v0lt: { following: true, alerts: "live" },
      ch_n0va: { following: true, alerts: "all" },
      ch_brk: { following: true, alerts: "live" },
    }),
  ),
);

const persistFollows = () =>
  LS.set(FOLLOW_KEY, Object.fromEntries(followState.entries()));

/**
 * Channels whose seeded follower count already includes this viewer, because
 * they start out followed. The count must stay consistent across
 * follow → unfollow → follow, so we track the viewer separately instead of
 * adding ±1 to whatever the seed says.
 */
const SEED_FOLLOWED = new Set(["ch_v0lt", "ch_n0va", "ch_brk"]);

function followerCountFor(channelId: string, seedCount: number): number {
  const base = seedCount - (SEED_FOLLOWED.has(channelId) ? 1 : 0);
  return base + (followState.get(channelId)?.following ? 1 : 0);
}

const WATCHED_KEY = "vanta.watched.v1";
const watchedState = new Map<string, string>(
  Object.entries(LS.get<Record<string, string>>(WATCHED_KEY, {
    ch_kirin: new Date(Date.now() - 86_400_000).toISOString(),
    ch_miko: new Date(Date.now() - 172_800_000).toISOString(),
  })),
);

/* -------------------------------------------------------------------------- */
/* in-memory mutable server state                                             */
/* -------------------------------------------------------------------------- */

const chatRooms = new Map<string, ChatMessage[]>();
const pinnedByStream = new Map<string, ChatMessage | null>();
const polls = new Map<string, Poll>();
const predictions = new Map<string, Prediction>();
const goals = new Map<string, StreamGoal[]>();
const alerts = new Map<string, SupportAlert[]>();
const leaderboardOptOut = { value: LS.get<boolean>("vanta.lb.optout", false) };

function room(streamId: string): ChatMessage[] {
  let r = chatRooms.get(streamId);
  if (!r) {
    const seeded = seedChat(streamId);
    r = seeded.messages;
    chatRooms.set(streamId, r);
    pinnedByStream.set(streamId, seeded.pinned);
  }
  return r;
}

/** broadcast bus — the mock equivalent of a WebSocket fan-out */
type ChatEvent =
  | { type: "message"; message: ChatMessage }
  | { type: "update"; message: ChatMessage }
  | { type: "remove"; id: string }
  | { type: "clear" }
  | { type: "pin"; message: ChatMessage | null }
  | { type: "poll"; poll: Poll }
  | { type: "alert"; alert: SupportAlert }
  | { type: "connection"; status: ChatConnectionStatus };

export type ChatConnectionStatus = "connecting" | "connected" | "reconnecting" | "disconnected";

const chatListeners = new Map<string, Set<(e: ChatEvent) => void>>();

function emit(streamId: string, event: ChatEvent) {
  chatListeners.get(streamId)?.forEach((fn) => fn(event));
}

/* -------------------------------------------------------------------------- */
/* moderation config                                                          */
/* -------------------------------------------------------------------------- */

const MODERATION = {
  maxLength: 500,
  bannedWords: ["free-followers", "buyviews", "kamikazefollow"],
  blockLinks: true,
  duplicateWindowMs: 20_000,
  minIntervalMs: 700,
};

const lastSendByUser = new Map<string, { at: number; text: string }>();

/** every account the moderation endpoints can act on */
function findModerationTarget(userId: string): User | null {
  return (
    chatPersonas.find((p) => p.id === userId) ??
    [demoUsers.mod, demoUsers.streamer, demoUsers.self].find((u) => u.id === userId) ??
    null
  );
}

/* -------------------------------------------------------------------------- */
/* stream projection                                                          */
/* -------------------------------------------------------------------------- */

function withViewerState(stream: Stream): Stream {
  const user = currentUser();
  const forced = demoStore.get().forcedStreamState;
  const state: StreamState = forced === "auto" ? stream.state : forced;
  const next: Stream = {
    ...stream,
    state,
    playback: state === "live" || state === "ended" ? stream.playback : null,
    viewerCanModerate: !!user && hasRole(user.roles, "moderator", "streamer"),
    viewerCanCreateClip: !!user && (state === "live" || state === "ended") && stream.playback !== null,
    channel: {
      ...stream.channel,
      followerCount: followerCountFor(stream.channel.id, stream.channel.followerCount),
      viewerIsFollowing: followState.get(stream.channel.id)?.following ?? false,
      viewerFollowAlerts: followState.get(stream.channel.id)?.alerts ?? "all",
    },
  };
  if (state === "offline" && !next.stateReason) {
    next.stateReason = "This channel is offline right now.";
  }
  if (state === "live" && !stream.playback) {
    // a live stream without a source is a real state, not an error to hide
    next.playback = null;
    next.stateReason = "The broadcaster is live but no playback source is published yet.";
  }
  return next;
}

/* -------------------------------------------------------------------------- */
/* API                                                                        */
/* -------------------------------------------------------------------------- */

export interface VantaApi {
  /* session ------------------------------------------------------------- */
  getSession(): Promise<AppSession>;

  /* streams ------------------------------------------------------------- */
  getStreamBySlug(slug: string): Promise<Stream>;
  getChatHistory(streamId: string, beforeId?: string | null): Promise<ChatHistoryPage>;

  /* channel ------------------------------------------------------------- */
  getChannel(slug: string): Promise<Channel>;
  setFollow(channelId: string, following: boolean): Promise<{ following: boolean; followerCount: number }>;
  setFollowAlerts(channelId: string, alerts: FollowAlerts): Promise<{ alerts: FollowAlerts }>;
  markWatched(channelId: string): Promise<void>;

  /* discovery ----------------------------------------------------------- */
  getDiscovery(): Promise<{
    following: Stream[];
    recommended: Stream[];
    recentlyWatched: Channel[];
    categories: typeof categories;
  }>;
  search(query: string): Promise<SearchResults>;

  /* chat ---------------------------------------------------------------- */
  sendMessage(streamId: string, text: string, replyTo?: ChatMessage["replyTo"]): Promise<ChatMessage>;
  deleteMessage(streamId: string, messageId: string): Promise<void>;
  clearChat(streamId: string): Promise<void>;
  pinMessage(streamId: string, messageId: string | null): Promise<ChatMessage | null>;
  timeoutUser(streamId: string, userId: string, seconds: number, reason?: string): Promise<void>;
  banUser(streamId: string, userId: string): Promise<void>;
  getPinned(streamId: string): Promise<ChatMessage | null>;

  /* widgets ------------------------------------------------------------- */
  getPoll(streamId: string): Promise<Poll>;
  votePoll(pollId: string, optionId: string): Promise<Poll>;
  closePoll(pollId: string): Promise<Poll>;
  createPoll(streamId: string, question: string, options: string[]): Promise<Poll>;
  getPrediction(streamId: string): Promise<Prediction>;
  enterPrediction(predictionId: string, outcomeId: string): Promise<Prediction>;
  getGoals(streamId: string): Promise<StreamGoal[]>;
  getLeaderboard(streamId: string): Promise<Leaderboard>;
  setLeaderboardOptOut(optOut: boolean): Promise<Leaderboard>;
  getRewards(streamId: string): Promise<RewardsState>;
  redeemReward(rewardId: string): Promise<RewardsState>;
  getAlerts(streamId: string): Promise<SupportAlert[]>;

  /* content ------------------------------------------------------------- */
  getClips(channelId: string): Promise<Clip[]>;
  getVods(channelId: string): Promise<typeof vods>;
  createClip(input: { streamId: string; startSeconds: number; endSeconds: number; title: string }): Promise<Clip>;
  getEmotes(): Promise<Emote[]>;

  /* safety -------------------------------------------------------------- */
  report(input: { targetType: "stream" | "channel" | "chat_message"; targetId: string; reason: string; details: string }): Promise<{ id: string }>;
}

class MockApi implements VantaApi {
  async getSession(): Promise<AppSession> {
    await transport();
    const user = currentUser();
    return { user, canGoLive: !!user && hasRole(user.roles, "streamer") };
  }

  async getStreamBySlug(slug: string): Promise<Stream> {
    await transport();
    const stream = streamBySlug(slug);
    if (!stream) throw new ApiError("not_found", "That stream does not exist.", 404);
    return withViewerState(stream);
  }

  async getChatHistory(streamId: string, beforeId?: string | null): Promise<ChatHistoryPage> {
    await transport();
    const all = room(streamId);
    const anchor = beforeId ? all.findIndex((m) => m.id === beforeId) : all.length;
    const end = anchor === -1 ? all.length : anchor;
    const start = Math.max(0, end - 25);
    return {
      messages: all.slice(start, end).map((m) => ({ ...m, canDelete: this.canDelete(m) })),
      olderCursor: start > 0 ? all[start].id : null,
    };
  }

  private canDelete(message: ChatMessage): boolean {
    const user = currentUser();
    if (!user) return false;
    if (hasRole(user.roles, "moderator", "streamer")) return true;
    return message.author?.id === user.id;
  }

  async getChannel(slug: string): Promise<Channel> {
    await transport();
    const channel = channels.find((c) => c.slug === slug);
    if (!channel) throw new ApiError("not_found", "Channel not found.", 404);
    const follow = followState.get(channel.id);
    return {
      ...channel,
      followerCount: followerCountFor(channel.id, channel.followerCount),
      viewerIsFollowing: follow?.following ?? false,
      viewerFollowAlerts: follow?.alerts ?? "all",
      lastWatchedAt: watchedState.get(channel.id) ?? null,
    };
  }

  async setFollow(channelId: string, following: boolean) {
    await transport();
    requireAuth();
    const channel = channels.find((c) => c.id === channelId);
    if (!channel) throw new ApiError("not_found", "Channel not found.", 404);

    const current = followState.get(channelId)?.following ?? false;
    if (current === following) {
      // no-op rather than double-counting; the UI should not have offered it
      throw new ApiError("conflict", following ? "You already follow this channel." : "You are not following this channel.", 409);
    }

    if (following && followState.size >= 100) {
      throw new ApiError("validation_failed", "You have reached the 100 channel follow limit.", 422);
    }

    followState.set(channelId, {
      following,
      alerts: followState.get(channelId)?.alerts ?? "all",
    });
    persistFollows();
    return {
      following,
      followerCount: followerCountFor(channelId, channel.followerCount),
    };
  }

  async setFollowAlerts(channelId: string, alerts: FollowAlerts) {
    await transport();
    requireAuth();
    const record = followState.get(channelId);
    if (!record?.following) {
      throw new ApiError("validation_failed", "Follow the channel before changing notifications.", 422);
    }
    followState.set(channelId, { ...record, alerts });
    persistFollows();
    return { alerts };
  }

  async markWatched(channelId: string) {
    watchedState.set(channelId, new Date().toISOString());
    LS.set(WATCHED_KEY, Object.fromEntries(watchedState.entries()));
  }

  async getDiscovery() {
    await transport();
    const project = (s: Stream) => withViewerState(s);
    const following = streams
      .filter((s) => followState.get(s.channel.id)?.following)
      .map(project);
    const recommended = streams
      .filter((s) => !followState.get(s.channel.id)?.following && s.state === "live")
      .map(project);
    const recentlyWatched = [...watchedState.entries()]
      .sort((a, b) => b[1].localeCompare(a[1]))
      .map(([id]) => channels.find((c) => c.id === id))
      .filter((c): c is Channel => Boolean(c));
    return { following, recommended, recentlyWatched, categories };
  }

  async search(query: string): Promise<SearchResults> {
    await transport();
    const q = query.trim().toLowerCase();
    if (!q) return { channels: [], categories: [], streams: [] };
    return {
      channels: channels.filter(
        (c) => c.displayName.toLowerCase().includes(q) || c.slug.includes(q),
      ),
      categories: categories.filter(
        (c) => c.name.toLowerCase().includes(q) || c.tags.some((t) => t.toLowerCase().includes(q)),
      ),
      streams: streams
        .filter(
          (s) =>
            s.title.toLowerCase().includes(q) ||
            s.channel.displayName.toLowerCase().includes(q) ||
            s.category?.name.toLowerCase().includes(q),
        )
        .map((s) => withViewerState(s)),
    };
  }

  /* ---- chat ---------------------------------------------------------- */

  async sendMessage(streamId: string, text: string, replyTo?: ChatMessage["replyTo"]): Promise<ChatMessage> {
    await transport();
    const user = requireAuth();
    const stream = streams.find((s) => s.id === streamId);
    if (!stream) throw new ApiError("not_found", "Stream not found.", 404);

    const body = text.trim();
    if (!body) throw new ApiError("validation_failed", "Message cannot be empty.", 422);
    if (body.length > MODERATION.maxLength) {
      throw new ApiError("validation_failed", `Messages are limited to ${MODERATION.maxLength} characters.`, 422);
    }
    if (MODERATION.blockLinks && /https?:\/\/|www\./i.test(body)) {
      throw new ApiError("validation_failed", "Links are not allowed in chat.", 422);
    }
    const lower = body.toLowerCase();
    if (MODERATION.bannedWords.some((w) => lower.includes(w))) {
      throw new ApiError("validation_failed", "That message contains a blocked term.", 422);
    }

    const isPrivileged = hasRole(user.roles, "moderator", "streamer");
    if (stream.chatSettings.subscribersOnly && !hasRole(user.roles, "subscriber", "moderator", "streamer")) {
      throw new ApiError("forbidden", "Subscriber-only mode is on.", 403);
    }
    const last = lastSendByUser.get(user.id);
    const now = Date.now();
    if (last) {
      if (now - last.at < MODERATION.minIntervalMs) {
        throw new ApiError("rate_limited", "You are sending messages too quickly.", 429, {
          retryAfter: Math.ceil((MODERATION.minIntervalMs - (now - last.at)) / 1000) || 1,
        });
      }
      const slow = stream.chatSettings.slowModeSeconds;
      if (slow > 0 && !isPrivileged && now - last.at < slow * 1000) {
        throw new ApiError("rate_limited", `Slow mode is on: wait ${slow}s between messages.`, 429, {
          retryAfter: Math.ceil((slow * 1000 - (now - last.at)) / 1000),
        });
      }
      if (last.text === body && now - last.at < MODERATION.duplicateWindowMs) {
        throw new ApiError("conflict", "You just sent that message. Try saying something else.", 409);
      }
    }
    lastSendByUser.set(user.id, { at: now, text: body });

    const message: ChatMessage = {
      id: `msg_live_${now}_${Math.random().toString(36).slice(2, 7)}`,
      streamId,
      author: user,
      kind: "chat",
      text: body,
      createdAt: new Date().toISOString(),
      badges: user.roles.includes("streamer")
        ? [{ kind: "streamer" }]
        : user.roles.includes("moderator")
          ? [{ kind: "moderator" }]
          : user.roles.includes("subscriber")
            ? [{ kind: "subscriber", label: "8m" }]
            : [],
      replyTo: replyTo ?? null,
      emotes: detectEmotes(body),
      mentions: detectMentions(body),
      isPinned: false,
      canDelete: true,
      deletedBy: null,
    };

    room(streamId).push(message);
    emit(streamId, { type: "message", message });
    return message;
  }

  async deleteMessage(streamId: string, messageId: string): Promise<void> {
    await transport();
    const user = requireAuth();
    const messages = room(streamId);
    const message = messages.find((m) => m.id === messageId);
    if (!message) throw new ApiError("not_found", "That message no longer exists.", 404);
    if (message.author?.id !== user.id && !hasRole(user.roles, "moderator", "streamer")) {
      throw new ApiError("forbidden", "You can only delete your own messages.", 403);
    }
    message.deletedBy = user.displayName;
    emit(streamId, { type: "update", message });
  }

  async clearChat(streamId: string): Promise<void> {
    await transport();
    const user = requireModerator();
    const messages = room(streamId);
    // keep a tombstone rather than wiping history silently
    messages.splice(0, messages.length, {
      id: `sys_clear_${Date.now()}`,
      streamId,
      author: null,
      kind: "moderation",
      text: `Chat was cleared by ${user.displayName}.`,
      createdAt: new Date().toISOString(),
      badges: [],
      replyTo: null,
      emotes: [],
      mentions: [],
      isPinned: false,
      canDelete: false,
      deletedBy: null,
    });
    emit(streamId, { type: "clear" });
  }

  async pinMessage(streamId: string, messageId: string | null): Promise<ChatMessage | null> {
    await transport();
    requireModerator();
    const messages = room(streamId);
    messages.forEach((m) => {
      m.isPinned = false;
    });
    const next = messageId ? messages.find((m) => m.id === messageId) ?? null : null;
    if (messageId && !next) throw new ApiError("not_found", "Message not found.", 404);
    if (next) next.isPinned = true;
    pinnedByStream.set(streamId, next);
    emit(streamId, { type: "pin", message: next });
    return next;
  }

  async getPinned(streamId: string): Promise<ChatMessage | null> {
    room(streamId);
    return pinnedByStream.get(streamId) ?? null;
  }

  async timeoutUser(streamId: string, userId: string, seconds: number, reason?: string): Promise<void> {
    await transport();
    const mod = requireModerator();
    if (!Number.isFinite(seconds) || seconds <= 0 || seconds > 1_209_600) {
      throw new ApiError("validation_failed", "Timeouts must be between 1 second and 14 days.", 422);
    }
    const target = findModerationTarget(userId);
    if (!target) throw new ApiError("not_found", "That user is no longer in chat.", 404);
    if (hasRole(target.roles, "moderator", "streamer")) {
      throw new ApiError("forbidden", "You cannot time out another moderator or the broadcaster.", 403);
    }
    const note: ChatMessage = {
      id: `sys_to_${Date.now()}`,
      streamId,
      author: null,
      kind: "moderation",
      text: `${mod.displayName} timed out @${target.displayName} for ${seconds}s${reason ? ` — ${reason}` : ""}.`,
      createdAt: new Date().toISOString(),
      badges: [],
      replyTo: null,
      emotes: [],
      mentions: [{ login: target.login, displayName: target.displayName }],
      isPinned: false,
      canDelete: false,
      deletedBy: null,
    };
    room(streamId).push(note);
    emit(streamId, { type: "message", message: note });
  }

  async banUser(streamId: string, userId: string): Promise<void> {
    await transport();
    const mod = requireModerator();
    const target = findModerationTarget(userId);
    if (!target) throw new ApiError("not_found", "That user is no longer in chat.", 404);
    if (hasRole(target.roles, "moderator", "streamer")) {
      throw new ApiError("forbidden", "You cannot ban another moderator or the broadcaster.", 403);
    }
    const note: ChatMessage = {
      id: `sys_ban_${Date.now()}`,
      streamId,
      author: null,
      kind: "moderation",
      text: `${mod.displayName} banned @${target.displayName}.`,
      createdAt: new Date().toISOString(),
      badges: [],
      replyTo: null,
      emotes: [],
      mentions: [{ login: target.login, displayName: target.displayName }],
      isPinned: false,
      canDelete: false,
      deletedBy: null,
    };
    room(streamId).push(note);
    emit(streamId, { type: "message", message: note });
  }

  /* ---- widgets ------------------------------------------------------- */

  async getPoll(streamId: string): Promise<Poll> {
    await transport();
    let poll = polls.get(streamId);
    if (!poll) {
      poll = seedPoll(streamId);
      polls.set(streamId, poll);
    }
    const user = currentUser();
    return { ...poll, canClose: !!user && hasRole(user.roles, "streamer", "moderator") };
  }

  async votePoll(pollId: string, optionId: string): Promise<Poll> {
    await transport();
    requireAuth();
    const poll = [...polls.values()].find((p) => p.id === pollId);
    if (!poll) throw new ApiError("not_found", "That poll has ended.", 404);
    if (poll.status === "closed") throw new ApiError("conflict", "This poll is closed.", 409);
    if (poll.viewerVote) throw new ApiError("conflict", "You have already voted in this poll.", 409);
    const option = poll.options.find((o) => o.id === optionId);
    if (!option) throw new ApiError("validation_failed", "Unknown poll option.", 422);

    option.votes += 1;
    poll.totalVotes += 1;
    poll.viewerVote = optionId;
    emit(poll.streamId, { type: "poll", poll: { ...poll } });
    return this.getPoll(poll.streamId);
  }

  async closePoll(pollId: string): Promise<Poll> {
    await transport();
    requireStreamer();
    const poll = [...polls.values()].find((p) => p.id === pollId);
    if (!poll) throw new ApiError("not_found", "Poll not found.", 404);
    poll.status = "closed";
    emit(poll.streamId, { type: "poll", poll: { ...poll } });
    return { ...poll, canClose: true };
  }

  async createPoll(streamId: string, question: string, options: string[]): Promise<Poll> {
    await transport();
    requireStreamer();
    const cleanOptions = options.map((o) => o.trim()).filter(Boolean);
    if (question.trim().length < 3) throw new ApiError("validation_failed", "Question is too short.", 422);
    if (cleanOptions.length < 2 || cleanOptions.length > 5) {
      throw new ApiError("validation_failed", "Polls need between 2 and 5 options.", 422);
    }
    const poll: Poll = {
      id: `poll_${Date.now()}`,
      streamId,
      question: question.trim(),
      options: cleanOptions.map((label, i) => ({ id: `po_${Date.now()}_${i}`, label, votes: 0 })),
      status: "open",
      createdAt: new Date().toISOString(),
      closesAt: null,
      totalVotes: 0,
      viewerVote: null,
      canClose: true,
      createdBy: currentUser()?.displayName ?? "streamer",
    };
    polls.set(streamId, poll);
    emit(streamId, { type: "poll", poll });
    return poll;
  }

  async getPrediction(streamId: string): Promise<Prediction> {
    await transport();
    let prediction = predictions.get(streamId);
    if (!prediction) {
      prediction = seedPrediction(streamId);
      predictions.set(streamId, prediction);
    }
    return { ...prediction };
  }

  async enterPrediction(predictionId: string, outcomeId: string): Promise<Prediction> {
    await transport();
    requireAuth();
    const prediction = [...predictions.values()].find((p) => p.id === predictionId);
    if (!prediction) throw new ApiError("not_found", "Prediction not found.", 404);
    if (!prediction.spendEnabled) {
      throw new ApiError(
        "unsupported",
        "Placing a prediction requires the channel-points economy service, which is not connected in this environment.",
        501,
      );
    }
    if (prediction.status !== "open") throw new ApiError("conflict", "Predictions are locked.", 409);
    const outcome = prediction.outcomes.find((o) => o.id === outcomeId);
    if (!outcome) throw new ApiError("validation_failed", "Unknown outcome.", 422);
    prediction.viewerEntry = { outcomeId, points: outcome.points };
    return { ...prediction };
  }

  async getGoals(streamId: string): Promise<StreamGoal[]> {
    await transport();
    if (!goals.has(streamId)) goals.set(streamId, seedGoals.map((g) => ({ ...g })));
    return (goals.get(streamId) ?? []).filter((g) => g.visibility === "public");
  }

  async getLeaderboard(_streamId: string): Promise<Leaderboard> {
    await transport();
    const board = seedLeaderboard();
    if (leaderboardOptOut.value) {
      return {
        ...board,
        entries: board.entries
          .filter((e) => !e.isSelf)
          .map((e, i) => ({ ...e, rank: i + 1 })),
        viewerOptedOut: true,
      };
    }
    return { ...board, viewerOptedOut: false, entries: board.entries.map((e) => ({ ...e })) };
  }

  async setLeaderboardOptOut(optOut: boolean): Promise<Leaderboard> {
    await transport();
    requireAuth();
    leaderboardOptOut.value = optOut;
    LS.set("vanta.lb.optout", optOut);
    return this.getLeaderboard("st_v0lt");
  }

  async getRewards(_streamId: string): Promise<RewardsState> {
    await transport();
    return seedRewards();
  }

  async redeemReward(rewardId: string): Promise<RewardsState> {
    await transport();
    requireAuth();
    const rewards = seedRewards();
    if (!rewards.redemptionEnabled) {
      throw new ApiError(
        "unsupported",
        "Reward redemption needs the channel-points service. It is intentionally disabled here rather than simulated.",
        501,
      );
    }
    const reward = rewards.rewards.find((r) => r.id === rewardId);
    if (!reward) throw new ApiError("not_found", "Reward not found.", 404);
    throw new ApiError("unsupported", "Reward redemption is not available.", 501);
  }

  async getAlerts(streamId: string): Promise<SupportAlert[]> {
    await transport();
    if (!alerts.has(streamId)) alerts.set(streamId, seedAlerts());
    return (alerts.get(streamId) ?? []).map((a) => ({ ...a }));
  }

  /* ---- content ------------------------------------------------------- */

  async getClips(channelId: string): Promise<Clip[]> {
    await transport();
    if (channelId !== "ch_v0lt") return [];
    return clips.map((c) => ({ ...c }));
  }

  async getVods(channelId: string) {
    await transport();
    return channelId === "ch_v0lt" ? vods.map((v) => ({ ...v })) : [];
  }

  async createClip(input: { streamId: string; startSeconds: number; endSeconds: number; title: string }): Promise<Clip> {
    await transport();
    requireAuth();
    const stream = streams.find((s) => s.id === input.streamId);
    if (!stream) throw new ApiError("not_found", "Stream not found.", 404);
    if (!stream.playback?.dvr.enabled) {
      throw new ApiError("unsupported", "This stream has no DVR window, so a clip cannot be created.", 501);
    }
    const length = input.endSeconds - input.startSeconds;
    if (length < 5 || length > 60) {
      throw new ApiError("validation_failed", "Clips must be between 5 and 60 seconds.", 422);
    }
    const title = input.title.trim();
    if (title.length < 3) throw new ApiError("validation_failed", "Give the clip a title (3+ characters).", 422);

    const clip: Clip = {
      id: `clip_${Date.now()}`,
      title,
      thumbnailUrl: stream.playback.posterUrl,
      durationSeconds: Math.round(length),
      viewCount: 0,
      createdAt: new Date().toISOString(),
      creatorDisplayName: currentUser()?.displayName ?? "viewer",
      gameName: stream.category?.name ?? "—",
    };
    clips.unshift(clip);
    return clip;
  }

  async getEmotes(): Promise<Emote[]> {
    return emotes;
  }

  async report(input: { targetType: "stream" | "channel" | "chat_message"; targetId: string; reason: string; details: string }) {
    await transport();
    requireAuth();
    if (!input.reason) throw new ApiError("validation_failed", "Choose a reason for the report.", 422);
    if (input.details.length > 500) {
      throw new ApiError("validation_failed", "Report details are limited to 500 characters.", 422);
    }
    return { id: `report_${Date.now()}` };
  }
}

/* emote/mention detection shared with the server-side message pipeline */
function detectEmotes(text: string): string[] {
  const found = new Set<string>();
  for (const token of text.split(/\s+/)) {
    const code = token.replace(/^:|:$/g, "").toLowerCase();
    if (/^:[a-z]+:$/.test(token) && emotes.some((e) => e.code === code)) found.add(code);
  }
  return [...found];
}

function detectMentions(text: string): ChatMessage["mentions"] {
  const out: ChatMessage["mentions"] = [];
  for (const m of text.matchAll(/@([a-z0-9_.]+)/gi)) {
    const login = m[1].toLowerCase();
    const persona = chatPersonas.find((p) => p.login === login);
    if (persona) out.push({ login: persona.login, displayName: persona.displayName });
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/* chat transport (mock WebSocket)                                            */
/* -------------------------------------------------------------------------- */

const AMBIENT_LINES = [
  "chat is genuinely educational today",
  "the audio cue thing changed my whole approach",
  "second monitor gang",
  "who else is supposed to be working right now",
  "that was the cleanest round all stream",
  "clip it clip it clip it",
  "does the new patch hit the second wave timing",
  "@n0va explain the rotation again please",
  "I have watched this map 200 times and never noticed that corner",
  "gg :pog:",
  "brb tea",
  "back, what did I miss",
  "he is one game off ascendant",
  "the aim is unreal tonight",
  "mods asleep, post wave 3 memes",
  "chat moving fast today",
];

const AMBIENT_PEOPLE = chatPersonas.filter((p) => p.login !== "long_username_test");

/**
 * Chat transport.
 *
 * This is the *seam*: replacing it with a WebSocket implementation means
 * implementing the same three methods and nothing else changes in the UI.
 */
export class MockChatTransport {
  private streamId: string | null = null;
  private timer: number | null = null;
  private reconnectTimer: number | null = null;
  private status: ChatConnectionStatus = "disconnected";
  private attempts = 0;
  private subscriber: ((e: ChatEvent) => void) | null = null;
  private statusListener: ((s: ChatConnectionStatus) => void) | null = null;

  connect(streamId: string) {
    if (this.streamId === streamId && this.status === "connected") return;
    this.disconnect(true);
    this.streamId = streamId;
    this.setStatus("connecting");
    const delay = 320 + Math.random() * 380;
    this.timer = window.setTimeout(() => {
      this.attempts = 0;
      this.setStatus("connected");
      this.scheduleAmbient();
    }, delay);
  }

  disconnect(silent = false) {
    if (this.timer) window.clearTimeout(this.timer);
    if (this.reconnectTimer) window.clearTimeout(this.reconnectTimer);
    this.timer = null;
    this.reconnectTimer = null;
    this.streamId = null;
    if (!silent) this.setStatus("disconnected");
  }

  onEvent(listener: (e: ChatEvent) => void) {
    this.subscriber = listener;
    if (this.streamId) {
      let set = chatListeners.get(this.streamId);
      if (!set) chatListeners.set(this.streamId, (set = new Set()));
      set.add(listener);
    }
    return () => {
      if (this.streamId) chatListeners.get(this.streamId)?.delete(listener);
      if (this.subscriber === listener) this.subscriber = null;
    };
  }

  onStatus(listener: (s: ChatConnectionStatus) => void) {
    this.statusListener = listener;
    listener(this.status);
    return () => {
      if (this.statusListener === listener) this.statusListener = null;
    };
  }

  private setStatus(next: ChatConnectionStatus) {
    this.status = next;
    this.statusListener?.(next);
  }

  /** Called by the demo panel to simulate a dropped socket. */
  simulateDrop() {
    if (!this.streamId) return;
    this.setStatus("reconnecting");
    if (this.timer) window.clearTimeout(this.timer);
    this.timer = null;
    this.attempts += 1;
    const backoff = Math.min(500 * 2 ** (this.attempts - 1), 8_000);
    this.reconnectTimer = window.setTimeout(() => {
      if (demoStore.get().chatOffline) {
        this.setStatus("disconnected");
        return;
      }
      this.setStatus("connected");
      this.attempts = 0;
      this.scheduleAmbient();
    }, backoff);
  }

  private scheduleAmbient() {
    if (this.timer) window.clearTimeout(this.timer);
    const next = 2_400 + Math.random() * 5_600;
    this.timer = window.setTimeout(() => {
      if (this.streamId && this.status === "connected") {
        if (demoStore.get().chatOffline) {
          this.simulateDrop();
          return;
        }
        this.emitAmbient();
        this.scheduleAmbient();
      }
    }, next);
  }

  private emitAmbient() {
    if (!this.streamId) return;
    const streamId = this.streamId;
    const persona = AMBIENT_PEOPLE[Math.floor(Math.random() * AMBIENT_PEOPLE.length)];
    const text = AMBIENT_LINES[Math.floor(Math.random() * AMBIENT_LINES.length)];
    const message: ChatMessage = {
      id: `msg_amb_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      streamId,
      author: persona,
      kind: "chat",
      text,
      createdAt: new Date().toISOString(),
      badges: persona.badge === "subscriber"
        ? [{ kind: "subscriber", label: persona.months ? `${persona.months}m` : undefined }]
        : persona.badge === "verified"
          ? [{ kind: "verified" }]
          : [],
      replyTo: null,
      emotes: detectEmotes(text),
      mentions: detectMentions(text),
      isPinned: false,
      canDelete: false,
      deletedBy: null,
    };
    room(streamId).push(message);
    // keep the room bounded in memory; a real server paginates history
    if (chatRooms.get(streamId)!.length > 400) {
      chatRooms.get(streamId)!.splice(0, 40);
    }
    emit(streamId, { type: "message", message });
  }
}

export const api: VantaApi & {
  getPinned: (streamId: string) => Promise<ChatMessage | null>;
} = new MockApi();

/**
 * Restores the seeded server state. Exported for the test suite only — the app
 * never calls this. Without it, module-level maps leak between test cases.
 */
export function __resetDemoState() {
  followState.clear();
  [
    ["ch_v0lt", { following: true, alerts: "live" as const }],
    ["ch_n0va", { following: true, alerts: "all" as const }],
    ["ch_brk", { following: true, alerts: "live" as const }],
  ].forEach(([id, rec]) => followState.set(id as string, rec as { following: boolean; alerts: FollowAlerts }));
  persistFollows();
  lastSendByUser.clear();
  chatRooms.clear();
  pinnedByStream.clear();
  polls.clear();
  predictions.clear();
  goals.clear();
  alerts.clear();
  leaderboardOptOut.value = false;
}

export const chatTransport = new MockChatTransport();
export { withViewerState };
export type { ChatEvent };
