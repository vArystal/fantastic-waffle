/**
 * Demo environment switches.
 *
 * These exist so the *documented* failure paths (slow network, intermittent
 * failures, offline server, chat disconnects, stream state transitions and the
 * role/permission matrix) can be exercised in a build with no backend.
 *
 * In a production build these controls are removed and the corresponding state
 * comes from real network/auth conditions.
 */

export type NetworkProfile = "fast" | "slow" | "flaky" | "offline";
export type PersonaId = "guest" | "viewer" | "subscriber" | "moderator" | "streamer";
export type ForcedStreamState = "auto" | "live" | "offline" | "ended" | "scheduled" | "restricted";

export interface DemoState {
  network: NetworkProfile;
  persona: PersonaId;
  forcedStreamState: ForcedStreamState;
  /** chat transport is deliberately dropped to exercise reconnect UI */
  chatOffline: boolean;
}

const KEY = "vanta.demo.v1";

const DEFAULTS: DemoState = {
  network: "fast",
  persona: "subscriber",
  forcedStreamState: "auto",
  chatOffline: false,
};

function read(): DemoState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS };
    return { ...DEFAULTS, ...(JSON.parse(raw) as Partial<DemoState>) };
  } catch {
    return { ...DEFAULTS };
  }
}

let state: DemoState = read();
const listeners = new Set<() => void>();

export const demoStore = {
  get(): DemoState {
    return state;
  },
  set(patch: Partial<DemoState>) {
    state = { ...state, ...patch };
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage can be unavailable — state stays in memory */
    }
    listeners.forEach((l) => l());
  },
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
};
