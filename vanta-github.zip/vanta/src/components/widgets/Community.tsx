import { useState } from "react";
import { api } from "../../api/mockApi";
import type { Poll, Stream, User } from "../../types";
import { ApiError } from "../../types";
import { cx, formatCount, formatRelative, percent } from "../../lib/utils";
import { useAsync } from "../../state/useAsync";
import { IconCoins, IconGift, IconStar, IconTrophy } from "../icons";
import { ErrorState, ProgressBar, SkeletonLine } from "../ui/primitives";
import { useToast } from "../ui/Toast";

/* -------------------------------------------------------------------------- */
/* poll                                                                       */
/* -------------------------------------------------------------------------- */

function usePoll(streamId: string) {
  return useAsync<Poll>(() => api.getPoll(streamId), [streamId]);
}

export function PollStrip({ stream }: { stream: Stream }) {
  const poll = usePoll(stream.id);
  const toast = useToast();
  const [voting, setVoting] = useState<string | null>(null);
  const [dismissed, setDismissed] = useState(false);

  if (dismissed || !poll.data || poll.data.status !== "open") return null;
  const data = poll.data;

  const vote = async (optionId: string) => {
    if (voting) return;
    setVoting(optionId);
    try {
      const next = await api.votePoll(data.id, optionId);
      poll.setData(next);
    } catch (err) {
      const e = err instanceof ApiError ? err : new ApiError("server_error", "Vote failed.");
      toast.error("Vote not counted", e.message);
      // resync with server truth after a rejected vote (duplicate, closed, etc.)
      void poll.reload();
    } finally {
      setVoting(null);
    }
  };

  return (
    <section className="poll-strip" aria-label="Live poll">
      <div className="poll-strip__head">
        <span className="eyebrow">Poll</span>
        <span className="poll-strip__q">{data.question}</span>
        <button className="icon-btn icon-btn--sm" onClick={() => setDismissed(true)} aria-label="Hide poll">
          ×
        </button>
      </div>
      <div className="poll-strip__options">
        {data.options.map((o) => {
          const pct = percent(o.votes, data.totalVotes);
          const chosen = data.viewerVote === o.id;
          return (
            <button
              key={o.id}
              className={cx("poll-opt", chosen && "is-chosen")}
              onClick={() => void vote(o.id)}
              disabled={!!data.viewerVote || voting !== null}
              aria-pressed={chosen}
            >
              <span className="poll-opt__fill" style={{ width: `${pct}%` }} aria-hidden="true" />
              <span className="poll-opt__label">{o.label}</span>
              <span className="poll-opt__pct mono">{Math.round(pct)}%</span>
            </button>
          );
        })}
      </div>
      <p className="poll-strip__foot">
        {data.viewerVote ? "Vote recorded · " : ""}
        {formatCount(data.totalVotes)} votes
        {data.closesAt ? ` · closes ${formatRelative(data.closesAt)}` : ""}
      </p>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/* goals + prediction + leaderboard + rewards                                 */
/* -------------------------------------------------------------------------- */

export function GoalsCard({ stream }: { stream: Stream }) {
  const goals = useAsync(() => api.getGoals(stream.id), [stream.id]);
  if (goals.loading) return <div className="panel widget"><SkeletonLine height={64} /></div>;
  if (goals.error) return <div className="panel widget"><ErrorState error={goals.error} onRetry={goals.reload} compact /></div>;
  if (!goals.data?.length) return null;

  return (
    <section className="panel widget">
      <div className="panel-head">
        <h3 className="panel-title">
          <IconStar size={14} /> Stream goals
        </h3>
      </div>
      <div className="widget__body">
        {goals.data.map((g) => (
          <div className="goal" key={g.id}>
            <div className="goal__row">
              <span className="goal__label">{g.label}</span>
              <span className="goal__nums mono">
                {formatCount(g.current)} / {formatCount(g.target)}
              </span>
            </div>
            <ProgressBar
              value={g.current}
              total={g.target}
              label={`${g.label}: ${Math.round(percent(g.current, g.target))}% complete`}
              tone={g.kind === "subscribers" ? "accent" : "trust"}
            />
          </div>
        ))}
        <p className="widget__note">Goals are read-only here; progress is updated by the creator service.</p>
      </div>
    </section>
  );
}

export function PredictionCard({ stream }: { stream: Stream }) {
  const prediction = useAsync(() => api.getPrediction(stream.id), [stream.id]);
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  if (prediction.loading) return <div className="panel widget"><SkeletonLine height={72} /></div>;
  if (prediction.error) return <div className="panel widget"><ErrorState error={prediction.error} onRetry={prediction.reload} compact /></div>;
  const data = prediction.data;
  if (!data) return null;

  const enter = async (outcomeId: string) => {
    setBusy(true);
    try {
      const next = await api.enterPrediction(data.id, outcomeId);
      prediction.setData(next);
    } catch (err) {
      const e = err instanceof ApiError ? err : new ApiError("server_error", "Prediction failed.");
      toast.error("Prediction unavailable", e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel widget">
      <div className="panel-head">
        <h3 className="panel-title">
          <IconTrophy size={14} /> Prediction
        </h3>
        <span className={cx("chip", data.status === "open" ? "chip--accent" : "")}>{data.status}</span>
      </div>
      <div className="widget__body">
        <p className="prediction__q">{data.question}</p>
        <div className="prediction__outcomes">
          {data.outcomes.map((o) => {
            const total = data.outcomes.reduce((sum, x) => sum + x.entries, 0);
            const pct = percent(o.entries, total);
            return (
              <button
                key={o.id}
                className={cx("prediction__opt", `prediction__opt--${o.color}`, data.viewerEntry?.outcomeId === o.id && "is-chosen")}
                onClick={() => void enter(o.id)}
                disabled={!data.spendEnabled || busy || data.status !== "open"}
                title={data.spendEnabled ? undefined : "Requires the channel-points economy service"}
              >
                <span className="prediction__label">{o.label}</span>
                <span className="prediction__odds mono">{o.points.toFixed(2)}×</span>
                <span className="prediction__fill" style={{ width: `${pct}%` }} aria-hidden="true" />
              </button>
            );
          })}
        </div>
        <p className="widget__note">
          {data.spendEnabled
            ? "Entries are validated server-side; odds update as points are committed."
            : "Placing a prediction needs the economy service, which isn't connected here. Odds shown are live channel data, and no points can be wagered."}
        </p>
      </div>
    </section>
  );
}

export function LeaderboardCard({ stream, user }: { stream: Stream; user: User | null }) {
  const board = useAsync(() => api.getLeaderboard(stream.id), [stream.id]);
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  if (board.loading)
    return (
      <div className="panel widget">
        <div className="widget__body">{Array.from({ length: 4 }, (_, i) => <SkeletonLine key={i} height={22} />)}</div>
      </div>
    );
  if (board.error) return <div className="panel widget"><ErrorState error={board.error} onRetry={board.reload} compact /></div>;
  if (!board.data) return null;
  const data = board.data;

  const toggleOptOut = async () => {
    setBusy(true);
    try {
      const next = await api.setLeaderboardOptOut(!data.viewerOptedOut);
      board.setData(next);
      toast.success(next.viewerOptedOut ? "You are hidden from this leaderboard" : "You are visible on this leaderboard");
    } catch (err) {
      toast.error("Could not update privacy setting", err instanceof ApiError ? err.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel widget">
      <div className="panel-head">
        <h3 className="panel-title">
          <IconTrophy size={14} /> {data.title}
        </h3>
        <span className="widget__period">{data.period}</span>
      </div>
      <ol className="lb">
        {data.entries.map((e) => (
          <li key={e.user.id} className={cx("lb__row", e.isSelf && "is-self")}>
            <span className={cx("lb__rank mono", e.rank <= 3 && `lb__rank--${e.rank}`)}>{e.rank}</span>
            <span className="lb__name truncate" style={{ color: e.user.color }}>
              {e.user.displayName}
              {e.isSelf && <span className="lb__you">you</span>}
            </span>
            <span className="lb__score mono">{formatCount(e.score)}</span>
          </li>
        ))}
      </ol>
      {user && (
        <button className="widget__privacy" onClick={() => void toggleOptOut()} disabled={busy}>
          {data.viewerOptedOut ? "Show me on leaderboards" : "Hide me from leaderboards"}
        </button>
      )}
    </section>
  );
}

export function RewardsCard({ stream }: { stream: Stream }) {
  const rewards = useAsync(() => api.getRewards(stream.id), [stream.id]);
  const toast = useToast();
  if (rewards.loading) return <div className="panel widget"><SkeletonLine height={72} /></div>;
  if (rewards.error) return <div className="panel widget"><ErrorState error={rewards.error} onRetry={rewards.reload} compact /></div>;
  const data = rewards.data;
  if (!data) return null;

  return (
    <section className="panel widget">
      <div className="panel-head">
        <h3 className="panel-title">
          <IconCoins size={14} /> Channel points
        </h3>
        <span className="mono widget__balance">{data.balance != null ? formatCount(data.balance) : "hidden"}</span>
      </div>
      <div className="widget__body widget__body--flush">
        {data.rewards.map((r) => {
          const blocked = !data.redemptionEnabled || r.unavailableReason !== null;
          return (
            <div className="reward" key={r.id}>
              <div className="reward__body">
                <p className="reward__title">{r.title}</p>
                <p className="reward__desc">{r.description}</p>
                <p className="reward__meta mono">
                  {formatCount(r.cost)} pts
                  {r.stock !== null && ` · ${r.stock} left`}
                  {r.cooldownSeconds > 0 && ` · ${Math.round(r.cooldownSeconds / 60)}m cooldown`}
                </p>
              </div>
              <button
                className="btn btn--ghost btn--sm"
                disabled={blocked}
                title={r.unavailableReason ?? (!data.redemptionEnabled ? "Redemption is disabled in this deployment" : undefined)}
                onClick={() => {
                  void api
                    .redeemReward(r.id)
                    .then((next) => rewards.setData(next))
                    .catch((err: ApiError) => toast.error("Redemption unavailable", err.message));
                }}
              >
                Redeem
              </button>
            </div>
          );
        })}
        <p className="widget__note">
          {data.redemptionEnabled
            ? "Redemptions are processed by the rewards service."
            : "Redemption is intentionally disabled: this build has no rewards service, and a decorative redeem button would be misleading."}
        </p>
      </div>
    </section>
  );
}

export function AlertsCard({ stream, soundEnabled }: { stream: Stream; soundEnabled: boolean }) {
  const alerts = useAsync(() => api.getAlerts(stream.id), [stream.id]);
  if (alerts.loading) return <div className="panel widget"><SkeletonLine height={54} /></div>;
  if (alerts.error) return <div className="panel widget"><ErrorState error={alerts.error} onRetry={alerts.reload} compact /></div>;
  if (!alerts.data?.length) return null;

  return (
    <section className="panel widget">
      <div className="panel-head">
        <h3 className="panel-title">
          <IconGift size={14} /> Recent support
        </h3>
        <span className="chip chip--quiet">{soundEnabled ? "sound on" : "muted"}</span>
      </div>
      <ul className="alerts">
        {alerts.data.map((a) => (
          <li key={a.id} className="alerts__row">
            <span className={cx("alerts__icon", `alerts__icon--${a.kind}`)} aria-hidden="true">
              <IconGift size={13} />
            </span>
            <span className="alerts__body">
              <strong>{a.displayName}</strong> {a.detail}
              {a.amountLabel && <span className="alerts__amount mono"> {a.amountLabel}</span>}
              <span className="alerts__time">{formatRelative(a.createdAt)}</span>
            </span>
          </li>
        ))}
      </ul>
      <p className="widget__note">Monetary amounts are display strings from the server; none are computed client-side.</p>
    </section>
  );
}

export function CommunityPanel({ stream, user }: { stream: Stream; user: User | null }) {
  return (
    <div className="community">
      <PredictionCard stream={stream} />
      <GoalsCard stream={stream} />
      <LeaderboardCard stream={stream} user={user} />
      <RewardsCard stream={stream} />
      <AlertsCard stream={stream} soundEnabled={false} />
    </div>
  );
}
