import { useEffect, useRef, useState } from "react";
import type { ChatMessage, Emote, Stream, User } from "../../types";
import { cx, stripText, useNow } from "../../lib/utils";
import { IconClose, IconSend, IconSmile } from "../icons";
import { Popover } from "../ui/Popover";
import type { ChatApi } from "../../state/useChat";

const MAX_LENGTH = 500;

export function ChatComposer({
  stream,
  chat,
  emotes,
  user,
  onRequireAuth,
}: {
  stream: Stream;
  chat: ChatApi;
  emotes: Emote[];
  user: User | null;
  onRequireAuth: () => void;
}) {
  const [value, setValue] = useState("");
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const now = useNow(250, chat.slowUntil > Date.now());

  /* keep the textarea height in sync with its content */
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 108)}px`;
  }, [value]);

  /* the message list requests a reply target through this event, which keeps
     the list free of composer internals */
  useEffect(() => {
    const onReply = (e: Event) => {
      setReplyTo((e as CustomEvent<ChatMessage>).detail);
      textareaRef.current?.focus();
    };
    window.addEventListener("vanta:chat-reply", onReply);
    return () => window.removeEventListener("vanta:chat-reply", onReply);
  }, []);

  const cooldown = Math.max(0, Math.ceil((chat.slowUntil - now) / 1000));
  const offline = chat.status === "disconnected";
  const reconnecting = chat.status === "reconnecting" || chat.status === "connecting";
  const tooLong = value.length > MAX_LENGTH;
  const canSend = !!value.trim() && !tooLong && !submitting && !offline && !!user && cooldown === 0;

  const submit = async () => {
    if (!canSend) return;
    const text = value.trim();
    setSubmitting(true);
    const result = await chat.send(
      text,
      replyTo
        ? {
            id: replyTo.id,
            displayName: replyTo.author?.displayName ?? "",
            text: stripText(replyTo.text).slice(0, 60),
          }
        : null,
    );
    setSubmitting(false);
    if (result.ok) {
      setValue("");
      setReplyTo(null);
      textareaRef.current?.focus();
    }
  };

  const insertEmote = (emote: Emote) => {
    setValue((prev) => `${prev}${prev && !prev.endsWith(" ") ? " " : ""}:${emote.code}: `);
    textareaRef.current?.focus();
  };

  if (!user) {
    return (
      <div className="composer composer--locked">
        <p className="composer__locked-text">Sign in to join the conversation.</p>
        <button className="btn btn--primary btn--sm" onClick={onRequireAuth}>
          Sign in to chat
        </button>
      </div>
    );
  }

  return (
    <div className="composer">
      {(offline || reconnecting) && (
        <p className="composer__status" role="status">
          {offline ? "Chat is disconnected — messages can't be sent until it reconnects." : "Reconnecting to chat…"}
        </p>
      )}

      {replyTo && (
        <div className="composer__reply">
          <span className="composer__reply-label">Replying to {replyTo.author?.displayName ?? "message"}</span>
          <span className="composer__reply-text">{stripText(replyTo.text).slice(0, 70)}</span>
          <button className="icon-btn icon-btn--sm" onClick={() => setReplyTo(null)} aria-label="Cancel reply">
            <IconClose size={13} />
          </button>
        </div>
      )}

      {stream.chatSettings.slowModeSeconds > 0 && (
        <p className="composer__mode">
          Slow mode: {stream.chatSettings.slowModeSeconds}s
          {cooldown > 0 && <span className="composer__cooldown mono"> · wait {cooldown}s</span>}
        </p>
      )}

      <div className={cx("composer__row", tooLong && "composer__row--error")}>
        <Popover
          label="Emotes"
          side="top"
          align="start"
          trigger={({ toggle }) => (
            <button className="icon-btn composer__emote-btn" onClick={toggle} aria-label="Open emote picker" type="button">
              <IconSmile size={19} />
            </button>
          )}
        >
          {(close) => (
            <div className="emote-picker">
              <p className="emote-picker__title">Channel emotes</p>
              <div className="emote-picker__grid">
                {emotes.map((e) => (
                  <button
                    key={e.id}
                    className="emote-picker__item"
                    onClick={() => {
                      insertEmote(e);
                      close();
                    }}
                    title={e.subscriberOnly ? `${e.code} (subscribers)` : e.code}
                    aria-label={`Insert ${e.code}${e.subscriberOnly ? " — subscribers only" : ""}`}
                  >
                    <img src={e.url} alt="" width={30} height={30} loading="lazy" />
                    <span>{e.code}</span>
                  </button>
                ))}
              </div>
              <p className="emote-picker__note">
                Subscriber-only emotes are rejected by the server for other viewers.
              </p>
            </div>
          )}
        </Popover>

        <textarea
          ref={textareaRef}
          className="composer__input"
          placeholder={offline ? "Chat is offline" : "Send a message"}
          value={value}
          rows={1}
          maxLength={MAX_LENGTH + 50}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void submit();
            }
            if (e.key === "Escape" && replyTo) setReplyTo(null);
          }}
          aria-label="Chat message"
          aria-describedby="composer-hint"
          disabled={offline}
        />

        <button
          className="btn btn--primary composer__send"
          onClick={() => void submit()}
          disabled={!canSend}
          aria-label="Send message"
        >
          <IconSend size={17} />
        </button>
      </div>

      <div className="composer__foot">
        <span id="composer-hint" className="composer__hint">
          Enter to send · Shift+Enter for a new line
        </span>
        {value.length > MAX_LENGTH * 0.8 && (
          <span className={cx("composer__count mono", tooLong && "is-over")} aria-live="polite">
            {value.length}/{MAX_LENGTH}
          </span>
        )}
      </div>
    </div>
  );
}
