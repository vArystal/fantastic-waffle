import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ChatMessage, Emote, Stream, User } from "../../types";
import { ApiError } from "../../types";
import { cx } from "../../lib/utils";
import { IconChat, IconMore, IconPin, IconRefresh, IconShield, IconWifiOff } from "../icons";
import { EmptyState, ErrorState, Spinner } from "../ui/primitives";
import { Popover } from "../ui/Popover";
import { useToast } from "../ui/Toast";
import type { ChatApi } from "../../state/useChat";
import { ChatMessageRow } from "./ChatMessageRow";
import { ChatComposer } from "./ChatComposer";

/**
 * Live chat panel.
 *
 * DOM size is bounded: only the most recent `WINDOW` messages are mounted, and
 * older pages are appended on demand. That is a deliberate trade-off versus a
 * full virtual scroller — see docs/ARCHITECTURE.md § chat rendering.
 */
const WINDOW = 90;

export function ChatPanel({
  stream,
  chat,
  emotes,
  user,
  onOpenProfile,
  onReport,
  onRequireAuth,
  layout = "side",
}: {
  stream: Stream;
  chat: ChatApi;
  emotes: Emote[];
  user: User | null;
  onOpenProfile: (login: string) => void;
  onReport: (message: ChatMessage) => void;
  onRequireAuth: () => void;
  layout?: "side" | "embedded";
}) {
  const toast = useToast();
  const listRef = useRef<HTMLDivElement>(null);
  const [atBottom, setAtBottom] = useState(true);
  const [modTarget, setModTarget] = useState<ChatMessage | null>(null);
  const [modBusy, setModBusy] = useState(false);

  const emoteMap = useMemo(() => new Map(emotes.map((e) => [e.code, e])), [emotes]);
  const visible = useMemo(() => chat.messages.slice(-WINDOW), [chat.messages]);

  /* follow the tail only while the reader is already at the bottom */
  useEffect(() => {
    if (!atBottom || chat.paused) return;
    const el = listRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [visible.length, atBottom, chat.paused]);

  const onScroll = useCallback(() => {
    const el = listRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 48;
    setAtBottom(nearBottom);
    if (el.scrollTop < 24 && chat.hasOlder) void chat.loadOlder();
    if (!nearBottom && chat.unread > 0) return;
    if (nearBottom && chat.unread > 0) chat.resume();
  }, [chat]);

  const handlers = useMemo(
    () => ({
      canModerate: stream.viewerCanModerate,
      onDelete: (m: ChatMessage) => {
        void chat.deleteMessage(m.id).catch((err: ApiError) => toast.error("Could not delete", err.message));
      },
      onTimeout: (m: ChatMessage) => setModTarget(m),
      onBan: (m: ChatMessage) => setModTarget(m),
      onPin: (m: ChatMessage) => {
        void chat
          .pinMessage(m.isPinned ? null : m.id)
          .catch((err: ApiError) => toast.error("Could not pin", err.message));
      },
      onReply: (m: ChatMessage) => {
        window.dispatchEvent(new CustomEvent("vanta:chat-reply", { detail: m }));
      },
      onReport: (m: ChatMessage) => onReport(m),
      onRetry: (m: ChatMessage) => {
        void chat.retryFailed(m);
      },
      onDismiss: (m: ChatMessage) => chat.dismissFailed(m.id),
      onOpenProfile,
    }),
    [chat, stream.viewerCanModerate, toast, onReport, onOpenProfile],
  );

  const runMod = async (kind: "timeout" | "ban") => {
    if (!modTarget?.author) return;
    setModBusy(true);
    try {
      if (kind === "timeout") await chat.timeoutUser(modTarget.author.id, 600, "moderator action");
      else await chat.banUser(modTarget.author.id);
      toast.success(kind === "timeout" ? "User timed out" : "User banned", modTarget.author.displayName);
      setModTarget(null);
    } catch (err) {
      const e = err instanceof ApiError ? err : new ApiError("server_error", "Action failed.");
      toast.error("Moderation failed", e.message);
    } finally {
      setModBusy(false);
    }
  };

  const statusLabel =
    chat.status === "connected"
      ? "Connected"
      : chat.status === "connecting"
        ? "Connecting…"
        : chat.status === "reconnecting"
          ? "Reconnecting…"
          : chat.status === "disconnected"
            ? "Disconnected"
            : "Idle";

  return (
    <section className={cx("chat", layout === "embedded" && "chat--embedded")} aria-label="Live chat">
      <header className="chat__head">
        <div className="chat__title">
          <IconChat size={15} aria-hidden="true" />
          <h2>Stream chat</h2>
          <span className={cx("chat__status", `chat__status--${chat.status}`)} title={`Chat ${statusLabel}`}>
            <span className="chat__status-dot" aria-hidden="true" />
          </span>
          <span className="sr-only" aria-live="polite">
            Chat {statusLabel}
          </span>
        </div>
        <div className="chat__tools">
          {chat.unread > 0 && (
            <button className="chat__new" onClick={chat.resume}>
              {chat.unread} new
            </button>
          )}
          <button
            className={cx("btn btn--quiet btn--sm", chat.paused && "is-active")}
            onClick={() => (chat.paused ? chat.resume() : chat.setPaused(true))}
            aria-pressed={chat.paused}
          >
            {chat.paused ? "Resume" : "Pause"}
          </button>
          <Popover
            label="Chat options"
            side="bottom"
            align="end"
            trigger={({ toggle }) => (
              <button className="icon-btn icon-btn--sm" onClick={toggle} aria-label="Chat options">
                <IconMore size={16} />
              </button>
            )}
          >
            {(close) => (
              <div className="menu" role="menu">
                {stream.viewerCanModerate && (
                  <button
                    className="menu__item"
                    role="menuitem"
                    onClick={() => {
                      void chat
                        .clearChat()
                        .then(() => toast.success("Chat cleared"))
                        .catch((err: ApiError) => toast.error("Could not clear chat", err.message));
                      close();
                    }}
                  >
                    <IconShield size={15} /> Clear chat
                  </button>
                )}
                {chat.pinned && (
                  <button
                    className="menu__item"
                    role="menuitem"
                    onClick={() => {
                      void chat.pinMessage(null).catch((err: ApiError) => toast.error("Could not unpin", err.message));
                      close();
                    }}
                  >
                    <IconPin size={15} /> Unpin message
                  </button>
                )}
                <button
                  className="menu__item"
                  role="menuitem"
                  onClick={() => {
                    chat.reconnect();
                    close();
                  }}
                >
                  <IconRefresh size={15} /> Reconnect chat
                </button>
                {!stream.viewerCanModerate && (
                  <p className="menu__note">Moderation tools are only shown to moderators and the broadcaster.</p>
                )}
              </div>
            )}
          </Popover>
        </div>
      </header>

      {chat.pinned && (
        <div className="pinned">
          <IconPin size={13} aria-hidden="true" />
          <div className="pinned__body">
            <span className="pinned__author">{chat.pinned.author?.displayName ?? "Announcement"}</span>
            <span className="pinned__text">{chat.pinned.text}</span>
          </div>
          {stream.viewerCanModerate && (
            <button
              className="icon-btn icon-btn--sm"
              onClick={() => void chat.pinMessage(null).catch(() => undefined)}
              aria-label="Unpin message"
            >
              ×
            </button>
          )}
        </div>
      )}

      <div
        className="chat__list scroll-y"
        ref={listRef}
        onScroll={onScroll}
        role="log"
        aria-live="polite"
        aria-relevant="additions"
        aria-label="Chat messages"
        tabIndex={0}
      >
        {chat.loadingHistory && (
          <div className="chat__loading">
            <Spinner size={16} label="Loading chat history" />
            <span>Loading chat…</span>
          </div>
        )}

        {chat.historyError && (
          <ErrorState error={chat.historyError} onRetry={() => void chat.reconnect()} compact />
        )}

        {!chat.loadingHistory && !chat.historyError && (
          <>
            {chat.hasOlder && (
              <button className="chat__load-older" onClick={() => void chat.loadOlder()} disabled={chat.loadingOlder}>
                {chat.loadingOlder ? "Loading…" : "Load earlier messages"}
              </button>
            )}
            {visible.length === 0 ? (
              <EmptyState
                compact
                icon={<IconChat size={20} />}
                title="No messages yet"
                description="Be the first to say something."
              />
            ) : (
              visible.map((m) => (
                <ChatMessageRow
                  key={m.id}
                  message={m}
                  emotes={emoteMap}
                  handlers={handlers}
                  selfId={user?.id ?? null}
                />
              ))
            )}
          </>
        )}
      </div>

      {chat.status === "disconnected" && (
        <div className="chat__banner chat__banner--error" role="alert">
          <IconWifiOff size={15} />
          <span>Chat disconnected. Playback is unaffected.</span>
          <button className="btn btn--sm btn--ghost" onClick={chat.reconnect}>
            Reconnect
          </button>
        </div>
      )}

      {chat.paused && (
        <button className="chat__banner chat__banner--paused" onClick={chat.resume}>
          Chat paused{chat.unread > 0 ? ` · ${chat.unread} new messages` : ""} — click to resume
        </button>
      )}

      <ChatComposer stream={stream} chat={chat} emotes={emotes} user={user} onRequireAuth={onRequireAuth} />

      {modTarget?.author && (
        <div className="chat__mod-panel" role="dialog" aria-label={`Moderate ${modTarget.author.displayName}`}>
          <p className="chat__mod-title">
            Moderate <strong>{modTarget.author.displayName}</strong>
          </p>
          <div className="chat__mod-actions">
            <button className="btn btn--sm btn--ghost" onClick={() => void runMod("timeout")} disabled={modBusy}>
              Timeout 10m
            </button>
            <button className="btn btn--sm btn--danger" onClick={() => void runMod("ban")} disabled={modBusy}>
              Ban
            </button>
            <button className="btn btn--sm btn--quiet" onClick={() => setModTarget(null)} disabled={modBusy}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
