import { memo } from "react";
import type { ChatMessage, Emote } from "../../types";
import { cx, formatClock } from "../../lib/utils";
import { Avatar, RoleBadges } from "../ui/primitives";
import { IconAlert, IconCheck, IconGift, IconLive, IconRefresh, IconShield } from "../icons";

type ModHandlers = {
  canModerate: boolean;
  onDelete: (m: ChatMessage) => void;
  onTimeout: (m: ChatMessage) => void;
  onBan: (m: ChatMessage) => void;
  onPin: (m: ChatMessage) => void;
  onReply: (m: ChatMessage) => void;
  onReport: (m: ChatMessage) => void;
  onRetry: (m: ChatMessage) => void;
  onDismiss: (m: ChatMessage) => void;
  onOpenProfile: (login: string) => void;
};

/**
 * One chat row.
 *
 * Rendering is deliberately text-based: user content is never injected as
 * HTML. Emotes and mentions are resolved into React elements, which is the
 * only XSS-safe way to keep formatting.
 */
function ChatRowInner({ message, emotes, handlers, selfId }: { message: ChatMessage; emotes: Map<string, Emote>; handlers: ModHandlers; selfId: string | null }) {
  if (message.kind !== "chat") {
    return (
      <div className={cx("chat-sys", `chat-sys--${message.kind}`)} role="note">
        <span className="chat-sys__icon" aria-hidden="true">
          {message.kind === "announcement" ? (
            <IconAlert size={13} />
          ) : message.kind === "subscription" ? (
            <IconGift size={13} />
          ) : (
            <IconShield size={13} />
          )}
        </span>
        <span className="chat-sys__text">{message.text}</span>
        <time className="chat-sys__time mono" dateTime={message.createdAt}>
          {formatClock(message.createdAt)}
        </time>
      </div>
    );
  }

  if (message.deletedBy) {
    return (
      <div className="chat-row chat-row--tombstone" role="note">
        <span className="chat-row__text">Message removed by {message.deletedBy}.</span>
      </div>
    );
  }

  const author = message.author;
  const displayName = author?.displayName ?? "Unknown";
  const color = author?.color ?? "var(--text-secondary)";
  const isSelf = !!author && author.id === selfId;

  const renderBody = () => {
    const parts = message.text.split(/(\s+)/);
    return parts.map((part, i) => {
      const emoteMatch = /^:([a-z]+):$/.exec(part);
      if (emoteMatch && emotes.has(emoteMatch[1])) {
        const emote = emotes.get(emoteMatch[1])!;
        return (
          <img
            key={`${part}-${i}`}
            className="chat-emote"
            src={emote.url}
            alt={`:${emote.code}:`}
            title={`:${emote.code}:`}
            loading="lazy"
            decoding="async"
            width={22}
            height={22}
          />
        );
      }
      if (part.startsWith("@") && part.length > 1) {
        const login = part.slice(1).toLowerCase();
        const mention = message.mentions.find((m) => m.login === login);
        if (mention) {
          return (
            <button
              key={`${part}-${i}`}
              className="chat-mention"
              onClick={() => handlers.onOpenProfile(mention.login)}
            >
              {part}
            </button>
          );
        }
      }
      return <span key={`${part}-${i}`}>{part}</span>;
    });
  };

  return (
    <article
      className={cx("chat-row", isSelf && "chat-row--self", message.deliveryState === "failed" && "chat-row--failed")}
      aria-label={`${displayName}: ${message.text}`}
    >
      <button
        className="chat-row__avatar"
        onClick={() => author && handlers.onOpenProfile(author.login)}
        aria-label={`Open ${displayName}'s profile`}
        tabIndex={-1}
      >
        <Avatar src={author?.avatarUrl ?? null} name={displayName} size={22} />
      </button>
      <div className="chat-row__body">
        {message.replyTo && (
          <div className="chat-reply">
            <span aria-hidden="true">↳</span> {message.replyTo.displayName}
            {message.replyTo.text && message.replyTo.text !== "…" ? `: ${message.replyTo.text}` : ""}
          </div>
        )}
        <p className="chat-row__line">
          <RoleBadges badges={message.badges} />
          <button
            className="chat-row__name"
            style={{ color }}
            onClick={() => author && handlers.onOpenProfile(author.login)}
          >
            {displayName}
          </button>
          <span className="chat-row__sep" aria-hidden="true">
            :
          </span>
          <span className="chat-row__text">{renderBody()}</span>
        </p>
        {message.deliveryState === "sending" && (
          <span className="chat-state" aria-live="polite">
            Sending…
          </span>
        )}
        {message.deliveryState === "failed" && (
          <span className="chat-state chat-state--failed">
            <IconAlert size={12} /> {message.failureReason ?? "Not delivered"}
            <button className="chat-state__btn" onClick={() => handlers.onRetry(message)}>
              <IconRefresh size={11} /> Retry
            </button>
            <button className="chat-state__btn" onClick={() => handlers.onDismiss(message)}>
              Discard
            </button>
          </span>
        )}
        {message.deliveryState === "sent" && isSelf && (
          <span className="chat-state chat-state--sent">
            <IconCheck size={11} /> Sent
          </span>
        )}
      </div>

      <div className="chat-row__actions">
        <button className="chat-row__action" onClick={() => handlers.onReply(message)} aria-label={`Reply to ${displayName}`}>
          Reply
        </button>
        {handlers.canModerate && (
          <div className="chat-row__mod" role="group" aria-label="Moderation actions">
            <button onClick={() => handlers.onTimeout(message)}>Timeout</button>
            <button onClick={() => handlers.onBan(message)}>Ban</button>
            <button onClick={() => handlers.onDelete(message)}>Delete</button>
            <button onClick={() => handlers.onPin(message)}>{message.isPinned ? "Unpin" : "Pin"}</button>
          </div>
        )}
        <button className="chat-row__action" onClick={() => handlers.onReport(message)} aria-label={`Report ${displayName}`}>
          Report
        </button>
      </div>

      {message.isPinned && (
        <span className="chat-row__pinned" title="Pinned message">
          <IconLive size={10} /> pinned
        </span>
      )}
    </article>
  );
}

export const ChatMessageRow = memo(ChatRowInner);
