import type { SVGProps } from "react";

/**
 * Single icon family: 24px grid, 1.6 stroke, round caps.
 * Keeping every glyph here guarantees consistent optical weight.
 */

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function Svg({ size = 18, children, ...rest }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const IconLogo = ({ size = 24, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true" {...p}>
    <path d="M3 4h5.2l5.8 14.2L19.8 4H25l-8.6 20h-4.8L3 4z" fill="currentColor" />
    <path d="M17.5 4H22l-2.2 5.2h-4.4L17.5 4z" fill="var(--trust)" opacity="0.85" />
  </svg>
);

export const IconHome = (p: IconProps) => (
  <Svg {...p}><path d="M4 10.5 12 4l8 6.5" /><path d="M6 9.5V20h12V9.5" /><path d="M10 20v-5h4v5" /></Svg>
);
export const IconCompass = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="12" r="8.5" /><path d="m15.2 8.8-2 4.4-4.4 2 2-4.4 4.4-2Z" /></Svg>
);
export const IconHeart = (p: IconProps) => (
  <Svg {...p}><path d="M12 20s-7.5-4.4-7.5-9.3A4.2 4.2 0 0 1 12 8a4.2 4.2 0 0 1 7.5 2.7C19.5 15.6 12 20 12 20Z" /></Svg>
);
export const IconHeartFilled = ({ size = 18, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M12 20.2s-7.7-4.6-7.7-9.5A4.4 4.4 0 0 1 12 7.7a4.4 4.4 0 0 1 7.7 3c0 4.9-7.7 9.5-7.7 9.5Z" />
  </svg>
);
export const IconSearch = (p: IconProps) => (
  <Svg {...p}><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" /></Svg>
);
export const IconBell = (p: IconProps) => (
  <Svg {...p}><path d="M6.5 9.5a5.5 5.5 0 0 1 11 0c0 4 1.5 5.5 1.5 5.5H5s1.5-1.5 1.5-5.5Z" /><path d="M10 18.5a2 2 0 0 0 4 0" /></Svg>
);
export const IconUser = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="8.5" r="3.5" /><path d="M5 20c0-3.3 3.1-5.5 7-5.5s7 2.2 7 5.5" /></Svg>
);
export const IconPlus = (p: IconProps) => (
  <Svg {...p}><path d="M12 5v14M5 12h14" /></Svg>
);
export const IconChevronDown = (p: IconProps) => <Svg {...p}><path d="m6 9.5 6 6 6-6" /></Svg>;
export const IconChevronUp = (p: IconProps) => <Svg {...p}><path d="m6 14.5 6-6 6 6" /></Svg>;
export const IconChevronLeft = (p: IconProps) => <Svg {...p}><path d="m14.5 6-6 6 6 6" /></Svg>;
export const IconChevronRight = (p: IconProps) => <Svg {...p}><path d="m9.5 6 6 6-6 6" /></Svg>;
export const IconArrowLeft = (p: IconProps) => <Svg {...p}><path d="M19 12H5" /><path d="m11 6-6 6 6 6" /></Svg>;
export const IconPlay = ({ size = 18, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M8 5.2v13.6L19 12 8 5.2Z" />
  </svg>
);
export const IconPause = ({ size = 18, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <rect x="7" y="5" width="3.4" height="14" rx="1" /><rect x="13.6" y="5" width="3.4" height="14" rx="1" />
  </svg>
);
export const IconVolume = (p: IconProps) => (
  <Svg {...p}><path d="M4 9.5h3L12 5.5v13L7 14.5H4z" /><path d="M15.5 9a4 4 0 0 1 0 6" /></Svg>
);
export const IconVolumeLow = (p: IconProps) => (
  <Svg {...p}><path d="M4 9.5h3L12 5.5v13L7 14.5H4z" /></Svg>
);
export const IconMuted = (p: IconProps) => (
  <Svg {...p}><path d="M4 9.5h3L12 5.5v13L7 14.5H4z" /><path d="m16 9.5 4.5 5M20.5 9.5l-4.5 5" /></Svg>
);
export const IconFullscreen = (p: IconProps) => (
  <Svg {...p}><path d="M4 9V4h5M20 15v5h-5M15 4h5v5M9 20H4v-5" /></Svg>
);
export const IconExitFullscreen = (p: IconProps) => (
  <Svg {...p}><path d="M9 4v5H4M15 20v-5h5M20 9h-5V4M4 15h5v5" /></Svg>
);
export const IconTheater = (p: IconProps) => (
  <Svg {...p}><rect x="3" y="6" width="18" height="12" rx="2" /><path d="M3 12h18" /></Svg>
);
export const IconSettings = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="12" r="3" /><path d="M19.2 14.2a7.6 7.6 0 0 0 0-4.4l1.6-1.2-1.6-2.8-1.9.8a7.6 7.6 0 0 0-3.8-2.2L13 2.5h-2l-.5 1.9a7.6 7.6 0 0 0-3.8 2.2l-1.9-.8-1.6 2.8 1.6 1.2a7.6 7.6 0 0 0 0 4.4l-1.6 1.2 1.6 2.8 1.9-.8a7.6 7.6 0 0 0 3.8 2.2l.5 1.9h2l.5-1.9a7.6 7.6 0 0 0 3.8-2.2l1.9.8 1.6-2.8-1.6-1.2Z" /></Svg>
);
export const IconPip = (p: IconProps) => (
  <Svg {...p}><rect x="3" y="5" width="18" height="13" rx="2" /><rect x="12" y="11" width="7" height="5.5" rx="1" /></Svg>
);
export const IconCaptions = (p: IconProps) => (
  <Svg {...p}><rect x="3" y="5.5" width="18" height="13" rx="2" /><path d="M10 10.5a2.5 2.5 0 1 0 0 3M17 10.5a2.5 2.5 0 1 0 0 3" /></Svg>
);
export const IconShare = (p: IconProps) => (
  <Svg {...p}><path d="M12 15V4" /><path d="m8 8 4-4 4 4" /><path d="M5 14v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-4" /></Svg>
);
export const IconLink = (p: IconProps) => (
  <Svg {...p}><path d="M10 13.5a3.5 3.5 0 0 0 5 0l3-3a3.5 3.5 0 0 0-5-5l-1.2 1.2" /><path d="M14 10.5a3.5 3.5 0 0 0-5 0l-3 3a3.5 3.5 0 0 0 5 5l1.2-1.2" /></Svg>
);
export const IconFlag = (p: IconProps) => (
  <Svg {...p}><path d="M6 21V4" /><path d="M6 5h10l-1.5 3.5L16 12H6" /></Svg>
);
export const IconVerified = ({ size = 14, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M12 2.2l2.4 1.9 3-.3 1 2.8 2.6 1.6-1 2.9 1 2.9-2.6 1.6-1 2.8-3-.3L12 21.8 9.6 20l-3 .3-1-2.8-2.6-1.6 1-2.9-1-2.9L5.6 7.5l1-2.8 3 .3L12 2.2Z" />
    <path d="m8.6 12.2 2.3 2.3 4.5-4.6" stroke="var(--surface-1)" strokeWidth="2.1" fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
export const IconShield = (p: IconProps) => (
  <Svg {...p}><path d="M12 3.5 19 6v5.5c0 4.2-3 7-7 9-4-2-7-4.8-7-9V6l7-2.5Z" /></Svg>
);
export const IconStar = (p: IconProps) => (
  <Svg {...p}><path d="m12 4 2.4 5 5.4.7-4 3.8 1 5.4-4.8-2.6L7.2 19l1-5.4-4-3.8 5.4-.7L12 4Z" /></Svg>
);
export const IconClose = (p: IconProps) => <Svg {...p}><path d="m6 6 12 12M18 6 6 18" /></Svg>;
export const IconMenu = (p: IconProps) => <Svg {...p}><path d="M4 7h16M4 12h16M4 17h16" /></Svg>;
export const IconSend = (p: IconProps) => (
  <Svg {...p}><path d="M4.5 12 20 4.5 15 19l-4-5.5-6.5-1.5Z" /></Svg>
);
export const IconSmile = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="12" r="8.5" /><path d="M9 14.5a4 4 0 0 0 6 0" /><path d="M9.3 9.5h.01M14.7 9.5h.01" strokeWidth="2.4" /></Svg>
);
export const IconMore = (p: IconProps) => (
  <Svg {...p}><circle cx="5.5" cy="12" r="1.4" fill="currentColor" /><circle cx="12" cy="12" r="1.4" fill="currentColor" /><circle cx="18.5" cy="12" r="1.4" fill="currentColor" /></Svg>
);
export const IconTrash = (p: IconProps) => (
  <Svg {...p}><path d="M5 7h14M9 7V4.5h6V7M7 7l.8 13h8.4L17 7" /><path d="M10 11v5M14 11v5" /></Svg>
);
export const IconPin = (p: IconProps) => (
  <Svg {...p}><path d="M9 4h6l-.7 5 3.2 3.2H6.5L9.7 9 9 4Z" /><path d="M12 12.2V20" /></Svg>
);
export const IconBan = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="12" r="8.5" /><path d="m6.5 17.5 11-11" /></Svg>
);
export const IconClock = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></Svg>
);
export const IconReply = (p: IconProps) => (
  <Svg {...p}><path d="M9 8 4 12.5 9 17" /><path d="M4 12.5h9.5A6.5 6.5 0 0 1 20 19" /></Svg>
);
export const IconEye = (p: IconProps) => (
  <Svg {...p}><path d="M2.5 12S6 6.5 12 6.5 21.5 12 21.5 12 18 17.5 12 17.5 2.5 12 2.5 12Z" /><circle cx="12" cy="12" r="2.6" /></Svg>
);
export const IconCalendar = (p: IconProps) => (
  <Svg {...p}><rect x="3.5" y="5.5" width="17" height="15" rx="2" /><path d="M3.5 10h17M8 3.5v4M16 3.5v4" /></Svg>
);
export const IconGrid = (p: IconProps) => (
  <Svg {...p}><rect x="3.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.5" /></Svg>
);
export const IconFilm = (p: IconProps) => (
  <Svg {...p}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M7 5v14M17 5v14M3 12h18" /></Svg>
);
export const IconScissors = (p: IconProps) => (
  <Svg {...p}><circle cx="6.5" cy="17.5" r="2.5" /><circle cx="6.5" cy="6.5" r="2.5" /><path d="M8.6 8.4 20 17M8.6 15.6 20 7" /></Svg>
);
export const IconTrophy = (p: IconProps) => (
  <Svg {...p}><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" /><path d="M8 5.5H5.5V8a3 3 0 0 0 3 3M16 5.5h2.5V8a3 3 0 0 1-3 3" /><path d="M12 13v4M9 20h6" /></Svg>
);
export const IconCoins = (p: IconProps) => (
  <Svg {...p}><ellipse cx="9" cy="7" rx="5" ry="2.4" /><path d="M4 7v4c0 1.3 2.2 2.4 5 2.4s5-1.1 5-2.4V7" /><ellipse cx="15" cy="15" rx="5" ry="2.4" /><path d="M10 15v3c0 1.3 2.2 2.4 5 2.4s5-1.1 5-2.4v-3" /></Svg>
);
export const IconGift = (p: IconProps) => (
  <Svg {...p}><rect x="3.5" y="9" width="17" height="11" rx="1.6" /><path d="M3.5 13h17M12 9v11" /><path d="M12 9S9.5 4.5 7.5 6s1.5 3 4.5 3c3 0 6.5-1.5 4.5-3S12 9 12 9Z" /></Svg>
);
export const IconRefresh = (p: IconProps) => (
  <Svg {...p}><path d="M19.5 12a7.5 7.5 0 1 1-2.4-5.5" /><path d="M19.5 4v4h-4" /></Svg>
);
export const IconAlert = (p: IconProps) => (
  <Svg {...p}><path d="M12 4.5 21 19H3l9-14.5Z" /><path d="M12 10v4M12 16.6h.01" strokeWidth="2" /></Svg>
);
export const IconCheck = (p: IconProps) => <Svg {...p}><path d="m5 12.5 4.5 4.5L19 7" /></Svg>;
export const IconWifiOff = (p: IconProps) => (
  <Svg {...p}><path d="M3 8.5a14 14 0 0 1 5-3M16.5 6a14 14 0 0 1 4.5 2.5" /><path d="M6.5 12a9 9 0 0 1 3-1.8M15 10.5a9 9 0 0 1 2.5 1.5" /><path d="M9.5 15.4a4 4 0 0 1 5 0" /><path d="M12 18.5h.01" strokeWidth="2.4" /><path d="m3 3 18 18" /></Svg>
);
export const IconExternal = (p: IconProps) => (
  <Svg {...p}><path d="M14 4h6v6" /><path d="M20 4 11 13" /><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4" /></Svg>
);
export const IconLive = (p: IconProps) => (
  <Svg {...p}><circle cx="12" cy="12" r="3" /><path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 16.2a6 6 0 0 0 0-8.4" /></Svg>
);
export const IconSliders = (p: IconProps) => (
  <Svg {...p}><path d="M5 7h14M5 17h14" /><circle cx="9.5" cy="7" r="2" /><circle cx="14.5" cy="17" r="2" /></Svg>
);
export const IconVideo = (p: IconProps) => (
  <Svg {...p}><rect x="3" y="6" width="12" height="12" rx="2.5" /><path d="m15 11 5.5-3v8L15 13" /></Svg>
);
export const IconChat = (p: IconProps) => (
  <Svg {...p}><path d="M4 5.5h16v10H9l-5 4v-14Z" /></Svg>
);
export const IconVolumeFilled = (p: IconProps) => (
  <Svg {...p}><path d="M4 9.5h3L12 5.5v13L7 14.5H4z" /><path d="M15.5 9a4 4 0 0 1 0 6M17.8 6.5a7.5 7.5 0 0 1 0 11" /></Svg>
);
export const IconKeyboard = (p: IconProps) => (
  <Svg {...p}><rect x="2.5" y="6.5" width="19" height="11" rx="2" /><path d="M6 10h.01M9.5 10h.01M13 10h.01M16.5 10h.01M8 14h8" strokeWidth="1.8" /></Svg>
);
