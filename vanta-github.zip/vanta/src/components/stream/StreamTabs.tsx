import { useState } from "react";
import { api } from "../../api/mockApi";
import type { Stream, User } from "../../types";
import { cx, formatDuration, formatRelative, formatScheduleTime, WEEKDAYS } from "../../lib/utils";
import { useAsync } from "../../state/useAsync";
import { routes } from "../../lib/router";
import {
  IconCalendar,
  IconChat,
  IconExternal,
  IconFilm,
  IconHeart,
  IconScissors,
  IconStar,
  IconTrophy,
} from "../icons";
import { Avatar, CardSkeleton, EmptyState, ErrorState } from "../ui/primitives";
import { ChannelRow, ClipTile, VodTile } from "../discovery/Cards";
import { CommunityPanel } from "../widgets/Community";

type TabId = "about" | "schedule" | "clips" | "vods" | "community";

const TABS: Array<{ id: TabId; label: string; icon: React.ReactNode }> = [
  { id: "about", label: "About", icon: <IconHeart size={14} /> },
  { id: "schedule", label: "Schedule", icon: <IconCalendar size={14} /> },
  { id: "clips", label: "Clips", icon: <IconScissors size={14} /> },
  { id: "vods", label: "Past broadcasts", icon: <IconFilm size={14} /> },
  { id: "community", label: "Community", icon: <IconTrophy size={14} /> },
];

/* -------------------------------------------------------------------------- */
/* panels                                                                     */
/* -------------------------------------------------------------------------- */

function AboutPanel({ stream }: { stream: Stream }) {
  const [expanded, setExpanded] = useState(false);
  const channel = stream.channel;
  const bio = channel.bio;
  const long = bio.length > 190;

  return (
    <div className="about">
      <div className="about__bio">
        <p className={cx(!expanded && long && "clamp-3")}>{bio}</p>
        {long && (
          <button className="about__more" onClick={() => setExpanded((v) => !v)}>
            {expanded ? "Show less" : "Read more"}
          </button>
        )}
      </div>
      <dl className="about__stats">
        <div>
          <dt>Followers</dt>
          <dd className="mono">{channel.followerCount.toLocaleString()}</dd>
        </div>
        {channel.subscriberCount != null && (
          <div>
            <dt>Subscribers</dt>
            <dd className="mono">{channel.subscriberCount.toLocaleString()}</dd>
          </div>
        )}
        <div>
          <dt>Language</dt>
          <dd>{channel.language}</dd>
        </div>
        <div>
          <dt>Category</dt>
          <dd>{stream.category?.name ?? "—"}</dd>
        </div>
        <div>
          <dt>Channel since</dt>
          <dd>{new Date(channel.createdAt).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</dd>
        </div>
        <div>
          <dt>This session</dt>
          <dd className="mono">+{stream.stats.followerGain.toLocaleString()} followers</dd>
        </div>
      </dl>
      {channel.socials.length > 0 && (
        <div className="about__socials">
          {channel.socials.map((s) => (
            <a key={s.kind} className="chip chip--link" href={s.href} target="_blank" rel="noreferrer noopener">
              {s.label}
              <IconExternal size={11} />
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

function SchedulePanel({ stream }: { stream: Stream }) {
  const schedule = [...stream.channel.schedule].sort((a, b) => a.dayOfWeek - b.dayOfWeek);
  if (!schedule.length) {
    return (
      <EmptyState
        icon={<IconCalendar size={22} />}
        title="No schedule published"
        description={`${stream.channel.displayName} hasn't posted a recurring schedule yet.`}
      />
    );
  }
  const today = new Date().getDay();
  return (
    <ul className="schedule">
      {schedule.map((entry, i) => (
        <li key={`${entry.dayOfWeek}-${entry.startTime}-${i}`} className={cx("schedule__row", entry.dayOfWeek === today && "is-today")}>
          <span className="schedule__day">
            {WEEKDAYS[entry.dayOfWeek]}
            {entry.dayOfWeek === today && <span className="schedule__now">today</span>}
          </span>
          <span className="schedule__time mono">{formatScheduleTime(entry.startTime)}</span>
          <span className="schedule__title truncate">{entry.title}</span>
          <span className="schedule__meta">{entry.categoryName} · {formatDuration(entry.durationMinutes * 60)}</span>
        </li>
      ))}
    </ul>
  );
}

function ClipsPanel({ stream }: { stream: Stream }) {
  const clips = useAsync(() => api.getClips(stream.channel.id), [stream.channel.id]);
  if (clips.loading) {
    return (
      <div className="tile-grid">
        {[0, 1, 2, 3].map((i) => (
          <CardSkeleton key={i} />
        ))}
      </div>
    );
  }
  if (clips.error) return <ErrorState error={clips.error} onRetry={clips.reload} />;
  if (!clips.data?.length) {
    return (
      <EmptyState
        icon={<IconScissors size={22} />}
        title="No clips yet"
        description="Clips created during this channel's streams will appear here."
      />
    );
  }
  return (
    <div className="tile-grid">
      {clips.data.map((clip) => (
        <ClipTile key={clip.id} clip={clip} href={`${routes.channel(stream.channel.slug)}?clip=${clip.id}`} />
      ))}
    </div>
  );
}

function VodsPanel({ stream }: { stream: Stream }) {
  const vods = useAsync(() => api.getVods(stream.channel.id), [stream.channel.id]);
  if (vods.loading) {
    return (
      <div className="tile-grid">
        {[0, 1, 2].map((i) => (
          <CardSkeleton key={i} />
        ))}
      </div>
    );
  }
  if (vods.error) return <ErrorState error={vods.error} onRetry={vods.reload} />;
  if (!vods.data?.length) {
    return (
      <EmptyState
        icon={<IconFilm size={22} />}
        title="No past broadcasts"
        description="This channel has no public VODs. Streams may expire after 14 days."
      />
    );
  }
  return (
    <div className="tile-grid">
      {vods.data.map((vod) => (
        <VodTile key={vod.id} vod={vod} href={`${routes.channel(stream.channel.slug)}?vod=${vod.id}`} />
      ))}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* tabs                                                                       */
/* -------------------------------------------------------------------------- */

export function StreamTabs({ stream, user }: { stream: Stream; user: User | null }) {
  const [tab, setTab] = useState<TabId>("about");

  return (
    <section className="tabs" aria-label="Stream details">
      <div className="tabs__list" role="tablist" aria-label="Stream information">
        {TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            id={`tab-${t.id}`}
            aria-selected={tab === t.id}
            aria-controls={`panel-${t.id}`}
            tabIndex={tab === t.id ? 0 : -1}
            className={cx("tabs__tab", tab === t.id && "is-active")}
            onClick={() => setTab(t.id)}
            onKeyDown={(e) => {
              const idx = TABS.findIndex((x) => x.id === tab);
              if (e.key === "ArrowRight") {
                e.preventDefault();
                const next = TABS[(idx + 1) % TABS.length];
                setTab(next.id);
                document.getElementById(`tab-${next.id}`)?.focus();
              }
              if (e.key === "ArrowLeft") {
                e.preventDefault();
                const prev = TABS[(idx - 1 + TABS.length) % TABS.length];
                setTab(prev.id);
                document.getElementById(`tab-${prev.id}`)?.focus();
              }
            }}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      <div className="tabs__panel" role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`} tabIndex={0}>
        {tab === "about" && <AboutPanel stream={stream} />}
        {tab === "schedule" && <SchedulePanel stream={stream} />}
        {tab === "clips" && <ClipsPanel stream={stream} />}
        {tab === "vods" && <VodsPanel stream={stream} />}
        {tab === "community" && <CommunityPanel stream={stream} user={user} />}
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/* related streams                                                            */
/* -------------------------------------------------------------------------- */

export function RelatedStreams({ streams, title }: { streams: Stream[]; title: string }) {
  if (!streams.length) return null;
  return (
    <section className="related" aria-label={title}>
      <div className="section-head">
        <h2 className="section-head__title">
          <IconChat size={15} aria-hidden="true" /> {title}
        </h2>
      </div>
      <div className="related__list">
        {streams.slice(0, 6).map((s) => (
          <ChannelRow
            key={s.id}
            channel={s.channel}
            live={s.state === "live"}
            viewers={s.viewerCount}
            categoryName={s.category?.name}
          />
        ))}
      </div>
    </section>
  );
}

export function ChannelCard({ stream }: { stream: Stream }) {
  const c = stream.channel;
  return (
    <section className="panel channel-card">
      <div className="panel-head">
        <h3 className="panel-title">
          <IconStar size={14} /> Channel
        </h3>
      </div>
      <div className="channel-card__body">
        <div className="channel-card__head">
          <Avatar src={c.avatarUrl} name={c.displayName} size={44} ring />
          <div>
            <p className="channel-card__name">{c.displayName}</p>
            <p className="channel-card__meta">
              {c.language} · {c.followerCount.toLocaleString()} followers
            </p>
          </div>
        </div>
        <p className="channel-card__bio clamp-3">{c.bio}</p>
      </div>
      {c.socials.length > 0 && (
        <div className="channel-card__socials">
          {c.socials.map((s) => (
            <a key={s.kind} className="chip chip--link" href={s.href} target="_blank" rel="noreferrer noopener">
              {s.label}
              <IconExternal size={11} />
            </a>
          ))}
        </div>
      )}
      <p className="channel-card__updated">Last updated {formatRelative(c.createdAt)}</p>
    </section>
  );
}
