import { useCallback, useMemo, useRef, useState } from "react";
import type { Channel, FollowAlerts, Stream, User } from "../../types";
import { ApiError } from "../../types";
import { cx, copyToClipboard, formatCount, formatFull, formatUptime, useNow } from "../../lib/utils";
import { routes } from "../../lib/router";
import { api } from "../../api/mockApi";
import {
  IconBell,
  IconChevronDown,
  IconEye,
  IconFlag,
  IconHeart,
  IconHeartFilled,
  IconLink,
  IconScissors,
  IconShare,
  IconStar,
  IconVerified,
} from "../icons";
import { Avatar, LiveBadge, Thumb } from "../ui/primitives";
import { Popover } from "../ui/Popover";
import { useToast } from "../ui/Toast";

/* -------------------------------------------------------------------------- */
/* follow                                                                     */
/* -------------------------------------------------------------------------- */

function FollowButton({
  channel,
  user,
  onChange,
}: {
  channel: Channel;
  user: User | null;
  onChange: (next: { following: boolean; followerCount: number }) => void;
}) {
  const toast = useToast();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inFlight = useRef(false);
  const following = channel.viewerIsFollowing ?? false;

  const toggle = useCallback(async () => {
    // hard guard against double submits (fast double-click, retry storms)
    if (inFlight.current) return;
    inFlight.current = true;
    setPending(true);
    setError(null);
    const previous = { following, followerCount: channel.followerCount };
    // optimistic
    onChange({ following: !following, followerCount: channel.followerCount + (following ? -1 : 1) });
    try {
      const result = await api.setFollow(channel.id, !following);
      onChange(result);
      toast.success(following ? `Unfollowed ${channel.displayName}` : `Following ${channel.displayName}`);
    } catch (err) {
      const e = err instanceof ApiError ? err : new ApiError("server_error", "Could not update follow state.");
      // roll back to the server-confirmed truth
      onChange(previous);
      setError(e.message);
      toast.error("Follow failed", e.message);
    } finally {
      setPending(false);
      inFlight.current = false;
    }
  }, [channel, following, onChange, toast]);

  return (
    <div className="follow">
      <button
        className={cx("btn", following ? "btn--ghost" : "btn--primary", "follow__btn")}
        onClick={() => void toggle()}
        disabled={pending}
        aria-pressed={following}
        aria-busy={pending}
        title={user ? undefined : "Sign in to follow"}
      >
        {following ? <IconHeartFilled size={15} /> : <IconHeart size={15} />}
        {pending ? "Working…" : following ? "Following" : "Follow"}
      </button>

      <Popover
        label="Notification preferences"
        align="start"
        width={240}
        trigger={({ toggle: openPrefs }) => (
          <button
            className="btn btn--ghost follow__alerts"
            onClick={openPrefs}
            aria-label="Follow notification preferences"
            disabled={!following}
          >
            <IconBell size={15} />
          </button>
        )}
      >
        {(close) => (
          <div className="menu" role="menu" aria-label="Follow notifications">
            <p className="menu__note menu__note--tight">Notify me when {channel.displayName}…</p>
            {(
              [
                ["all", "Goes live and uploads"],
                ["live", "Goes live only"],
                ["none", "Never"],
              ] as Array<[FollowAlerts, string]>
            ).map(([value, label]) => (
              <button
                key={value}
                role="menuitemradio"
                aria-checked={channel.viewerFollowAlerts === value}
                className={cx("menu__item", channel.viewerFollowAlerts === value && "is-active")}
                onClick={() => {
                  void (async () => {
                    try {
                      await api.setFollowAlerts(channel.id, value);
                      toast.success("Notification preference saved");
                    } catch (err) {
                      toast.error("Could not save preference", err instanceof ApiError ? err.message : undefined);
                    }
                  })();
                  close();
                }}
              >
                <span className="menu__label">{label}</span>
              </button>
            ))}
          </div>
        )}
      </Popover>

      {error && (
        <span className="follow__error" role="alert">
          {error}
        </span>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* trend sparkline                                                            */
/* -------------------------------------------------------------------------- */

function Trend({ data, peak }: { data: number[]; peak: number }) {
  if (data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const points = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * 100;
      const y = 22 - ((v - min) / Math.max(1, max - min)) * 20;
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <span className="trend" title={`Peak ${formatFull(peak)} this session`}>
      <svg viewBox="0 0 100 24" preserveAspectRatio="none" aria-hidden="true" className="trend__svg">
        <polyline points={points} fill="none" stroke="var(--trust)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
      </svg>
      <span className="trend__label">peak {formatCount(peak)}</span>
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/* header                                                                     */
/* -------------------------------------------------------------------------- */

export function StreamHeader({
  stream,
  user,
  onChannelChange,
  onOpenSubscribe,
  onOpenReport,
  onOpenClip,
}: {
  stream: Stream;
  user: User | null;
  onChannelChange: (next: { following: boolean; followerCount: number }) => void;
  onOpenSubscribe: () => void;
  onOpenReport: () => void;
  onOpenClip: () => void;
}) {
  const toast = useToast();
  const now = useNow(1000, stream.state === "live");
  const [shareBusy, setShareBusy] = useState(false);

  const url = useMemo(
    () => `${location.origin}${location.pathname}${routes.channel(stream.channel.slug)}`,
    [stream.channel.slug],
  );

  const share = async () => {
    setShareBusy(true);
    try {
      if (navigator.share) {
        await navigator.share({ title: stream.title, url });
        return;
      }
      const ok = await copyToClipboard(url);
      if (ok) toast.success("Link copied");
      else toast.error("Could not copy", "Copy the URL from the address bar instead.");
    } catch (err) {
      // AbortError = the user dismissed the native share sheet; not a failure
      if (!(err instanceof DOMException && err.name === "AbortError")) {
        toast.error("Sharing failed");
      }
    } finally {
      setShareBusy(false);
    }
  };

  const copyLink = async () => {
    const ok = await copyToClipboard(url);
    if (ok) toast.success("Link copied to clipboard");
    else toast.error("Could not copy the link");
  };

  const category = stream.category;

  return (
    <header className="stream-head">
      <div className="stream-head__main">
        <div className="stream-head__identity">
          <a className="stream-head__avatar" href={routes.channel(stream.channel.slug)} aria-label={stream.channel.displayName}>
            <Avatar src={stream.channel.avatarUrl} name={stream.channel.displayName} size={52} ring />
          </a>
          <div className="stream-head__who">
            <p className="stream-head__channel">
              <a href={routes.channel(stream.channel.slug)} className="stream-head__channel-link">
                {stream.channel.displayName}
              </a>
              {stream.channel.verified && (
                <span className="verified" title="Verified channel">
                  <IconVerified size={14} />
                  <span className="sr-only">Verified</span>
                </span>
              )}
              <span className="stream-head__followers mono" title={`${formatFull(stream.channel.followerCount)} followers`}>
                {formatCount(stream.channel.followerCount)} followers
              </span>
            </p>
            <h1 className="stream-head__title" title={stream.title}>
              {stream.title}
            </h1>

            <div className="stream-head__meta">
              {stream.state === "live" ? (
                <LiveBadge />
              ) : (
                <span className="chip chip--muted">{stream.state.toUpperCase()}</span>
              )}
              {stream.state === "live" && stream.startedAt && (
                <span className="chip chip--quiet mono" title="Stream duration">
                  {formatUptime(stream.startedAt, now)}
                </span>
              )}
              <span className="stream-head__viewers">
                <IconEye size={14} aria-hidden="true" />
                <span className="mono">{formatCount(stream.viewerCount)}</span>
                <span className="stream-head__viewers-label">watching</span>
              </span>
              {stream.state === "live" && <Trend data={stream.stats.viewerTrend} peak={stream.stats.peakViewers} />}
              {category && (
                <a className="stream-head__category" href={routes.browse(category.slug)}>
                  <Thumb src={category.artUrl} alt="" className="stream-head__cat-art" ratio="1 / 1" />
                  <span>{category.name}</span>
                </a>
              )}
              <span className="chip chip--quiet">{stream.language}</span>
              {stream.tags.slice(1).map((tag) => (
                <span key={tag} className="chip chip--quiet">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="stream-head__actions">
          <FollowButton channel={stream.channel} user={user} onChange={onChannelChange} />

          {stream.channel.subscriptionsEnabled && (
            <button className="btn btn--trust subscribe-btn" onClick={onOpenSubscribe}>
              <IconStar size={15} />
              Subscribe
              {stream.channel.subscriberCount != null && (
                <span className="subscribe-btn__count mono">{formatCount(stream.channel.subscriberCount)}</span>
              )}
            </button>
          )}

          <button
            className="btn btn--ghost stream-head__share"
            onClick={() => void share()}
            disabled={shareBusy}
            aria-label="Share stream"
          >
            <IconShare size={15} aria-hidden="true" />
            <span aria-hidden="true">Share</span>
          </button>

          <Popover
            label="More actions"
            align="end"
            width={240}
            trigger={({ toggle }) => (
              <button
                className="icon-btn stream-head__more"
                onClick={toggle}
                aria-label="More stream actions"
                data-dialog-return
              >
                <IconChevronDown size={17} />
              </button>
            )}
          >
            {(close) => (
              <div className="menu" role="menu">
                <button className="menu__item" role="menuitem" onClick={() => { void copyLink(); close(); }}>
                  <IconLink size={15} /> Copy link
                </button>
                <button
                  className="menu__item"
                  role="menuitem"
                  disabled={!stream.viewerCanCreateClip}
                  aria-label={stream.viewerCanCreateClip ? "Create a clip" : "Clip creation unavailable for this stream"}
                  onClick={() => {
                    onOpenClip();
                    close();
                  }}
                >
                  <IconScissors size={15} /> Create clip
                  {!stream.viewerCanCreateClip && <span className="menu__hint">unavailable</span>}
                </button>
                <div className="menu__divider" role="separator" />
                <button
                  className="menu__item menu__item--danger"
                  role="menuitem"
                  onClick={() => {
                    onOpenReport();
                    close();
                  }}
                >
                  <IconFlag size={15} /> Report stream
                </button>
              </div>
            )}
          </Popover>
        </div>
      </div>
    </header>
  );
}
