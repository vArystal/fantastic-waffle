import { useEffect, useMemo, useRef, useState } from "react";
import { api, chatTransport } from "../../api/mockApi";
import { demoStore, type ForcedStreamState, type NetworkProfile, type PersonaId } from "../../api/demo";
import type { Channel, Stream, User } from "../../types";
import { ApiError } from "../../types";
import { cx, formatDuration } from "../../lib/utils";
import { usePlayerActions, usePlayerTime } from "../player/PlayerContext";
import { playerBridge } from "../../state/playerBridge";
import { Dialog, useToast } from "../ui/Toast";
import { IconAlert, IconCheck, IconScissors, IconStar } from "../icons";
import { Spinner } from "../ui/primitives";

/* -------------------------------------------------------------------------- */
/* report                                                                     */
/* -------------------------------------------------------------------------- */

const REPORT_REASONS = [
  "Harassment or hateful conduct",
  "Spam, scams or deceptive links",
  "Graphic or mature content in the wrong category",
  "Copyright infringement",
  "Other",
];

export function ReportDialog({
  open,
  onClose,
  targetType,
  targetId,
  targetLabel,
}: {
  open: boolean;
  onClose: () => void;
  targetType: "stream" | "channel" | "chat_message";
  targetId: string;
  targetLabel: string;
}) {
  const toast = useToast();
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setReason("");
      setDetails("");
      setError(null);
    }
  }, [open]);

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.report({ targetType, targetId, reason, details });
      toast.success("Report submitted", "Our moderation team will review it.");
      onClose();
    } catch (err) {
      const e = err instanceof ApiError ? err : new ApiError("server_error", "Report failed.");
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Report"
      description={`Reporting: ${targetLabel}`}
      footer={
        <>
          <button className="btn btn--quiet" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <button className="btn btn--danger" onClick={() => void submit()} disabled={!reason || busy}>
            {busy ? <Spinner size={14} /> : null} Submit report
          </button>
        </>
      }
    >
      <fieldset className="report">
        <legend className="sr-only">Reason for report</legend>
        {REPORT_REASONS.map((r) => (
          <label key={r} className={cx("report__option", reason === r && "is-selected")}>
            <input type="radio" name="report-reason" value={r} checked={reason === r} onChange={() => setReason(r)} />
            <span>{r}</span>
          </label>
        ))}
      </fieldset>
      <label className="field field--textarea">
        <span className="sr-only">Additional details</span>
        <textarea
          rows={3}
          maxLength={500}
          placeholder="Add context (optional)"
          value={details}
          onChange={(e) => setDetails(e.target.value)}
        />
      </label>
      {error && (
        <p className="form-error" role="alert">
          <IconAlert size={14} /> {error}
        </p>
      )}
      <p className="dialog__note">
        Reports are validated server-side and rate limited. False reports can affect your account standing.
      </p>
    </Dialog>
  );
}

/* -------------------------------------------------------------------------- */
/* clip                                                                       */
/* -------------------------------------------------------------------------- */

export function ClipDialog({ open, onClose, stream }: { open: boolean; onClose: () => void; stream: Stream }) {
  const { currentTime } = usePlayerTime();
  const { pause } = usePlayerActions();
  const toast = useToast();
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [start, setStart] = useState(0);

  useEffect(() => {
    if (!open) return;
    pause();
    setStart(Math.max(0, currentTime - 15));
    setTitle("");
    setError(null);
    // capture the position once, on open
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const end = Math.min(start + 30, Math.max(start + 5, currentTime + 2));
  const length = Math.max(0, end - start);
  const dvrEnabled = stream.playback?.dvr.enabled ?? false;

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.createClip({ streamId: stream.id, startSeconds: start, endSeconds: end, title });
      toast.success("Clip created", "It will appear in the Clips tab.");
      onClose();
    } catch (err) {
      const e = err instanceof ApiError ? err : new ApiError("server_error", "Clip creation failed.");
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Create a clip"
      description={dvrEnabled ? "Clips are cut from the available DVR window." : "This stream has no DVR window."}
      footer={
        <>
          <button className="btn btn--quiet" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <button className="btn btn--primary" onClick={() => void submit()} disabled={!dvrEnabled || title.trim().length < 3 || busy}>
            {busy ? <Spinner size={14} /> : <IconScissors size={14} />} Create clip
          </button>
        </>
      }
    >
      {!dvrEnabled ? (
        <p className="form-error" role="alert">
          <IconAlert size={14} /> Clipping requires a DVR window. This stream does not publish one, so the action is
          unavailable rather than silently failing.
        </p>
      ) : (
        <>
          <div className="clip-range">
            <div>
              <span className="eyebrow">Start</span>
              <span className="mono">{formatDuration(start)}</span>
            </div>
            <div className="clip-range__bar" aria-hidden="true" />
            <div>
              <span className="eyebrow">End</span>
              <span className="mono">{formatDuration(end)}</span>
            </div>
            <div>
              <span className="eyebrow">Length</span>
              <span className="mono">{formatDuration(length)}</span>
            </div>
          </div>
          <label className="field">
            <span className="sr-only">Clip title</span>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Give the clip a title"
              maxLength={80}
              autoFocus
            />
          </label>
          <p className="dialog__note">Clips must be between 5 and 60 seconds. The server validates the range.</p>
        </>
      )}
      {error && (
        <p className="form-error" role="alert">
          <IconAlert size={14} /> {error}
        </p>
      )}
    </Dialog>
  );
}

/* -------------------------------------------------------------------------- */
/* subscribe                                                                  */
/* -------------------------------------------------------------------------- */

export function SubscribeDialog({
  open,
  onClose,
  channel,
}: {
  open: boolean;
  onClose: () => void;
  channel: Channel;
}) {
  const tiers = [
    { id: "t1", name: "Tier 1", price: "monthly", perks: ["Subscriber badge", "Ad-free viewing", "Channel emotes"] },
    { id: "t2", name: "Tier 2", price: "monthly", perks: ["Everything in Tier 1", "Extra emote slots", "Sub-only chat rooms"] },
    { id: "t3", name: "Tier 3", price: "monthly", perks: ["Everything in Tier 2", "Monthly VOD review", "Priority in viewer queue"] },
  ];
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={`Subscribe to ${channel.displayName}`}
      description="Support the channel and unlock subscriber perks."
      width={520}
      footer={
        <button className="btn btn--quiet" onClick={onClose}>
          Close
        </button>
      }
    >
      <div className="tiers">
        {tiers.map((t) => (
          <div className="tier" key={t.id}>
            <div className="tier__head">
              <span className="tier__name">
                <IconStar size={14} /> {t.name}
              </span>
              <span className="tier__price">billing per month</span>
            </div>
            <ul className="tier__perks">
              {t.perks.map((p) => (
                <li key={p}>
                  <IconCheck size={12} /> {p}
                </li>
              ))}
            </ul>
            <button className="btn btn--ghost btn--block" disabled title="Billing service is not connected in this environment">
              Continue to checkout
            </button>
          </div>
        ))}
      </div>
      <p className="dialog__note">
        Checkout is intentionally disabled: this deployment has no billing or payment service. Prices and entitlements
        must come from the subscriptions API — no client-side price is invented here.
      </p>
    </Dialog>
  );
}

/* -------------------------------------------------------------------------- */
/* keyboard shortcuts                                                         */
/* -------------------------------------------------------------------------- */

const SHORTCUTS: Array<[string, string]> = [
  ["Space / K", "Play or pause"],
  ["M", "Mute or unmute"],
  ["F", "Toggle fullscreen"],
  ["T", "Toggle theater mode"],
  ["C", "Toggle captions"],
  ["← / →", "Seek 5s (Shift for 30s) — when the timeline is focused"],
  ["Home / End", "Jump to start or end of the DVR window"],
  ["?", "Open this dialog"],
  ["Esc", "Close dialogs and popovers"],
];

export function ShortcutsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onClose={onClose} title="Keyboard shortcuts" description="Active while the player is on screen and focus is not in a text field.">
      <ul className="shortcuts">
        {SHORTCUTS.map(([key, label]) => (
          <li key={key}>
            <kbd>{key}</kbd>
            <span>{label}</span>
          </li>
        ))}
      </ul>
    </Dialog>
  );
}

/* -------------------------------------------------------------------------- */
/* demo panel                                                                 */
/* -------------------------------------------------------------------------- */

const NETWORKS: Array<[NetworkProfile, string, string]> = [
  ["fast", "Fast", "~150ms responses"],
  ["slow", "Slow 3G", "1–2s responses, tests skeletons"],
  ["flaky", "Flaky", "~28% of requests fail"],
  ["offline", "Offline", "all requests fail"],
];

const PERSONAS: Array<[PersonaId, string]> = [
  ["guest", "Guest (signed out)"],
  ["viewer", "Viewer"],
  ["subscriber", "Subscriber"],
  ["moderator", "Moderator"],
  ["streamer", "Broadcaster"],
];

const STREAM_STATES: Array<[ForcedStreamState, string]> = [
  ["auto", "Auto (from data)"],
  ["live", "Live"],
  ["offline", "Offline"],
  ["scheduled", "Scheduled"],
  ["ended", "Ended"],
  ["restricted", "Restricted"],
];

export function DemoPanel({
  open,
  onClose,
  stream,
}: {
  open: boolean;
  onClose: () => void;
  stream: Stream | null;
}) {
  const [state, setState] = useState(demoStore.get());
  const toast = useToast();
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    const unsubscribe = demoStore.subscribe(() => {
      if (mounted.current) setState(demoStore.get());
    });
    return () => {
      mounted.current = false;
      unsubscribe();
    };
  }, []);

  const update = (patch: Partial<typeof state>) => {
    demoStore.set(patch);
    setState(demoStore.get());
  };

  const networkLabel = useMemo(() => NETWORKS.find(([id]) => id === state.network)?.[1] ?? "", [state.network]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Demo controls"
      description="These switches exist because this build has no backend. They exercise the failure paths the real app must handle."
      width={560}
      footer={
        <button className="btn btn--quiet" onClick={onClose}>
          Done
        </button>
      }
    >
      <div className="demo">
        <section className="demo__group">
          <h3 className="demo__title">Signed in as</h3>
          <p className="demo__hint">Permissions are enforced by the service layer, not the UI.</p>
          <div className="demo__segmented" role="radiogroup" aria-label="Session role">
            {PERSONAS.map(([id, label]) => (
              <button
                key={id}
                role="radio"
                aria-checked={state.persona === id}
                className={cx("demo__seg", state.persona === id && "is-active")}
                onClick={() => update({ persona: id })}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="demo__group">
          <h3 className="demo__title">Network</h3>
          <p className="demo__hint">Simulates API latency and failure. Currently: {networkLabel}.</p>
          <div className="demo__segmented" role="radiogroup" aria-label="Network profile">
            {NETWORKS.map(([id, label, desc]) => (
              <button
                key={id}
                role="radio"
                aria-checked={state.network === id}
                className={cx("demo__seg", state.network === id && "is-active")}
                onClick={() => update({ network: id })}
                title={desc}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="demo__group">
          <h3 className="demo__title">Stream state</h3>
          <p className="demo__hint">Overrides the stream status to preview non-live states.</p>
          <div className="demo__segmented" role="radiogroup" aria-label="Stream state">
            {STREAM_STATES.map(([id, label]) => (
              <button
                key={id}
                role="radio"
                aria-checked={state.forcedStreamState === id}
                className={cx("demo__seg", state.forcedStreamState === id && "is-active")}
                onClick={() => update({ forcedStreamState: id })}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="demo__group">
          <h3 className="demo__title">Connection faults</h3>
          <div className="demo__actions">
            <button
              className="btn btn--ghost btn--sm"
              onClick={() => {
                playerBridge.interrupt?.();
                onClose();
                toast.push({ title: "Playback interrupted", description: "The player will attempt to reconnect.", tone: "info" });
              }}
              disabled={!stream?.playback}
            >
              Interrupt playback
            </button>
            <button
              className="btn btn--ghost btn--sm"
              onClick={() => {
                chatTransport.simulateDrop();
                toast.push({ title: "Chat socket dropped", description: "Reconnecting with backoff.", tone: "info" });
              }}
            >
              Drop chat socket
            </button>
            <label className="demo__toggle">
              <input
                type="checkbox"
                checked={state.chatOffline}
                onChange={(e) => {
                  update({ chatOffline: e.target.checked });
                  if (e.target.checked) chatTransport.simulateDrop();
                }}
              />
              <span>Keep chat offline</span>
            </label>
          </div>
        </section>

        <section className="demo__group demo__group--note">
          <h3 className="demo__title">What is not simulated</h3>
          <ul className="demo__list">
            <li>Payments, subscriptions checkout and reward redemption return <code>unsupported</code>.</li>
            <li>Abuse protection (rate limits, duplicate detection) is implemented in the mock service layer and mirrored by the UI.</li>
            <li>No stream keys, playback tokens or private viewer data exist in this build.</li>
          </ul>
        </section>
      </div>
    </Dialog>
  );
}

/* -------------------------------------------------------------------------- */
/* sign-in prompt                                                             */
/* -------------------------------------------------------------------------- */

export function SignInDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Sign in"
      description="Authentication is not connected in this demo build."
      footer={
        <>
          <button className="btn btn--quiet" onClick={onClose}>
            Cancel
          </button>
          <button
            className="btn btn--primary"
            onClick={() => {
              demoStore.set({ persona: "subscriber" });
              onClose();
            }}
          >
            Continue as demo subscriber
          </button>
        </>
      }
    >
      <p className="dialog__note">
        The real sign-in flow must go through the existing auth provider. This button only switches the local demo
        persona so permission-dependent UI can be reviewed.
      </p>
      <p className="dialog__note">
        <strong>Note:</strong> the API enforces permissions server-side, so switching persona changes what the mock
        service will accept — it is not a client-side bypass.
      </p>
    </Dialog>
  );
}

export type { User, Stream };
