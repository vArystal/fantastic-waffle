import { memo } from "react";
import type { Category, Channel } from "../../types";
import { cx, formatCount, formatDuration, formatRelative } from "../../lib/utils";
import { routes } from "../../lib/router";
import { IconEye, IconHeartFilled, IconVerified } from "../icons";
import { Avatar, LiveBadge, Thumb } from "../ui/primitives";

/* -------------------------------------------------------------------------- */
/* stream card                                                                */
/* -------------------------------------------------------------------------- */

export interface StreamCardData {
  slug: string;
  title: string;
  channelName: string;
  channelSlug: string;
  avatarUrl: string | null;
  verified: boolean;
  thumbnailUrl: string | null;
  categoryName: string | null;
  viewerCount: number;
  tags: string[];
  isLive: boolean;
  language: string;
  /** e.g. "Ended 1h ago" for non-live cards */
  statusLabel?: string | null;
}

export const StreamCard = memo(function StreamCard({
  data,
  size = "md",
  priority = false,
}: {
  data: StreamCardData;
  size?: "sm" | "md" | "lg";
  priority?: boolean;
}) {
  return (
    <a className={cx("card", `card--${size}`)} href={routes.channel(data.channelSlug)}>
      <Thumb src={data.thumbnailUrl} alt="" priority={priority} className="card__thumb">
        {data.isLive ? (
          <>
            <LiveBadge />
            <span className="card__viewers mono">
              <IconEye size={12} aria-hidden="true" />
              {formatCount(data.viewerCount)}
            </span>
          </>
        ) : (
          <span className="card__offline chip">Offline</span>
        )}
      </Thumb>
      <div className="card__body">
        <div className="card__avatar-row">
          <Avatar src={data.avatarUrl} name={data.channelName} size={size === "sm" ? 24 : 30} />
          <div className="card__meta">
            <p className="card__title clamp-2" title={data.title}>
              {data.title}
            </p>
            <p className="card__channel">
              <span className="truncate">{data.channelName}</span>
              {data.verified && <IconVerified size={12} className="verified-icon" />}
            </p>
          </div>
        </div>
        <p className="card__sub">
          {!data.isLive && data.statusLabel && <span>{data.statusLabel}</span>}
          {!data.isLive && data.statusLabel && data.categoryName && <span aria-hidden="true"> · </span>}
          {data.categoryName && <span>{data.categoryName}</span>}
          {data.categoryName && data.tags[0] && <span aria-hidden="true"> · </span>}
          {data.tags[0] && <span>{data.tags[0]}</span>}
        </p>
      </div>
    </a>
  );
});

/* -------------------------------------------------------------------------- */
/* category card                                                              */
/* -------------------------------------------------------------------------- */

export const CategoryCard = memo(function CategoryCard({ category }: { category: Category }) {
  return (
    <a className="cat-card" href={routes.browse(category.slug)}>
      <Thumb src={category.artUrl} alt="" className="cat-card__art" />
      <span className="cat-card__scrim" aria-hidden="true" />
      <span className="cat-card__body">
        <span className="cat-card__name">{category.name}</span>
        <span className="cat-card__count mono">{formatCount(category.viewers)} viewers</span>
      </span>
    </a>
  );
});

/* -------------------------------------------------------------------------- */
/* channel row (sidebar + following)                                          */
/* -------------------------------------------------------------------------- */

export const ChannelRow = memo(function ChannelRow({
  channel,
  live,
  viewers,
  categoryName,
  following,
  compact = false,
}: {
  channel: Pick<Channel, "slug" | "displayName" | "avatarUrl" | "verified" | "viewerIsFollowing">;
  live: boolean;
  viewers?: number;
  categoryName?: string | null;
  following?: boolean;
  compact?: boolean;
}) {
  return (
    <a className={cx("channel-row", compact && "channel-row--compact")} href={routes.channel(channel.slug)}>
      <span className="channel-row__avatar">
        <Avatar src={channel.avatarUrl} name={channel.displayName} size={compact ? 26 : 32} ring={live} />
        {live && <span className="channel-row__pulse" aria-hidden="true" />}
      </span>
      <span className="channel-row__body">
        <span className="channel-row__name truncate">
          {channel.displayName}
          {channel.verified && <IconVerified size={11} className="verified-icon" />}
        </span>
        <span className="channel-row__sub truncate">
          {live ? (categoryName ?? "Live now") : "Offline"}
        </span>
      </span>
      {live && typeof viewers === "number" ? (
        <span className="channel-row__count mono">
          <span className="live-dot" aria-hidden="true" />
          {formatCount(viewers)}
        </span>
      ) : following ? (
        <IconHeartFilled size={12} className="channel-row__follow" />
      ) : null}
    </a>
  );
});

/* -------------------------------------------------------------------------- */
/* clip / vod tile                                                            */
/* -------------------------------------------------------------------------- */

export function MediaTile({
  thumbnailUrl,
  title,
  meta,
  href,
  badge,
  duration,
}: {
  thumbnailUrl: string | null;
  title: string;
  meta: string;
  href: string;
  badge?: string;
  duration?: number;
}) {
  return (
    <a className="media-tile" href={href}>
      <Thumb src={thumbnailUrl} alt="" className="media-tile__thumb">
        {typeof duration === "number" && <span className="media-tile__duration mono">{formatDuration(duration)}</span>}
        {badge && <span className="media-tile__badge">{badge}</span>}
      </Thumb>
      <p className="media-tile__title clamp-2">{title}</p>
      <p className="media-tile__meta">{meta}</p>
    </a>
  );
}

export function ClipTile({ clip, href }: { clip: { title: string; thumbnailUrl: string | null; durationSeconds: number; viewCount: number; creatorDisplayName: string }; href: string }) {
  return (
    <a className="clip-tile" href={href}>
      <Thumb src={clip.thumbnailUrl} alt="" className="clip-tile__thumb">
        <span className="media-tile__duration mono">{formatDuration(clip.durationSeconds)}</span>
      </Thumb>
      <p className="clip-tile__title clamp-2">{clip.title}</p>
      <p className="clip-tile__meta">
        {formatCount(clip.viewCount)} views · by {clip.creatorDisplayName}
      </p>
    </a>
  );
}

export function VodTile({ vod, href }: { vod: { title: string; thumbnailUrl: string | null; durationSeconds: number; viewCount: number; publishedAt: string }; href: string }) {
  return (
    <a className="clip-tile" href={href}>
      <Thumb src={vod.thumbnailUrl} alt="" className="clip-tile__thumb">
        <span className="media-tile__duration mono">{formatDuration(vod.durationSeconds)}</span>
      </Thumb>
      <p className="clip-tile__title clamp-2">{vod.title}</p>
      <p className="clip-tile__meta">
        {formatCount(vod.viewCount)} views · {formatRelative(vod.publishedAt)}
      </p>
    </a>
  );
}
