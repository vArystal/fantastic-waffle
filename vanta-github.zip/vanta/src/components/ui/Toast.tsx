import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { cx, uid } from "../../lib/utils";
import { IconAlert, IconCheck, IconClose, IconWifiOff } from "../icons";

type Tone = "info" | "success" | "error";

interface Toast {
  id: string;
  title: string;
  description?: string;
  tone: Tone;
}

interface ToastApi {
  push: (t: Omit<Toast, "id">) => void;
  success: (title: string, description?: string) => void;
  error: (title: string, description?: string) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef(new Map<string, number>());

  const dismiss = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
    const timer = timers.current.get(id);
    if (timer) {
      window.clearTimeout(timer);
      timers.current.delete(id);
    }
  }, []);

  const push = useCallback(
    (toast: Omit<Toast, "id">) => {
      // de-duplicate identical adjacent toasts (double-click / double-submit)
      setToasts((prev) => {
        if (prev.some((t) => t.title === toast.title && t.description === toast.description)) {
          return prev;
        }
        return [...prev.slice(-2), { ...toast, id: uid("toast") }];
      });
      const id = uid("toast");
      // schedule using the same id we store
      setToasts((prev) => {
        const last = prev[prev.length - 1];
        if (last && last.id.startsWith("toast_") && !timers.current.has(last.id)) {
          const timer = window.setTimeout(() => dismiss(last.id), 4200);
          timers.current.set(last.id, timer);
        }
        return prev;
      });
      void id;
    },
    [dismiss],
  );

  const api = useMemo<ToastApi>(
    () => ({
      push,
      success: (title, description) => push({ title, description, tone: "success" }),
      error: (title, description) => push({ title, description, tone: "error" }),
    }),
    [push],
  );

  useEffect(() => {
    return () => {
      timers.current.forEach((t) => window.clearTimeout(t));
      timers.current.clear();
    };
  }, []);

  return (
    <ToastContext.Provider value={api}>
      {children}
      {createPortal(
        <div className="toast-viewport" role="region" aria-label="Notifications">
          {toasts.map((t) => (
            <div key={t.id} className={cx("toast", `toast--${t.tone}`)} role="status">
              <span className="toast__icon" aria-hidden="true">
                {t.tone === "success" ? <IconCheck size={16} /> : t.tone === "error" ? <IconAlert size={16} /> : <IconWifiOff size={16} />}
              </span>
              <div className="toast__body">
                <p className="toast__title">{t.title}</p>
                {t.description && <p className="toast__desc">{t.description}</p>}
              </div>
              <button className="icon-btn icon-btn--sm" onClick={() => dismiss(t.id)} aria-label="Dismiss notification">
                <IconClose size={14} />
              </button>
            </div>
          ))}
        </div>,
        document.body,
      )}
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside ToastProvider");
  return ctx;
}

/* -------------------------------------------------------------------------- */
/* dialog                                                                     */
/* -------------------------------------------------------------------------- */

export function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 480,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: ReactNode;
  footer?: ReactNode;
  width?: number;
}) {
  const titleId = useId();
  const descId = useId();
  const panelRef = useRef<HTMLDivElement>(null);
  const restoreTo = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    restoreTo.current = document.activeElement as HTMLElement | null;
    const panel = panelRef.current;
    const focusables = () =>
      Array.from(
        panel?.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])',
        ) ?? [],
      );
    focusables()[0]?.focus();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
        return;
      }
      if (e.key !== "Tab") return;
      const items = focusables();
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown, true);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown, true);
      document.body.style.overflow = prevOverflow;
      // the trigger may have been unmounted (e.g. a dialog opened from a menu),
      // so fall back to the element that owns this dialog's entry point.
      // The focus has to happen after React commits the close, otherwise the
      // unmount of the popover steals it back.
      const target = restoreTo.current;
      requestAnimationFrame(() => {
        if (target?.isConnected && target !== document.body) {
          target.focus?.();
          return;
        }
        const fallback = document.querySelector<HTMLElement>("[data-dialog-return]");
        if (fallback) fallback.focus();
        else document.getElementById("main-content")?.focus();
      });
    };
  }, [open, onClose]);

  if (!open) return null;

  return createPortal(
    <div className="dialog-scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        ref={panelRef}
        className="dialog"
        style={{ maxWidth: width }}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descId : undefined}
      >
        <div className="dialog__head">
          <div>
            <h2 id={titleId} className="dialog__title">
              {title}
            </h2>
            {description && (
              <p id={descId} className="dialog__desc">
                {description}
              </p>
            )}
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close dialog">
            <IconClose size={18} />
          </button>
        </div>
        {children && <div className="dialog__body">{children}</div>}
        {footer && <div className="dialog__footer">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}
