import { useState, type ReactNode } from "react";
import { ApiError, type ChatBadge } from "../../types";
import { cx, initials, percent } from "../../lib/utils";
import {
  IconAlert,
  IconLive,
  IconRefresh,
  IconShield,
  IconStar,
  IconVerified,
  IconWifiOff,
} from "../icons";

/* -------------------------------------------------------------------------- */
/* images                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Avatar with a deterministic initials fallback. Missing avatars are a real
 * state (deleted uploads, new accounts) so it must never render a broken image.
 */
export function Avatar({
  src,
  name,
  size = 32,
  className,
  ring,
}: {
  src: string | null;
  name: string;
  size?: number;
  className?: string;
  ring?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const showFallback = !src || failed;
  return (
    <span
      className={cx("avatar", ring && "avatar--ring", className)}
      style={{ width: size, height: size, fontSize: Math.max(10, size * 0.36) }}
      data-testid="avatar"
    >
      {showFallback ? (
        <span className="avatar__initials" aria-hidden="true">
          {initials(name) || "?"}
        </span>
      ) : (
        <img src={src} alt="" width={size} height={size} loading="lazy" decoding="async" onError={() => setFailed(true)} />
      )}
    </span>
  );
}

/** 16:9 artwork with a skeleton while loading and a graceful failure state. */
export function Thumb({
  src,
  alt,
  className,
  ratio = "16 / 9",
  priority = false,
  children,
}: {
  src: string | null;
  alt: string;
  className?: string;
  ratio?: string;
  priority?: boolean;
  children?: ReactNode;
}) {
  const [state, setState] = useState<"loading" | "ready" | "failed">(src ? "loading" : "failed");
  return (
    <span className={cx("thumb", className)} style={{ aspectRatio: ratio }} data-testid="thumb">
      {state === "loading" && <span className="skeleton thumb__skeleton" aria-hidden="true" />}
      {state !== "failed" && src && (
        <img
          src={src}
          alt={alt}
          className={cx("thumb__img", state === "ready" && "is-ready")}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          onLoad={() => setState("ready")}
          onError={() => setState("failed")}
        />
      )}
      {state === "failed" && (
        <span className="thumb__fallback" aria-hidden="true">
          <IconLive size={20} />
        </span>
      )}
      {children}
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/* status                                                                     */
/* -------------------------------------------------------------------------- */

export function LiveBadge({ label = "LIVE", subtle = false }: { label?: string; subtle?: boolean }) {
  return (
    <span className={cx("live-badge", subtle && "live-badge--subtle")}>
      <span className="live-dot" aria-hidden="true" />
      <span className="live-badge__text">{label}</span>
    </span>
  );
}

export function RoleBadges({ badges, size = 14 }: { badges: ChatBadge[]; size?: number }) {
  if (!badges.length) return null;
  return (
    <span className="role-badges">
      {badges.map((b) => {
        const map = {
          streamer: { icon: <IconLive size={size} />, title: "Broadcaster", cls: "role--streamer" },
          moderator: { icon: <IconShield size={size} />, title: "Moderator", cls: "role--moderator" },
          subscriber: { icon: <IconStar size={size} />, title: b.label ? `Subscriber · ${b.label}` : "Subscriber", cls: "role--subscriber" },
          verified: { icon: <IconVerified size={size} />, title: "Verified", cls: "role--verified" },
          founder: { icon: <IconStar size={size} />, title: "Founder", cls: "role--founder" },
        }[b.kind];
        if (!map) return null;
        return (
          <span key={b.kind} className={cx("role-badge", map.cls)} title={map.title} aria-label={map.title} role="img">
            {map.icon}
            {b.kind === "subscriber" && b.label && <span className="role-badge__label">{b.label}</span>}
          </span>
        );
      })}
    </span>
  );
}

export function Spinner({ size = 18, label = "Loading" }: { size?: number; label?: string }) {
  return (
    <span className="spinner" style={{ width: size, height: size }} role="status" aria-label={label}>
      <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.4" fill="none" opacity="0.22" />
        <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </svg>
    </span>
  );
}

export function ProgressBar({
  value,
  total,
  label,
  tone = "accent",
  height = 8,
}: {
  value: number;
  total: number;
  label: string;
  tone?: "accent" | "trust" | "live";
  height?: number;
}) {
  const pct = percent(value, total);
  return (
    <div
      className="progress"
      role="progressbar"
      aria-valuenow={Math.round(pct)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
      style={{ height }}
    >
      <div className={cx("progress__fill", `progress__fill--${tone}`)} style={{ width: `${pct}%` }} />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* empty / error / skeleton                                                   */
/* -------------------------------------------------------------------------- */

export function EmptyState({
  icon,
  title,
  description,
  action,
  compact = false,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div className={cx("empty", compact && "empty--compact")}>
      {icon && (
        <span className="empty__icon" aria-hidden="true">
          {icon}
        </span>
      )}
      <p className="empty__title">{title}</p>
      {description && <p className="empty__desc">{description}</p>}
      {action && <div className="empty__action">{action}</div>}
    </div>
  );
}

export function ErrorState({
  error,
  onRetry,
  compact = false,
}: {
  error: ApiError;
  onRetry?: () => void;
  compact?: boolean;
}) {
  const offline = error.code === "network";
  return (
    <EmptyState
      compact={compact}
      icon={offline ? <IconWifiOff size={22} /> : <IconAlert size={22} />}
      title={offline ? "You're offline" : "That didn't load"}
      description={error.message}
      action={
        onRetry ? (
          <button className="btn btn--ghost btn--sm" onClick={onRetry}>
            <IconRefresh size={14} /> Try again
          </button>
        ) : null
      }
    />
  );
}

export function SkeletonLine({ width = "100%", height = 12, radius = 6, style }: { width?: string | number; height?: number; radius?: number; style?: React.CSSProperties }) {
  return <span className="skeleton" style={{ display: "block", width, height, borderRadius: radius, ...style }} aria-hidden="true" />;
}

export function CardSkeleton() {
  return (
    <div className="card-skeleton" aria-hidden="true">
      <span className="skeleton card-skeleton__thumb" />
      <div className="card-skeleton__body">
        <SkeletonLine width="86%" />
        <SkeletonLine width="54%" height={10} />
      </div>
    </div>
  );
}

export function RailSkeleton({ count = 4, title }: { count?: number; title?: string }) {
  return (
    <section className="rail" aria-busy="true" aria-label={title ? `Loading ${title}` : "Loading"}>
      {title && (
        <div className="rail__head">
          <h2 className="rail__title">{title}</h2>
        </div>
      )}
      <div className="rail__track rail__track--skeleton">
        {Array.from({ length: count }, (_, i) => (
          <CardSkeleton key={i} />
        ))}
      </div>
    </section>
  );
}

export function SectionHeading({
  title,
  icon,
  action,
  id,
}: {
  title: string;
  icon?: ReactNode;
  action?: ReactNode;
  id?: string;
}) {
  return (
    <div className="section-head">
      <h2 className="section-head__title" id={id}>
        {icon && <span aria-hidden="true">{icon}</span>}
        {title}
      </h2>
      {action}
    </div>
  );
}
