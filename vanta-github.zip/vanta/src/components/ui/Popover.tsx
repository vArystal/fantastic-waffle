import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { cx } from "../../lib/utils";

/**
 * Popover: anchored, dismissible, keyboard-closing container.
 * Used for menus, share sheets, settings panels and notification lists.
 */
export function Popover({
  trigger,
  children,
  align = "end",
  side = "bottom",
  label,
  className,
  open: controlledOpen,
  onOpenChange,
  width,
}: {
  trigger: (props: { open: boolean; toggle: () => void; ref: React.Ref<HTMLButtonElement> }) => ReactNode;
  children: (close: () => void) => ReactNode;
  align?: "start" | "end" | "center";
  side?: "bottom" | "top";
  label: string;
  className?: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  width?: number;
}) {
  const [uncontrolled, setUncontrolled] = useState(false);
  const open = controlledOpen ?? uncontrolled;
  const setOpen = useCallback(
    (next: boolean) => {
      if (controlledOpen === undefined) setUncontrolled(next);
      onOpenChange?.(next);
    },
    [controlledOpen, onOpenChange],
  );

  const wrapRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const close = useCallback(
    (restoreFocus = false) => {
      setOpen(false);
      if (restoreFocus) triggerRef.current?.focus();
    },
    [setOpen],
  );

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (e: PointerEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) close();
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        close(true);
      }
      if (e.key === "Tab" && panelRef.current) {
        const items = Array.from(
          panelRef.current.querySelectorAll<HTMLElement>(
            'button:not([disabled]), [href], input:not([disabled]), [tabindex]:not([tabindex="-1"])',
          ),
        );
        if (items.length && !panelRef.current.contains(document.activeElement)) {
          items[0].focus();
        }
      }
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown, true);
    // move focus into the panel so keyboard users land in context
    const first = panelRef.current?.querySelector<HTMLElement>(
      'button:not([disabled]), [href], input:not([disabled]), [tabindex]:not([tabindex="-1"])',
    );
    if (first && panelRef.current && !panelRef.current.contains(document.activeElement)) {
      first.focus({ preventScroll: true });
    }
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown, true);
    };
  }, [open, close]);

  return (
    <div className="popover-wrap" ref={wrapRef}>
      {trigger({ open, toggle: () => setOpen(!open), ref: triggerRef })}
      {open && (
        <div
          ref={panelRef}
          className={cx("popover", `popover--${align}`, `popover--${side}`, className)}
          role="dialog"
          aria-label={label}
          style={width ? { width } : undefined}
        >
          {children(() => close(true))}
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* menu (keyboard-navigable list of actions)                                   */
/* -------------------------------------------------------------------------- */

export interface MenuItem {
  id: string;
  label: string;
  icon?: ReactNode;
  onSelect: () => void;
  danger?: boolean;
  disabled?: boolean;
  /** secondary description, announced to screen readers */
  hint?: string;
}

export function MenuList({ items, onDone }: { items: MenuItem[]; onDone: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(-1);
  const enabled = items.filter((i) => !i.disabled);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const dir = e.key === "ArrowDown" ? 1 : -1;
        const next = (index + dir + enabled.length) % enabled.length;
        setIndex(next);
        const el = ref.current?.querySelectorAll<HTMLElement>('[role="menuitem"]:not([disabled])')[next];
        el?.focus();
      }
      if (e.key === "Home") {
        e.preventDefault();
        setIndex(0);
        ref.current?.querySelector<HTMLElement>('[role="menuitem"]:not([disabled])')?.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [index, enabled.length]);

  return (
    <div className="menu" role="menu" ref={ref}>
      {items.map((item) => (
        <button
          key={item.id}
          role="menuitem"
          className={cx("menu__item", item.danger && "menu__item--danger")}
          disabled={item.disabled}
          aria-label={item.hint ? `${item.label} — ${item.hint}` : item.label}
          onClick={() => {
            item.onSelect();
            onDone();
          }}
        >
          {item.icon && <span className="menu__icon">{item.icon}</span>}
          <span className="menu__label">{item.label}</span>
          {item.hint && <span className="menu__hint">{item.hint}</span>}
        </button>
      ))}
    </div>
  );
}
