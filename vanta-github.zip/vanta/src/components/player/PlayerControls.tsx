import { useCallback, useRef, useState } from "react";
import { Popover } from "../ui/Popover";
import {
  IconCaptions,
  IconCheck,
  IconExitFullscreen,
  IconFullscreen,
  IconMuted,
  IconPause,
  IconPip,
  IconPlay,
  IconSettings,
  IconTheater,
  IconVolumeFilled,
  IconVolumeLow,
} from "../icons";
import { cx, formatDuration } from "../../lib/utils";
import { usePlayer, usePlayerActions, usePlayerTime } from "./PlayerContext";

/* -------------------------------------------------------------------------- */
/* timeline                                                                   */
/* -------------------------------------------------------------------------- */

function Timeline() {
  const { stream, phase } = usePlayer();
  const { currentTime, duration, buffered, liveEdge, behindLive } = usePlayerTime();
  const { seek, goLive } = usePlayerActions();
  const trackRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const [preview, setPreview] = useState<number | null>(null);

  const isLive = stream.state === "live";
  const pct = duration > 0 ? (currentTime / duration) * 100 : 0;
  const bufferedPct = duration > 0 ? (buffered / duration) * 100 : 0;

  const timeFromEvent = useCallback(
    (clientX: number) => {
      const el = trackRef.current;
      if (!el) return 0;
      const rect = el.getBoundingClientRect();
      const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
      return ratio * duration;
    },
    [duration],
  );

  const onPointerDown = (e: React.PointerEvent) => {
    if (duration <= 0) return;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    setDragging(true);
    const t = timeFromEvent(e.clientX);
    setPreview(t);
    seek(t);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (duration <= 0) return;
    const t = timeFromEvent(e.clientX);
    setPreview(t);
    if (dragging) seek(t);
  };

  const stopDrag = () => {
    setDragging(false);
    setPreview(null);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    const step = e.shiftKey ? 30 : 5;
    if (e.key === "ArrowRight") {
      e.preventDefault();
      seek(currentTime + step);
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      seek(currentTime - step);
    } else if (e.key === "Home") {
      e.preventDefault();
      seek(0);
    } else if (e.key === "End") {
      e.preventDefault();
      seek(duration);
    }
  };

  const disabled = duration <= 0 || phase === "error";

  return (
    <div className="timeline-wrap">
      <div
        ref={trackRef}
        className={cx("timeline", disabled && "timeline--disabled", dragging && "is-dragging")}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={stopDrag}
        onPointerCancel={stopDrag}
        onPointerLeave={() => !dragging && setPreview(null)}
        role="slider"
        aria-label={isLive ? "Seek within the DVR window" : "Seek"}
        aria-valuemin={0}
        aria-valuemax={Math.round(duration)}
        aria-valuenow={Math.round(currentTime)}
        aria-valuetext={`${formatDuration(currentTime)} of ${formatDuration(duration)}`}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        onKeyDown={onKeyDown}
      >
        <div className="timeline__buffer" style={{ width: `${bufferedPct}%` }} />
        <div className="timeline__played" style={{ width: `${pct}%` }}>
          <span className="timeline__thumb" />
        </div>
        {preview !== null && (
          <span className="timeline__preview" style={{ left: `${(preview / (duration || 1)) * 100}%` }}>
            {formatDuration(preview)}
          </span>
        )}
      </div>
      {isLive && !liveEdge && (
        <button className="live-edge-btn" onClick={goLive} aria-label={`Return to live, ${Math.round(behindLive)} seconds behind`}>
          <span className="live-dot" aria-hidden="true" />
          Go live
        </button>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* volume                                                                     */
/* -------------------------------------------------------------------------- */

function VolumeControl() {
  const { muted, volume } = usePlayer();
  const { toggleMute, setVolume } = usePlayerActions();
  const [open, setOpen] = useState(false);
  const level = muted ? 0 : volume;
  const Icon = level === 0 ? IconMuted : level < 0.5 ? IconVolumeLow : IconVolumeFilled;

  return (
    <div
      className="volume"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        className="player-btn"
        onClick={toggleMute}
        aria-label={level === 0 ? "Unmute" : "Mute"}
        aria-pressed={level === 0}
      >
        <Icon size={20} />
      </button>
      <div className={cx("volume__slider", open && "is-open")}>
        <input
          type="range"
          min={0}
          max={1}
          step={0.02}
          value={level}
          onChange={(e) => setVolume(Number(e.target.value))}
          aria-label="Volume"
          className="range"
          style={{ ["--fill" as string]: `${level * 100}%` }}
        />
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* quality + settings                                                         */
/* -------------------------------------------------------------------------- */

function QualityMenu({ close }: { close: () => void }) {
  const { stream, qualityId, effectiveQualityId } = usePlayer();
  const { setQuality } = usePlayerActions();
  const renditions = stream.playback?.renditions ?? [];

  if (!renditions.length) {
    return (
      <div className="menu">
        <p className="menu__note">No playback renditions are published for this stream.</p>
        <button className="menu__item" onClick={close}>Close</button>
      </div>
    );
  }

  return (
    <div className="menu" role="menu" aria-label="Playback quality">
      <div className="menu__head">
        <span className="eyebrow">Quality</span>
        {stream.playback?.kind === "hls" ? (
          <span className="menu__badge">Adaptive</span>
        ) : (
          <span className="menu__badge">Manual</span>
        )}
      </div>
      <p className="menu__note">
        {stream.playback?.kind === "hls"
          ? "Adaptive bitrate is handled by the manifest; these are the published renditions."
          : "Switching quality reloads the source at the same position."}
      </p>
      {renditions.map((r) => {
        const active = r.id === qualityId;
        return (
          <button
            key={r.id}
            role="menuitemradio"
            aria-checked={active}
            className={cx("menu__item", active && "is-active")}
            onClick={() => {
              setQuality(r.id);
              close();
            }}
          >
            <span className="menu__label">
              {r.label}
              {r.id === effectiveQualityId && <span className="menu__hint">loaded</span>}
            </span>
            <span className="menu__meta mono">{r.bitrateKbps} kbps</span>
            {active && <IconCheck size={15} />}
          </button>
        );
      })}
    </div>
  );
}

function SettingsMenu({ close }: { close: () => void }) {
  const { captionsAvailable, captionsEnabled, stream, qualityId } = usePlayer();
  const { toggleCaptions } = usePlayerActions();
  const active = stream.playback?.renditions.find((r) => r.id === qualityId);

  return (
    <div className="menu" role="menu" aria-label="Player settings">
      <div className="menu__head">
        <span className="eyebrow">Player</span>
        <span className="menu__badge">{active?.label ?? "—"}</span>
      </div>
      <button
        role="menuitemcheckbox"
        aria-checked={captionsEnabled}
        className="menu__item"
        disabled={!captionsAvailable}
        onClick={() => {
          toggleCaptions();
          close();
        }}
      >
        <IconCaptions size={16} />
        <span className="menu__label">Captions</span>
        <span className="menu__meta">
          {captionsAvailable ? (captionsEnabled ? "On" : "Off") : "Not available"}
        </span>
      </button>
      <div className="menu__divider" role="separator" />
      <div className="menu__note menu__note--tight">
        {stream.playback?.lowLatency
          ? "Low-latency playback is enabled for this stream."
          : "Standard latency. Low-latency mode requires the LL-HLS transport."}
      </div>
      <div className="menu__note menu__note--tight">
        DVR window: {stream.playback?.dvr.enabled ? formatDuration(stream.playback.dvr.windowSeconds) : "disabled"}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* control bar                                                                */
/* -------------------------------------------------------------------------- */

export function PlayerControls({ onOpenShortcuts }: { onOpenShortcuts: () => void }) {
  const { stream, playing, phase, captionsAvailable, captionsEnabled, fullscreen, pip, qualityId } = usePlayer();
  const { togglePlay, toggleFullscreen, toggleTheater, togglePip, toggleCaptions } = usePlayerActions();
  const { currentTime, duration } = usePlayerTime();
  const live = stream.state === "live";

  return (
    <div className="controls" onClick={(e) => e.stopPropagation()}>
      <Timeline />
      <div className="controls__row">
        <div className="controls__group">
          <button
            className="player-btn"
            onClick={togglePlay}
            aria-label={playing ? "Pause" : "Play"}
            aria-pressed={playing}
          >
            {playing ? <IconPause size={20} /> : <IconPlay size={20} />}
          </button>
          <VolumeControl />
          <div className="time-readout mono" aria-hidden="true">
            {formatDuration(currentTime)}
            <span className="time-readout__sep">/</span>
            {duration > 0 ? formatDuration(duration) : "—"}
          </div>
          {live ? (
            <span className="controls__live" aria-label="Stream is live">
              <span className="live-dot" aria-hidden="true" />
              LIVE
            </span>
          ) : (
            <span className="controls__vod">{stream.state === "ended" ? "REPLAY" : "PREVIEW"}</span>
          )}
        </div>

        <div className="controls__group controls__group--end">
          <button
            className={cx("player-btn player-btn--optional", captionsEnabled && "is-active")}
            onClick={toggleCaptions}
            aria-label={captionsAvailable ? `Captions ${captionsEnabled ? "on" : "off"}` : "Captions unavailable"}
            aria-pressed={captionsEnabled}
            disabled={!captionsAvailable}
          >
            <IconCaptions size={19} />
          </button>

          <button
            className="player-btn player-btn--optional"
            onClick={() => void togglePip()}
            aria-label="Picture in picture"
            aria-pressed={pip}
          >
            <IconPip size={19} />
          </button>

          <button
            className="player-btn player-btn--optional"
            onClick={() => onOpenShortcuts()}
            aria-label="Keyboard shortcuts"
            title="Keyboard shortcuts (?)"
          >
            <span className="kbd-hint">?</span>
          </button>

          <Popover
            label="Quality"
            align="end"
            side="top"
            trigger={({ toggle }) => (
              <button
                className="player-btn player-btn--wide"
                onClick={toggle}
                aria-label={`Quality: ${stream.playback?.renditions.find((r) => r.id === qualityId)?.label ?? "Auto"}`}
              >
                <span className="quality-label" aria-hidden="true">
                  {stream.playback?.renditions.find((r) => r.id === qualityId)?.label ?? "Auto"}
                </span>
                <IconSettings size={17} aria-hidden="true" />
              </button>
            )}
          >
            {(close) => <QualityMenu close={close} />}
          </Popover>

          <Popover
            label="Settings"
            align="end"
            side="top"
            trigger={({ toggle }) => (
              <button className="player-btn" onClick={toggle} aria-label="Player settings and captions">
                <IconSettings size={19} />
              </button>
            )}
          >
            {(close) => <SettingsMenu close={close} />}
          </Popover>

          <button
            className="player-btn player-btn--optional"
            onClick={toggleTheater}
            aria-label="Theater mode"
            title="Theater mode (t)"
          >
            <IconTheater size={19} />
          </button>

          <button
            className="player-btn"
            onClick={toggleFullscreen}
            aria-label={fullscreen ? "Exit fullscreen" : "Fullscreen"}
            title="Fullscreen (f)"
          >
            {fullscreen ? <IconExitFullscreen size={19} /> : <IconFullscreen size={19} />}
          </button>
        </div>
      </div>
      <span className="sr-only" aria-live="polite">
        {phase === "buffering" ? "Buffering" : ""}
      </span>
    </div>
  );
}
