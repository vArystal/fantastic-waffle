import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Stream } from "../../types";
import { clamp } from "../../lib/utils";
import { playerBridge } from "../../state/playerBridge";

/**
 * Player state, isolated from the rest of the page.
 *
 * Two contexts on purpose:
 *  - `usePlayer()`        discrete state (playing, muted, quality, modes) — low frequency
 *  - `usePlayerTime()`    playback clock (time, duration, buffered) — high frequency
 *
 * The split keeps 4 Hz clock updates from re-rendering the whole page.
 */

export type PlaybackPhase =
  | "idle" // no source / stream not playable
  | "connecting" // source attached, waiting for first frame
  | "playing"
  | "paused"
  | "buffering"
  | "interrupted" // network stall we are recovering from
  | "error"
  | "ended";

export interface PlayerError {
  title: string;
  message: string;
  /** can the user retry, or is this terminal? */
  retryable: boolean;
  code?: number;
}

interface PlayerState {
  stream: Stream;
  phase: PlaybackPhase;
  playing: boolean;
  muted: boolean;
  volume: number;
  qualityId: string;
  effectiveQualityId: string;
  captionsEnabled: boolean;
  captionsAvailable: boolean;
  theater: boolean;
  fullscreen: boolean;
  pip: boolean;
  error: PlayerError | null;
  retryCount: number;
  /** user has interacted at least once (unlocks audio) */
  interacted: boolean;
}

interface PlayerTime {
  currentTime: number;
  duration: number;
  buffered: number;
  liveEdge: boolean;
  /** seconds behind the live edge */
  behindLive: number;
}

interface PlayerActions {
  attachVideo: (el: HTMLVideoElement | null) => void;
  play: () => Promise<void>;
  pause: () => void;
  togglePlay: () => void;
  seek: (time: number) => void;
  seekBy: (delta: number) => void;
  goLive: () => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  setQuality: (id: string) => void;
  toggleCaptions: () => void;
  toggleTheater: () => void;
  toggleFullscreen: () => void;
  togglePip: () => Promise<void>;
  retry: () => void;
  /** used by the demo panel to exercise the reconnect path */
  simulateInterruption: () => void;
  containerRef: React.RefObject<HTMLDivElement | null>;
  videoEl: () => HTMLVideoElement | null;
}

const StateCtx = createContext<PlayerState | null>(null);
const TimeCtx = createContext<PlayerTime | null>(null);
const ActionsCtx = createContext<PlayerActions | null>(null);

const MAX_AUTO_RETRIES = 3;

const initialState = (stream: Stream): PlayerState => ({
  stream,
  phase: stream.state === "live" ? "connecting" : stream.state === "ended" ? "idle" : "idle",
  playing: false,
  muted: true, // never autoplay audio
  volume: 0.6,
  qualityId: stream.playback?.renditions[0]?.id ?? "auto",
  effectiveQualityId: stream.playback?.renditions[0]?.id ?? "auto",
  captionsEnabled: false,
  captionsAvailable: (stream.playback?.captions.length ?? 0) > 0,
  theater: false,
  fullscreen: false,
  pip: false,
  error: null,
  retryCount: 0,
  interacted: false,
});

export function PlayerProvider({ stream, children }: { stream: Stream; children: ReactNode }) {
  const [state, setState] = useState<PlayerState>(() => initialState(stream));
  const [time, setTime] = useState<PlayerTime>({
    currentTime: 0,
    duration: 0,
    buffered: 0,
    liveEdge: true,
    behindLive: 0,
  });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const pendingSeek = useRef<number | null>(null);
  const stallTimer = useRef<number | null>(null);
  const retryTimer = useRef<number | null>(null);
  const playIntent = useRef(false);
  /** timestamp of the most recent loop wrap, used to keep "at live edge" honest
   *  for looping sources (the demo clip loops to imitate a continuous feed) */
  const lastWrapAt = useRef(0);
  const prevTime = useRef(0);

  /* stream identity change resets everything (navigating between channels) */
  useEffect(() => {
    setState(initialState(stream));
    setTime({ currentTime: 0, duration: 0, buffered: 0, liveEdge: true, behindLive: 0 });
  }, [stream.id, stream.state, stream.playback]);

  const patch = useCallback((next: Partial<PlayerState>) => {
    setState((prev) => ({ ...prev, ...next }));
  }, []);

  /* ---------------------------------------------------------------------- */
  /* actions                                                                */
  /* ---------------------------------------------------------------------- */

  const attachVideo = useCallback((el: HTMLVideoElement | null) => {
    videoRef.current = el;
    if (el && pendingSeek.current !== null) {
      const target = pendingSeek.current;
      pendingSeek.current = null;
      const apply = () => {
        try {
          el.currentTime = Math.min(target, el.duration || target);
        } catch {
          /* seeking before metadata is a no-op, not an error */
        }
        if (playIntent.current) void el.play().catch(() => undefined);
      };
      if (el.readyState >= 1) apply();
      else el.addEventListener("loadedmetadata", apply, { once: true });
    }
  }, []);

  const play = useCallback(async () => {
    const el = videoRef.current;
    if (!el) return;
    playIntent.current = true;
    try {
      await el.play();
    } catch (err) {
      // autoplay rejection is expected until the user interacts; surface it
      // honestly instead of silently failing
      const name = err instanceof DOMException ? err.name : "";
      if (name === "NotAllowedError") {
        patch({ phase: "paused" });
        return;
      }
      patch({
        phase: "error",
        error: {
          title: "Playback could not start",
          message: "The browser blocked playback. Press play to try again.",
          retryable: true,
        },
      });
    }
  }, [patch]);

  const pause = useCallback(() => {
    playIntent.current = false;
    videoRef.current?.pause();
  }, []);

  const togglePlay = useCallback(() => {
    const el = videoRef.current;
    if (!el) return;
    patch({ interacted: true });
    if (el.muted && state.muted) {
      // first explicit play keeps audio off, matching "no unexpected audio"
    }
    if (el.paused) void play();
    else pause();
  }, [patch, pause, play, state.muted]);

  const seek = useCallback((t: number) => {
    const el = videoRef.current;
    if (!el || !Number.isFinite(el.duration)) return;
    el.currentTime = clamp(t, 0, el.duration);
    setTime((prev) => ({ ...prev, currentTime: el.currentTime }));
  }, []);

  const seekBy = useCallback(
    (delta: number) => {
      const el = videoRef.current;
      if (!el) return;
      seek(el.currentTime + delta);
    },
    [seek],
  );

  const goLive = useCallback(() => {
    const el = videoRef.current;
    if (!el || !Number.isFinite(el.duration)) return;
    // NOTE: with a real HLS live window this is seekable.end(seekable.length-1);
    // the progressive demo source reports its length as duration.
    el.currentTime = Math.max(0, el.duration - 1.2);
    void play();
  }, [play]);

  const setVolume = useCallback(
    (v: number) => {
      const el = videoRef.current;
      const next = clamp(v, 0, 1);
      if (el) {
        el.volume = next;
        el.muted = next === 0;
      }
      patch({ volume: next, muted: next === 0, interacted: true });
    },
    [patch],
  );

  const toggleMute = useCallback(() => {
    const el = videoRef.current;
    if (!el) return;
    const next = !el.muted;
    el.muted = next;
    if (!next && el.volume === 0) el.volume = 0.6;
    patch({ muted: next, volume: el.volume, interacted: true });
  }, [patch]);

  const setQuality = useCallback(
    (id: string) => {
      const el = videoRef.current;
      if (el && Number.isFinite(el.duration)) {
        // remember where the viewer is so the source swap is seamless
        pendingSeek.current = el.currentTime;
        playIntent.current = !el.paused;
      }
      patch({ qualityId: id, phase: "buffering" });
    },
    [patch],
  );

  const toggleCaptions = useCallback(() => {
    const el = videoRef.current;
    const next = !state.captionsEnabled;
    if (el) {
      for (const track of Array.from(el.textTracks)) {
        track.mode = next && track.language ? "showing" : "disabled";
      }
    }
    patch({ captionsEnabled: next });
  }, [patch, state.captionsEnabled]);

  const toggleTheater = useCallback(() => {
    setState((prev) => ({ ...prev, theater: !prev.theater }));
  }, []);

  const toggleFullscreen = useCallback(() => {
    const node = containerRef.current;
    if (!node) return;
    if (document.fullscreenElement) {
      void document.exitFullscreen?.();
    } else {
      void node.requestFullscreen?.().catch(() => {
        patch({
          error: {
            title: "Fullscreen unavailable",
            message: "Your browser refused the fullscreen request.",
            retryable: false,
          },
        });
      });
    }
  }, [patch]);

  const togglePip = useCallback(async () => {
    const el = videoRef.current;
    if (!el) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await el.requestPictureInPicture();
      } else {
        patch({
          error: {
            title: "Picture-in-picture unavailable",
            message: "This browser does not support picture-in-picture.",
            retryable: false,
          },
        });
      }
    } catch {
      patch({
        error: {
          title: "Picture-in-picture failed",
          message: "The browser blocked the request. Check the page permissions.",
          retryable: false,
        },
      });
    }
  }, [patch]);

  const retry = useCallback(() => {
    const el = videoRef.current;
    patch({
      error: null,
      phase: "connecting",
      retryCount: 0,
    });
    if (!el) return;
    el.load();
    pendingSeek.current = null;
    if (playIntent.current) void el.play().catch(() => undefined);
  }, [patch]);

  /* ---------------------------------------------------------------------- */
  /* auto-reconnect                                                         */
  /* ---------------------------------------------------------------------- */

  const scheduleReconnect = useCallback(
    (reason: string) => {
      if (retryTimer.current) window.clearTimeout(retryTimer.current);
      setState((prev) => {
        if (prev.retryCount >= MAX_AUTO_RETRIES) {
          return {
            ...prev,
            phase: "error",
            error: {
              title: "Connection lost",
              message: `${reason} We stopped trying after ${MAX_AUTO_RETRIES} attempts.`,
              retryable: true,
            },
          };
        }
        return { ...prev, phase: "interrupted", retryCount: prev.retryCount + 1 };
      });
      const attempt = state.retryCount;
      const backoff = Math.min(1_200 * 2 ** attempt, 8_000);
      retryTimer.current = window.setTimeout(() => {
        const el = videoRef.current;
        if (!el) return;
        el.load();
        if (playIntent.current) void el.play().catch(() => undefined);
      }, backoff);
    },
    [state.retryCount],
  );

  const simulateInterruption = useCallback(() => {
    const el = videoRef.current;
    if (!el) return;
    el.pause();
    scheduleReconnect("The stream connection was interrupted.");
  }, [scheduleReconnect]);

  /* ---------------------------------------------------------------------- */
  /* media element events                                                   */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;

    const onLoadedMetadata = () => {
      const d = Number.isFinite(el.duration) ? el.duration : 0;
      setTime((prev) => ({ ...prev, duration: d }));
      if (pendingSeek.current !== null) {
        const target = pendingSeek.current;
        pendingSeek.current = null;
        el.currentTime = clamp(target, 0, d || target);
      }
      // a rendition swap keeps the viewer where they were
      if (playIntent.current && el.paused) void el.play().catch(() => undefined);
      setState((prev) => ({
        ...prev,
        effectiveQualityId: state.qualityId,
        phase: prev.phase === "interrupted" ? prev.phase : el.paused ? "paused" : "connecting",
        error: null,
        retryCount: 0,
      }));
    };

    const onCanPlay = () => {
      setState((prev) =>
        prev.phase === "connecting" || prev.phase === "buffering" || prev.phase === "interrupted"
          ? { ...prev, phase: el.paused ? "paused" : "playing", error: null, retryCount: 0 }
          : prev,
      );
    };

    const onPlay = () => {
      setState((prev) => ({ ...prev, playing: true, phase: "playing", error: null }));
    };
    const onPause = () => {
      setState((prev) => ({ ...prev, playing: false, phase: prev.phase === "error" ? "error" : "paused" }));
    };
    const onWaiting = () => {
      if (stallTimer.current) window.clearTimeout(stallTimer.current);
      stallTimer.current = window.setTimeout(() => {
        setState((prev) => (prev.phase === "error" ? prev : { ...prev, phase: "buffering" }));
      }, 350);
    };
    const onPlaying = () => {
      if (stallTimer.current) window.clearTimeout(stallTimer.current);
      setState((prev) => ({ ...prev, playing: true, phase: "playing", retryCount: 0, error: null }));
    };
    const onTimeUpdate = () => {
      const d = Number.isFinite(el.duration) ? el.duration : 0;
      const buffered = el.buffered.length ? el.buffered.end(el.buffered.length - 1) : 0;
      // a loop wrap means the playhead jumped backwards
      if (el.loop && prevTime.current - el.currentTime > 1) lastWrapAt.current = Date.now();
      prevTime.current = el.currentTime;
      const justWrapped = Date.now() - lastWrapAt.current < 1500;
      const behind = Math.max(0, d - el.currentTime);
      setTime({
        currentTime: el.currentTime,
        duration: d,
        buffered,
        // with a looping source the newest frames are reached again right after
        // the wrap, so the viewer is at the edge even though the clock restarted
        behindLive: justWrapped ? 0 : behind,
        liveEdge: justWrapped || behind < 2,
      });
    };
    const onEnded = () => {
      setState((prev) => ({
        ...prev,
        playing: false,
        phase: prev.stream.state === "live" ? "paused" : "ended",
      }));
    };
    const onVolumeChange = () => {
      setState((prev) => ({ ...prev, muted: el.muted, volume: el.volume }));
    };
    const onError = () => {
      const code = el.error?.code ?? 0;
      const map: Record<number, { title: string; message: string; retryable: boolean }> = {
        1: { title: "Playback aborted", message: "The stream was interrupted before it could start.", retryable: true },
        2: { title: "Network error", message: "The stream stopped downloading. Check your connection.", retryable: true },
        3: { title: "Decode error", message: "This stream could not be decoded by your browser.", retryable: true },
        4: { title: "Source unsupported", message: "This playback source is not available in your browser.", retryable: false },
      };
      const detail = map[code] ?? {
        title: "Playback failed",
        message: "The player ran into an unexpected problem.",
        retryable: true,
      };
      if (detail.retryable && state.retryCount < MAX_AUTO_RETRIES) {
        scheduleReconnect(detail.message);
      } else {
        setState((prev) => ({ ...prev, phase: "error", error: { ...detail, code } }));
      }
    };

    el.addEventListener("loadedmetadata", onLoadedMetadata);
    el.addEventListener("canplay", onCanPlay);
    el.addEventListener("play", onPlay);
    el.addEventListener("pause", onPause);
    el.addEventListener("waiting", onWaiting);
    el.addEventListener("stalled", onWaiting);
    el.addEventListener("playing", onPlaying);
    el.addEventListener("timeupdate", onTimeUpdate);
    el.addEventListener("ended", onEnded);
    el.addEventListener("volumechange", onVolumeChange);
    el.addEventListener("error", onError);

    // seed initial values for an element that is already loaded
    onVolumeChange();
    if (el.readyState >= 1) onLoadedMetadata();
    if (el.readyState >= 3) onCanPlay();

    return () => {
      el.removeEventListener("loadedmetadata", onLoadedMetadata);
      el.removeEventListener("canplay", onCanPlay);
      el.removeEventListener("play", onPlay);
      el.removeEventListener("pause", onPause);
      el.removeEventListener("waiting", onWaiting);
      el.removeEventListener("stalled", onWaiting);
      el.removeEventListener("playing", onPlaying);
      el.removeEventListener("timeupdate", onTimeUpdate);
      el.removeEventListener("ended", onEnded);
      el.removeEventListener("volumechange", onVolumeChange);
      el.removeEventListener("error", onError);
      if (stallTimer.current) window.clearTimeout(stallTimer.current);
      if (retryTimer.current) window.clearTimeout(retryTimer.current);
    };
    // `state.qualityId` re-binds listeners to the freshly mounted element after
    // a source swap; `state.retryCount` keeps the error branch accurate
  }, [state.qualityId, state.retryCount, scheduleReconnect]);

  /* expose the interruption hook to the demo panel (no context coupling) */
  useEffect(() => {
    playerBridge.interrupt = simulateInterruption;
    playerBridge.isPlayable = () => Boolean(videoRef.current) && Boolean(stream.playback);
    return () => {
      playerBridge.interrupt = null;
      playerBridge.isPlayable = () => false;
    };
  }, [simulateInterruption, stream.playback]);

  /* fullscreen + pip observers */
  useEffect(() => {
    const onFsChange = () => setState((prev) => ({ ...prev, fullscreen: !!document.fullscreenElement }));
    const onPipChange = () => setState((prev) => ({ ...prev, pip: !!document.pictureInPictureElement }));
    document.addEventListener("fullscreenchange", onFsChange);
    document.addEventListener("enterpictureinpicture", onPipChange);
    document.addEventListener("leavepictureinpicture", onPipChange);
    return () => {
      document.removeEventListener("fullscreenchange", onFsChange);
      document.removeEventListener("enterpictureinpicture", onPipChange);
      document.removeEventListener("leavepictureinpicture", onPipChange);
    };
  }, []);

  /* apply volume/mute to the element whenever they change in state */
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    el.volume = state.volume;
    el.muted = state.muted;
  }, [state.volume, state.muted]);

  /* caption mode follow-through */
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    for (const track of Array.from(el.textTracks)) {
      track.mode = state.captionsEnabled ? "showing" : "disabled";
    }
  }, [state.captionsEnabled, state.qualityId]);

  const actions = useMemo<PlayerActions>(
    () => ({
      attachVideo,
      play,
      pause,
      togglePlay,
      seek,
      seekBy,
      goLive,
      setVolume,
      toggleMute,
      setQuality,
      toggleCaptions,
      toggleTheater,
      toggleFullscreen,
      togglePip,
      retry,
      simulateInterruption,
      containerRef,
      videoEl: () => videoRef.current,
    }),
    [
      attachVideo, play, pause, togglePlay, seek, seekBy, goLive, setVolume, toggleMute,
      setQuality, toggleCaptions, toggleTheater, toggleFullscreen, togglePip, retry, simulateInterruption,
    ],
  );

  return (
    <StateCtx.Provider value={state}>
      <TimeCtx.Provider value={time}>
        <ActionsCtx.Provider value={actions}>{children}</ActionsCtx.Provider>
      </TimeCtx.Provider>
    </StateCtx.Provider>
  );
}

export function usePlayer(): PlayerState {
  const ctx = useContext(StateCtx);
  if (!ctx) throw new Error("usePlayer must be used inside PlayerProvider");
  return ctx;
}
export function usePlayerTime(): PlayerTime {
  const ctx = useContext(TimeCtx);
  if (!ctx) throw new Error("usePlayerTime must be used inside PlayerProvider");
  return ctx;
}
export function usePlayerActions(): PlayerActions {
  const ctx = useContext(ActionsCtx);
  if (!ctx) throw new Error("usePlayerActions must be used inside PlayerProvider");
  return ctx;
}
