import { useCallback, useEffect, useRef, useState } from "react";
import type { Stream } from "../../types";
import { cx, formatUptime, useNow } from "../../lib/utils";
import {
  IconAlert,
  IconCalendar,
  IconEye,
  IconPlay,
  IconRefresh,
  IconVolumeFilled,
  IconWifiOff,
} from "../icons";
import { Spinner } from "../ui/primitives";
import { PlayerControls } from "./PlayerControls";
import { usePlayer, usePlayerActions } from "./PlayerContext";

/* -------------------------------------------------------------------------- */
/* non-playable states                                                        */
/* -------------------------------------------------------------------------- */

function StateScreen({ stream }: { stream: Stream }) {
  const { retry } = usePlayerActions();
  const now = useNow(1000, stream.state === "scheduled");

  const content = (() => {
    switch (stream.state) {
      case "scheduled": {
        const when = stream.scheduledFor ? new Date(stream.scheduledFor) : null;
        return {
          icon: <IconCalendar size={26} />,
          title: "Scheduled — not live yet",
          body: when
            ? `Starts ${when.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}
               at ${when.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}.`
            : "The broadcaster has not announced a start time.",
          meta: when ? `In ${Math.max(0, Math.round((when.getTime() - now) / 60000))} minutes` : null,
        };
      }
      case "offline":
        return {
          icon: <IconWifiOff size={26} />,
          title: "Channel is offline",
          body: stream.stateReason ?? "This channel is not broadcasting right now.",
          meta: null,
        };
      case "restricted":
        return {
          icon: <IconAlert size={26} />,
          title: "Restricted stream",
          body: stream.stateReason ?? "You do not have permission to view this stream.",
          meta: null,
        };
      case "unavailable":
        return {
          icon: <IconAlert size={26} />,
          title: "Stream unavailable",
          body: stream.stateReason ?? "This stream cannot be played right now.",
          meta: null,
        };
      default:
        return {
          icon: <IconAlert size={26} />,
          title: "No playback source",
          body: "The broadcaster is live but no playable source is published yet.",
          meta: null,
        };
    }
  })();

  return (
    <div className="player__screen" role="status">
      <span className="player__screen-icon" aria-hidden="true">
        {content.icon}
      </span>
      <h2 className="player__screen-title">{content.title}</h2>
      <p className="player__screen-body">{content.body}</p>
      {content.meta && <p className="player__screen-meta mono">{content.meta}</p>}
      <div className="player__screen-actions">
        {stream.state === "offline" || stream.state === "unavailable" ? (
          <button className="btn btn--ghost btn--sm" onClick={retry}>
            <IconRefresh size={14} /> Check again
          </button>
        ) : null}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* player                                                                     */
/* -------------------------------------------------------------------------- */

export function VideoPlayer({ stream, onOpenShortcuts }: { stream: Stream; onOpenShortcuts: () => void }) {
  const player = usePlayer();
  const { attachVideo, togglePlay, retry, toggleMute, toggleTheater, toggleFullscreen, toggleCaptions, containerRef } =
    usePlayerActions();
  const [uiVisible, setUiVisible] = useState(true);
  const hideTimer = useRef<number | null>(null);
  const now = useNow(1000, stream.state === "live");

  const playback = stream.playback;
  const rendition = playback?.renditions.find((r) => r.id === player.qualityId) ?? playback?.renditions[0] ?? null;
  const playable = Boolean(playback) && (stream.state === "live" || stream.state === "ended");

  /* --- controls auto-hide ------------------------------------------------ */
  const showUi = useCallback(() => {
    setUiVisible(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      // never hide while paused, focused inside the player or erroring
      const el = containerRef.current;
      if (!el) return;
      if (el.contains(document.activeElement) && document.activeElement !== el) return;
      if (!player.playing) return;
      setUiVisible(false);
    }, 2600);
  }, [player.playing]);

  useEffect(() => {
    showUi();
    return () => {
      if (hideTimer.current) window.clearTimeout(hideTimer.current);
    };
  }, [showUi, player.phase]);

  /* --- keyboard shortcuts ------------------------------------------------ */
  useEffect(() => {
    if (!playable) return;
    const isTyping = () => {
      const el = document.activeElement;
      return (
        el instanceof HTMLElement &&
        (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable)
      );
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (isTyping() || e.metaKey || e.ctrlKey || e.altKey) return;
      const inPlayer = containerRef.current?.contains(document.activeElement) || !document.activeElement;
      const actions: Record<string, () => void> = {
        " ": togglePlay,
        k: togglePlay,
        m: toggleMute,
        f: toggleFullscreen,
        t: toggleTheater,
        c: toggleCaptions,
        "?": onOpenShortcuts,
      };
      if (actions[e.key]) {
        // only hijack globally when not typing; playback keys are page-wide by design
        e.preventDefault();
        actions[e.key]();
        showUi();
        return;
      }
      if (e.key === "?" || (e.key === "/" && e.shiftKey)) {
        e.preventDefault();
        onOpenShortcuts();
      }
      if (inPlayer && (e.key === "ArrowRight" || e.key === "ArrowLeft")) {
        // let the timeline handle arrows when focused
        return;
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [playable, togglePlay, toggleMute, toggleFullscreen, toggleTheater, toggleCaptions, onOpenShortcuts, showUi]);

  const showBigPlay = player.phase === "paused" && playable;
  const showBuffering = player.phase === "buffering" || player.phase === "connecting";
  const showUnmute = playable && player.playing && player.muted;

  return (
    <div
      ref={containerRef}
      className={cx("player", player.theater && "player--theater", !uiVisible && "player--idle")}
      data-phase={player.phase}
      onPointerMove={showUi}
      onPointerDown={showUi}
      onFocus={showUi}
      onKeyDown={showUi}
      tabIndex={-1}
    >
      {!playable ? (
        <StateScreen stream={stream} />
      ) : (
        <>
          <video
            ref={attachVideo}
            className="player__video"
            /* setting src (rather than swapping a <source> child) guarantees the
               browser reloads the new rendition — otherwise the quality menu
               would only change a label */
            src={playback?.kind === "progressive" ? rendition?.src : undefined}
            poster={playback?.posterUrl ?? undefined}
            muted={player.muted}
            playsInline
            preload="metadata"
            loop={stream.state === "live"}
            crossOrigin="anonymous"
            aria-label={`${stream.channel.displayName} — ${stream.title}`}
            onClick={togglePlay}
          >
            {playback?.kind === "hls" && playback.hlsUrl && (
              <source src={playback.hlsUrl} type="application/x-mpegURL" />
            )}
            {playback?.captions.map((c) => (
              <track key={c.id} kind="captions" src={c.src} srcLang={c.language} label={c.label} default={c.default} />
            ))}
          </video>

          {/* top row: live + uptime + viewers */}
          <div className="player__top">
            <div className="player__live">
              {stream.state === "live" ? (
                <>
                  <span className="live-pill">
                    <span className="live-dot" aria-hidden="true" />
                    LIVE
                  </span>
                  {stream.startedAt && (
                    <span className="player__uptime mono" aria-label={`Streaming for ${formatUptime(stream.startedAt, now)}`}>
                      {formatUptime(stream.startedAt, now)}
                    </span>
                  )}
                </>
              ) : (
                <span className="live-pill live-pill--muted">REPLAY</span>
              )}
            </div>
            <div className="player__top-right">
              <span className="player__viewers mono" aria-label={`${stream.viewerCount.toLocaleString()} viewers`}>
                <IconEye size={14} aria-hidden="true" />
                {stream.viewerCount.toLocaleString()}
              </span>
            </div>
          </div>

          {/* overlays */}
          {showBuffering && (
            <div className={cx("player__overlay", "player__overlay--subtle")} role="status" aria-live="polite">
              <Spinner size={28} label={player.phase === "connecting" ? "Connecting to stream" : "Buffering"} />
              <p className="player__overlay-text">
                {player.phase === "connecting" ? "Connecting…" : "Buffering…"}
              </p>
            </div>
          )}

          {player.phase === "interrupted" && (
            <div className="player__overlay" role="alert">
              <IconWifiOff size={26} />
              <p className="player__overlay-title">Reconnecting…</p>
              <p className="player__overlay-text">
                The stream connection dropped. Attempt {player.retryCount} of 3.
              </p>
              <button className="btn btn--ghost btn--sm" onClick={retry}>
                <IconRefresh size={14} /> Retry now
              </button>
            </div>
          )}

          {player.phase === "error" && player.error && (
            <div className="player__overlay player__overlay--error" role="alert">
              <IconAlert size={26} />
              <p className="player__overlay-title">{player.error.title}</p>
              <p className="player__overlay-text">{player.error.message}</p>
              {player.error.retryable && (
                <button className="btn btn--primary btn--sm" onClick={retry}>
                  <IconRefresh size={14} /> Reload stream
                </button>
              )}
            </div>
          )}

          {player.phase === "ended" && (
            <div className="player__overlay" role="status">
              <IconPlay size={24} />
              <p className="player__overlay-title">Broadcast ended</p>
              <p className="player__overlay-text">The broadcaster has stopped streaming. You can rewatch below.</p>
            </div>
          )}

          {showBigPlay && (
            <button className="player__big-play" onClick={togglePlay} aria-label="Play stream">
              <IconPlay size={26} />
            </button>
          )}

          {showUnmute && (
            <button className="unmute-pill" onClick={toggleMute}>
              <IconVolumeFilled size={16} />
              Tap to unmute
            </button>
          )}

          <PlayerControls onOpenShortcuts={onOpenShortcuts} />
        </>
      )}
    </div>
  );
}
