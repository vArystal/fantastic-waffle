import { useMemo } from "react";
import type { Stream } from "../../types";
import { cx } from "../../lib/utils";
import { routes, useRoute } from "../../lib/router";
import { IconCompass, IconHeart, IconHome } from "../icons";
import { ChannelRow, CategoryCard } from "../discovery/Cards";
import { RailSkeleton, SkeletonLine } from "../ui/primitives";
import type { AsyncState } from "../../state/useAsync";

type Discovery = {
  following: Stream[];
  recommended: Stream[];
  recentlyWatched: { slug: string; displayName: string; avatarUrl: string | null; verified: boolean }[];
  categories: { id: string; slug: string; name: string; artUrl: string | null; viewers: number; tags: string[] }[];
};

export function Sidebar({
  discovery,
  open,
  onClose,
  inline = false,
}: {
  discovery: AsyncState<Discovery>;
  open: boolean;
  onClose: () => void;
  /** true when the layout puts the sidebar in the grid flow (>= 1400px) */
  inline?: boolean;
}) {
  const route = useRoute();
  const data = discovery.data;

  const sections = useMemo(() => {
    if (!data) return null;
    return {
      following: data.following,
      recommended: data.recommended.slice(0, 6),
      recent: data.recentlyWatched.slice(0, 4),
      categories: data.categories.slice(0, 4),
    };
  }, [data]);

  return (
    <>
      {open && !inline && <div className="sidebar__scrim" onClick={onClose} aria-hidden="true" />}
      <aside className={cx("sidebar", (open || inline) && "is-open")} aria-label="Browse navigation">
        <nav className="sidebar__nav" aria-label="Sections">
          <a className={cx("sidebar__link", route.name === "home" && "is-active")} href={routes.home()}>
            <IconHome size={17} /> Home
          </a>
          <a className={cx("sidebar__link", route.name === "browse" && "is-active")} href={routes.browse()}>
            <IconCompass size={17} /> Browse
          </a>
          <a className={cx("sidebar__link", route.name === "following" && "is-active")} href={routes.following()}>
            <IconHeart size={17} /> Following
          </a>
        </nav>

        <div className="sidebar__scroll scroll-y">
          <section className="sidebar__section">
            <div className="sidebar__head">
              <h2 className="sidebar__title">Following</h2>
              <span className="sidebar__count mono">{sections?.following.length ?? 0}</span>
            </div>
            {!sections && (
              <div className="sidebar__skeletons">
                {[0, 1, 2].map((i) => (
                  <SkeletonLine key={i} height={30} />
                ))}
              </div>
            )}
            {sections?.following.length === 0 && (
              <p className="sidebar__empty">You aren't following anyone yet.</p>
            )}
            {sections?.following.map((s) => (
              <ChannelRow
                key={s.id}
                channel={s.channel}
                live={s.state === "live"}
                viewers={s.viewerCount}
                categoryName={s.category?.name}
                compact
              />
            ))}
          </section>

          <section className="sidebar__section">
            <div className="sidebar__head">
              <h2 className="sidebar__title">Recommended</h2>
            </div>
            {!sections && <RailSkeleton count={3} />}
            {sections?.recommended.map((s) => (
              <ChannelRow
                key={s.id}
                channel={s.channel}
                live={s.state === "live"}
                viewers={s.viewerCount}
                categoryName={s.category?.name}
                compact
              />
            ))}
          </section>

          {sections && sections.recent.length > 0 && (
            <section className="sidebar__section">
              <div className="sidebar__head">
                <h2 className="sidebar__title">Recently watched</h2>
              </div>
              {sections.recent.map((c) => (
                <ChannelRow
                  key={c.slug}
                  channel={{ ...c, viewerIsFollowing: false }}
                  live={data?.following.some((s) => s.channel.slug === c.slug && s.state === "live") ?? false}
                  compact
                />
              ))}
            </section>
          )}

          <section className="sidebar__section sidebar__section--cats">
            <div className="sidebar__head">
              <h2 className="sidebar__title">Categories</h2>
            </div>
            <div className="sidebar__cats">
              {data?.categories.slice(0, 4).map((c) => (
                <CategoryCard key={c.id} category={c} />
              ))}
            </div>
          </section>
        </div>

        <footer className="sidebar__foot">
          <p>VANTA demo · mock service layer</p>
          <p className="sidebar__foot-note">No real accounts, payments, or player tokens.</p>
        </footer>
      </aside>
    </>
  );
}
