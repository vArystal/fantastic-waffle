import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api } from "../../api/mockApi";
import { demoStore, type PersonaId } from "../../api/demo";
import type { AppSession, SearchResults } from "../../types";
import { cx, useDebounced, useMediaQuery } from "../../lib/utils";
import { navigate, routes, useRoute } from "../../lib/router";
import {
  IconBell,
  IconChevronDown,
  IconClose,
  IconCompass,
  IconGift,
  IconHeart,
  IconHome,
  IconLive,
  IconLogo,
  IconMenu,
  IconSearch,
  IconSliders,
  IconUser,
  IconVideo,
} from "../icons";
import { Avatar, Spinner } from "../ui/primitives";
import { Popover } from "../ui/Popover";

const PERSONA_LABEL: Record<PersonaId, string> = {
  guest: "Guest",
  viewer: "Viewer",
  subscriber: "Subscriber",
  moderator: "Moderator",
  streamer: "Broadcaster",
};

/* -------------------------------------------------------------------------- */
/* search                                                                     */
/* -------------------------------------------------------------------------- */

function SearchBox({ onDone }: { onDone?: () => void }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState<SearchResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const debounced = useDebounced(query, 220);
  const reqId = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (debounced.trim().length < 2) {
      setResults(null);
      setLoading(false);
      return;
    }
    const id = ++reqId.current;
    setLoading(true);
    api
      .search(debounced)
      .then((r) => {
        if (id === reqId.current) {
          setResults(r);
          setLoading(false);
          setOpen(true);
        }
      })
      .catch(() => {
        if (id === reqId.current) {
          setResults(null);
          setLoading(false);
        }
      });
  }, [debounced]);

  const flat = useMemo(() => {
    if (!results) return [];
    return [
      ...results.channels.slice(0, 3).map((c) => ({ kind: "channel" as const, id: c.id, label: c.displayName, sub: "Channel", slug: c.slug })),
      ...results.categories.slice(0, 3).map((c) => ({ kind: "category" as const, id: c.id, label: c.name, sub: `${c.viewers.toLocaleString()} viewers`, slug: c.slug })),
      ...results.streams.slice(0, 3).map((s) => ({ kind: "stream" as const, id: s.id, label: s.title, sub: s.channel.displayName, slug: s.channel.slug })),
    ];
  }, [results]);

  const go = (item: (typeof flat)[number]) => {
    if (item.kind === "category") navigate(routes.browse(item.slug));
    else navigate(routes.channel(item.slug));
    setOpen(false);
    setQuery("");
    onDone?.();
  };

  return (
    <div className="search">
      <div className={cx("search__field", open && query.length > 1 && "is-open")}>
        <IconSearch size={16} aria-hidden="true" />
        <input
          ref={inputRef}
          type="search"
          value={query}
          placeholder="Search channels, categories, streams"
          aria-label="Search"
          role="combobox"
          aria-expanded={open && flat.length > 0}
          aria-controls="search-results"
          aria-autocomplete="list"
          onChange={(e) => {
            setQuery(e.target.value);
            setActiveIndex(-1);
          }}
          onFocus={() => query.length > 1 && setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "Escape") {
              setOpen(false);
              setQuery("");
            }
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActiveIndex((i) => Math.min(i + 1, flat.length - 1));
            }
            if (e.key === "ArrowUp") {
              e.preventDefault();
              setActiveIndex((i) => Math.max(i - 1, -1));
            }
            if (e.key === "Enter" && activeIndex >= 0 && flat[activeIndex]) {
              go(flat[activeIndex]);
            }
          }}
        />
        {loading && <Spinner size={14} label="Searching" />}
        {query && !loading && (
          <button className="icon-btn icon-btn--sm" onClick={() => setQuery("")} aria-label="Clear search">
            <IconClose size={13} />
          </button>
        )}
      </div>

      {open && query.length > 1 && (
        <div className="search__results" id="search-results" role="listbox" aria-label="Search results">
          {flat.length === 0 && !loading && <p className="search__empty">No results for “{query}”.</p>}
          {flat.map((item, i) => (
            <button
              key={`${item.kind}-${item.id}`}
              role="option"
              aria-selected={i === activeIndex}
              className={cx("search__item", i === activeIndex && "is-active")}
              onClick={() => go(item)}
              onMouseEnter={() => setActiveIndex(i)}
            >
              <span className="search__item-kind">{item.kind === "category" ? <IconCompass size={14} /> : item.kind === "channel" ? <IconUser size={14} /> : <IconLive size={14} />}</span>
              <span className="search__item-label truncate">{item.label}</span>
              <span className="search__item-sub truncate">{item.sub}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* notifications                                                              */
/* -------------------------------------------------------------------------- */

const NOTIFICATIONS = [
  { id: "n1", kind: "live", text: "v0lt is live: Ascendant push — game 3", at: "2m ago", slug: "v0lt", unread: true },
  { id: "n2", kind: "sub", text: "riff_rat resubscribed for 22 months", at: "18m ago", slug: "v0lt", unread: true },
  { id: "n3", kind: "live", text: "brk is live: Ranked with the crew", at: "1h ago", slug: "brk", unread: false },
];

function NotificationsMenu() {
  const [read, setRead] = useState<string[]>([]);
  const unreadCount = NOTIFICATIONS.filter((n) => n.unread && !read.includes(n.id)).length;
  return (
    <Popover
      label="Notifications"
      width={320}
      align="end"
      trigger={({ open, toggle }) => (
        <button
          className={cx("icon-btn header__icon", open && "icon-btn--active")}
          onClick={toggle}
          aria-label={`Notifications${unreadCount ? `, ${unreadCount} unread` : ""}`}
        >
          <IconBell size={19} />
          {unreadCount > 0 && <span className="dot-badge" aria-hidden="true">{unreadCount}</span>}
        </button>
      )}
    >
      {(close) => (
        <div className="notif">
          <div className="notif__head">
            <span className="eyebrow">Notifications</span>
            <button
              className="btn btn--quiet btn--sm"
              onClick={() => setRead(NOTIFICATIONS.map((n) => n.id))}
              disabled={unreadCount === 0}
            >
              Mark all read
            </button>
          </div>
          {NOTIFICATIONS.map((n) => (
            <button
              key={n.id}
              className={cx("notif__item", n.unread && !read.includes(n.id) && "is-unread")}
              onClick={() => {
                setRead((prev) => [...prev, n.id]);
                navigate(routes.channel(n.slug));
                close();
              }}
            >
              <span className={cx("notif__icon", `notif__icon--${n.kind}`)} aria-hidden="true">
                {n.kind === "sub" ? <IconGift size={14} /> : <IconLive size={14} />}
              </span>
              <span className="notif__body">
                <span className="notif__text">{n.text}</span>
                <span className="notif__time mono">{n.at}</span>
              </span>
            </button>
          ))}
          <p className="notif__foot">
            Notification preferences are stored per channel under Following.
          </p>
        </div>
      )}
    </Popover>
  );
}

/* -------------------------------------------------------------------------- */
/* account menu                                                               */
/* -------------------------------------------------------------------------- */

function AccountMenu({
  session,
  onOpenDemo,
  onSignIn,
}: {
  session: AppSession | null;
  onOpenDemo: () => void;
  onSignIn: () => void;
}) {
  const user = session?.user ?? null;
  if (!user) {
    return (
      <button className="btn btn--primary btn--sm header__signin" onClick={onSignIn}>
        Sign in
      </button>
    );
  }
  return (
    <Popover
      label="Account"
      width={260}
      align="end"
      trigger={({ open, toggle }) => (
        <button className={cx("header__avatar-btn", open && "is-open")} onClick={toggle} aria-label="Account menu">
          <Avatar src={user.avatarUrl} name={user.displayName} size={30} />
          <IconChevronDown size={13} className="header__avatar-caret" />
        </button>
      )}
    >
      {(close) => (
        <div className="menu" role="menu">
          <div className="account__head">
            <Avatar src={user.avatarUrl} name={user.displayName} size={36} />
            <div>
              <p className="account__name">{user.displayName}</p>
              <p className="account__role">{PERSONA_LABEL[demoStore.get().persona]} · demo session</p>
            </div>
          </div>
          <div className="menu__divider" role="separator" />
          <button className="menu__item" role="menuitem" onClick={() => { navigate(routes.following()); close(); }}>
            <IconHeart size={15} /> Following
          </button>
          <button
            className="menu__item"
            role="menuitem"
            onClick={() => {
              onOpenDemo();
              close();
            }}
          >
            <IconSliders size={15} /> Demo & role controls
          </button>
          <div className="menu__divider" role="separator" />
          <button
            className="menu__item menu__item--danger"
            role="menuitem"
            onClick={() => {
              demoStore.set({ persona: "guest" });
              close();
            }}
          >
            Sign out
          </button>
        </div>
      )}
    </Popover>
  );
}

/* -------------------------------------------------------------------------- */
/* header                                                                     */
/* -------------------------------------------------------------------------- */

export function AppHeader({
  session,
  onOpenDemo,
  onOpenSidebar,
}: {
  session: AppSession | null;
  onOpenDemo: () => void;
  onOpenSidebar: () => void;
}) {
  const route = useRoute();
  const isNarrow = useMediaQuery("(max-width: 767px)");
  const [mobileSearch, setMobileSearch] = useState(false);
  const routeName = route.name;

  const signIn = useCallback(() => demoStore.set({ persona: "subscriber" }), []);

  return (
    <header className="header">
      <div className="header__left">
        <button className="icon-btn header__menu" onClick={onOpenSidebar} aria-label="Open navigation">
          <IconMenu size={19} />
        </button>
        <a href={routes.home()} className="brand" aria-label="VANTA home">
          <IconLogo size={22} />
          <span className="brand__word">VANTA</span>
        </a>
      </div>

      {!isNarrow && (
        <nav className="header__nav" aria-label="Primary">
          <a className={cx("header__link", routeName === "home" && "is-active")} href={routes.home()}>
            <IconHome size={16} /> Home
          </a>
          <a className={cx("header__link", routeName === "browse" && "is-active")} href={routes.browse()}>
            <IconCompass size={16} /> Browse
          </a>
          <a className={cx("header__link", routeName === "following" && "is-active")} href={routes.following()}>
            <IconHeart size={16} /> Following
          </a>
        </nav>
      )}

      <div className="header__center">
        {!isNarrow && <SearchBox />}
      </div>

      <div className="header__right">
        {isNarrow && (
          <button className="icon-btn header__icon" onClick={() => setMobileSearch((v) => !v)} aria-label="Search" aria-expanded={mobileSearch}>
            <IconSearch size={19} />
          </button>
        )}
        {session?.canGoLive && (
          <button className="btn btn--ghost btn--sm header__golive" onClick={() => onOpenDemo()}>
            <IconVideo size={15} /> Go live
          </button>
        )}
        <NotificationsMenu />
        <AccountMenu session={session} onOpenDemo={onOpenDemo} onSignIn={signIn} />
      </div>

      {isNarrow && mobileSearch && (
        <div className="header__mobile-search">
          <SearchBox onDone={() => setMobileSearch(false)} />
        </div>
      )}
    </header>
  );
}
