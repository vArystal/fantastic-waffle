# VANTA — implementation report

Evidence-backed summary of what was built, what was verified, and what remains.
Anything not listed as verified is not claimed.

---

## 0. Starting point (Phase 0 audit)

The workspace was **empty** — no repository, routes, design tokens, player
infrastructure, chat transport, auth, or API. Confirmed before any code was
written:

```
$ find /home/user -maxdepth 3 -not -path '*/node_modules*'
/home/user
```

So Phase 0's usual deliverable ("preserve existing behaviour") collapses to: there
is nothing to preserve, and every integration is new. The audit output that
matters is therefore the **inventory of what does not exist**, which is recorded
in `docs/API-INTEGRATION.md` as required backend work.

Stack chosen with the user's approval: React 19 + Vite + TypeScript, mock service
layer with documented boundaries.

---

## 1. What was built

| Phase | Delivered |
| --- | --- |
| 1 — Core streaming | Responsive watch page, real video with 3 renditions + captions + DVR, stream status/error states, identity header, follow/share/copy/report/clip controls, desktop + mobile + tablet layouts, theater mode. |
| 2 — Chat & moderation | Transport-backed chat with reconnect, optimistic sends with retry, role badges, pin/clear/timeout/ban enforced server-side, slow mode + flood + duplicate + link/banned-word protection, disconnected state. |
| 3 — Community & discovery | Following / recommended / recently watched, categories, search with autocomplete, clips + VODs + schedule + about tabs, related live channels, empty states for every list. |
| 4 — Interactive widgets | Polls (real vote flow), prediction + goals + leaderboard (real reads, writes gated), rewards (read-only), support alerts — mounted in the Community tab, not the initial viewport. |
| 5 — Polish & a11y | Skeletons, token system, motion with reduced-motion support, keyboard shortcuts, focus management, mobile tap targets, safe-area insets, a11y contrast fixes. |
| 6 — Verification | 54 automated tests, axe-core WCAG 2.1 AA audit, 7-width responsive sweep, role/permission matrix, network and stream-state matrix, keyboard-only pass. |

---

## 2. Automated test results

```
$ npm test
 ✓ tests/mockApi.test.ts      (32 tests)
 ✓ tests/chatRender.test.tsx  (10 tests)
 ✓ tests/utils.test.ts        (12 tests)

 Test Files  3 passed (3)
      Tests  54 passed (54)
```

```
$ npm run typecheck      # tsc -b, strict
(no output — 0 errors)

$ npm run build
dist/index.html                   2.20 kB │ gzip:   0.83 kB
dist/assets/index-Cg-VT5NK.css   70.17 kB │ gzip:  13.20 kB
dist/assets/index-iAxyDvqx.js   385.62 kB │ gzip: 113.38 kB
✓ built in 220ms

$ npx oxlint src tests
Found 23 warnings and 0 errors.
```

The 23 warnings are React-Compiler advisories (mostly
`set-state-in-effect` for deliberate state resets on stream identity change, and
`Date` purity in render). They are advisory, non-blocking, and listed under
limitations rather than hidden.

What the tests actually protect:

- **Service rules** — permission refusal (`clearChat` as a viewer → 403), peer
  moderation refusal, timeout bounds, duplicate follow → 409, duplicate vote →
  409, slow mode → 429, link/banned-word blocking, clip DVR requirement →
  501, `unsupported` for predictions and rewards, leaderboard privacy, hidden
  goals, network-profile error codes.
- **Rendering safety** — an XSS payload (`<img onerror>` + `<script>`) renders as
  text and sets no global; emotes/mentions resolve to elements; tombstones for
  removed messages; failure reason + retry on a failed send.
- **Player defaults** — starts muted, never enters `playing` for an offline
  stream, selects the highest rendition, captions off by default.
- **Formatting** — counts, durations, past *and future* relative times (poll and
  prediction deadlines), uptime, initials, percent guards.

---

## 3. Responsive verification

Measured in Chromium with `document.documentElement.scrollWidth - innerWidth`
(horizontal overflow) and live element geometry:

| Viewport | Overflow | Player | Chat | Layout mode |
| --- | --- | --- | --- | --- |
| 320 | **0** | 296×167 | tabbed | narrow mobile |
| 375 | **0** | 351×197 | tabbed | mobile |
| 390 | **0** | 366×206 | tabbed | mobile |
| 768 | **0** | 728×410 | tabbed | tablet |
| 1024 | **0** | 628×353 | 340 (sticky) | compact desktop |
| 1280 | **0** | **876**×493 | 340 (sticky) | desktop |
| 1440 | **0** | 792×446 + 244 sidebar | 340 (sticky) | full desktop |

All five secondary tabs (About, Schedule, Clips, Past broadcasts, Community) were
opened at 390px: overflow **0** in every case.

Two layout defects found and fixed during this sweep:

1. At 1280 the inline sidebar squeezed the player to 632px. The sidebar now
   becomes a drawer below 1400px → player 632 → **876px**.
2. At 768 the search field was clipped by the primary nav. Nav hides below
   1000px; it stays reachable via the drawer (bottom bar below 768).

Mobile specifics verified: bottom navigation renders, chat/details switcher
present, no side chat, composer row 48px with 40px send button, `16px` composer
font (prevents iOS zoom), safe-area padding on the composer and bottom nav.

---

## 4. Behaviour verification (browser)

Playback — real media, real renditions:

| Assertion | Result |
| --- | --- |
| Press play → element advances | `paused: false, currentTime 1.57s, duration 26s, videoWidth 1280` |
| Audio never autoplays | `muted: true` before any interaction |
| Unmute works | `muted: false` |
| Quality 720p → 360p | `currentSrc: stream-360.mp4`, `videoWidth` **1280 → 640**, playhead preserved, still playing |
| Captions toggle | track `en` → `mode: "showing"`, button `aria-pressed="true"` |
| Timeline keyboard seek | Home → 0.5s, ArrowRight → 5.8s |
| "Go live" when behind edge | appears at behind>2s; click → `t=25.6 / 26` (behind 0.4s) |
| Picture-in-picture | entered PiP successfully |
| Theater mode | `data-theater=true`, player 792 → **1036px** |

Chat and moderation (role matrix):

| Persona | Composer | Mod buttons | Moderator action |
| --- | --- | --- | --- |
| Guest | locked ("Sign in to chat") | 0 | n/a |
| Viewer | enabled | 0 | refused by service (403) |
| Moderator | enabled | 23 (per row) | timeout accepted → system notice rendered |
| Broadcaster | enabled | 23 | "Clear chat" + poll close available |

Chat mechanics: own message renders exactly once (`own-row-count: 1`, no
duplicate keys); duplicate send is rejected with an inline reason and a retry
affordance; link posting rejected; slow-mode countdown shown; Escape clears a
reply; chat reconnect banner appears on transport drop **without** touching
playback.

Stream states (all nine required, plus network):

| State | Rendered |
| --- | --- |
| Live + playing | video, LIVE pill, uptime, viewer count, trend |
| Live + loading | "Connecting…" overlay with spinner |
| Reconnecting | "Reconnecting… attempt n of 3" + retry |
| Temporarily interrupted | same overlay (stall path) |
| Offline | "Channel is offline" + "Check again" |
| Scheduled | "Scheduled — not live yet", body + relative start |
| Ended | REPLAY pill, playable, ENDED chip |
| Restricted (mature) | "Restricted stream" + reason |
| Unavailable | "Stream unavailable" + reason |
| No playback source | "No playback source" state |
| Playback failure | error overlay with "Reload stream" |
| Chat disconnected | banner + Reconnect, playback unaffected |
| Empty clips/VODs | dedicated empty states |
| Missing metadata | avatar/thumb fallbacks with initials and placeholder art |
| API offline | "You're offline" + "Try again" |
| Slow network | 18 skeletons → 0, then content |

Other flows: follow → reload → state persisted; follow conflict/rollback;
report dialog (submit disabled until a reason is chosen, then success toast);
clip creation (playback pauses, range captured, 5–60s validation, new clip
appears in the Clips tab); subscribe dialog shows tiers with checkout disabled
and an explanation; search autocomplete returns channels, categories and streams
(keyboard-navigable).

---

## 5. Accessibility verification

axe-core, WCAG 2.1 A + AA rules:

| Surface | Violations |
| --- | --- |
| Watch page 1440 | **0** |
| Watch page 390 | **0** |
| Home 1440 | **0** |

Fixed during the audit (all were real):

1. `--text-faint` failed 4.5:1 on surfaces (3.97:1) → raised to `#838d9d` (4.87:1).
2. Live badge white-on-red failed (3.71:1) → added `--live-strong` (5.3:1).
3. `.btn--primary` white on violet failed (3.26:1) → added `--accent-solid`.
4. `aria-label` on a bare `<span>` (chat status) → removed; SR text kept.
5. Quality button's accessible name didn't contain its visible label → `Quality: 720p`.
6. Poll options had an aria-label that omitted the visible text → removed.
7. Mobile share button lost its name when the label was hidden → `aria-label`.
8. An invisible focus stop (collapsed volume slider) → expands on `:focus-within`.
9. Focus not restored after a dialog opened from a menu → rAF-deferred restore
   with a `data-dialog-return` fallback.

Keyboard-only pass: skip link first, 10 sequential stops all visible with a
visible ring, timeline operable by arrows/Home/End, dialogs trap and restore
focus, Escape closes dialogs and popovers, `prefers-reduced-motion` reduces the
live-dot animation to `1e-06s / 1 iteration`.

---

## 6. Defects found by this verification (and fixed)

Recorded because a report that only lists successes is not a report.

| # | Defect | Impact | Fix |
| --- | --- | --- | --- |
| 1 | Chat messages duplicated (optimistic copy + transport echo) | duplicate React keys, doubled messages | de-dupe by id in `useChat`, single replacement path |
| 2 | Quality selector only changed a label | **fake control** | `video.src` now carries the rendition; reload + position restore verified (1280→640) |
| 3 | Follower count off by one after follow→unfollow→follow | wrong data | seed-aware `followerCountFor()` |
| 4 | Emote PNGs missing (generation run failed mid-way) | blank emotes | regenerated; `naturalWidth 140` asserted |
| 5 | Hero artwork rendered as a tall narrow column | broken layout | `.hero .hero__art` specificity vs `.thumb` |
| 6 | "at live edge" wrong for the looping demo source | misleading DVR state | loop-wrap detection in the time handler |
| 7 | Volume slider focusable while invisible | invisible focus stop | `:focus-within` reveal |
| 8 | Focus lost after dialog opened from a menu | keyboard trap-out | deferred restore + fallback |
| 9 | Contrast failures (8 nodes at desktop, 12 at mobile) | WCAG AA failure | token changes above |
| 10 | Sidebar squeezed the player at 1280 | worse primary experience | drawer below 1400 |
| 11 | Nav clipped search at 768 | unusable field | nav hidden below 1000 |
| 12 | Duplicate-key console errors ×13 | unreliable list identity | same as #1 |

---

## 7. Known limitations

**Because there is no backend (by design, documented in API-INTEGRATION.md):**

1. Data is a seeded in-memory dataset. Mutations reset on full page reload except
   follows and leaderboard privacy, which persist to `localStorage`.
2. Chat messages do not persist across reloads; ambient traffic is generated
   client-side to exercise rendering and rate limits.
3. Notifications are a static front-end list; there is no push or fan-out.
4. Search is a client-side filter over the seed, not a search service.

**Deliberately not implemented (would be fake otherwise):**

5. Payments/subscription checkout — tiers are read-only, checkout disabled.
6. Points redemption and prediction wagers — service returns `501 unsupported`.
7. Real-money support alerts — amounts are server display strings only.

**Technical limitations to address with the real stack:**

8. **HLS is not wired.** `PlaybackSource` supports `kind: "hls"` and the UI
   surfaces the mode, but no HLS engine is bundled. Adaptive bitrate needs
   `hls.js` (or native Safari playback) plus `seekable.end()` for the live edge.
   Progressive renditions are used until then. This is the single biggest
   remaining gap for real streaming.
9. **Chat rendering caps at 90 mounted messages** rather than a true virtual
   scroller. Fine for a 300–400 message room; a 10k-message history needs
   windowing (e.g. `@tanstack/virtual`).
10. **Mobile keyboard** was verified by emulating a viewport and asserting focus
    and font-size behaviour, not with a real iOS/Android keyboard open. The CSS
    uses `dvh`, safe-area insets and a 16px composer font, which are the known
    mitigations, but device testing is still required.
11. **Chat user profile** navigation routes to the channel page. A dedicated user
    profile route does not exist.
12. **i18n**: English only; the language chip is data, not a UI locale switch.
13. **Lint warnings**: 23 React-Compiler advisories remain (see §2). None are
    errors and none affect behaviour, but they should be triaged with the app's
    real toolchain.
14. **Aspect ratio**: the player defaults to 16:9 and reads `aspectRatio` from the
    source, but no vertical/4:3 stream was tested.
15. **Demo controls must be deleted** before shipping — `components/dialogs/Dialogs.tsx`
    (`DemoPanel`), `api/demo.ts`, and the persona switch in `mockApi.currentUser`.

---

## 8. Remaining work, in priority order

1. Wire the real API and auth; delete the demo layer (§7.15).
2. Add the HLS engine and a real live-edge calculation (§7.8).
3. Real WebSocket chat with server fan-out; keep `MockChatTransport`'s interface.
4. Clip transcoding pipeline + pending state.
5. Points economy → enable prediction entries and reward redemption.
6. Billing → real subscription tiers and entitlements.
7. Virtualize chat history; add device testing for the mobile keyboard.
8. Triage the lint advisories; add visual regression snapshots in CI.

---

## 9. Static deployment (GitHub Pages)

The app is deployable as static files: hash routing means no server rewrites, and
`vite.config.ts` sets `base: './'` so one build works both at a domain root and
under a project subpath. `.github/workflows/deploy.yml` runs typecheck → tests →
build → publish on every push to `main`.

Verified against the **production build served from a subpath**, the way Pages
serves a project site (`http://localhost:8099/vanta/`):

| Check | Result |
| --- | --- |
| Failed requests / 4xx responses | **0** |
| Console errors | **0** |
| Images loaded (all from `/vanta/media/...`) | 29 / 29, **0 broken** |
| Video source | `/vanta/media/demo/stream-720.mp4`, `readyState 4`, `duration 26`, `videoWidth 1280` |
| Press play in the built app | `paused: false`, `t: 2.19s` |
| Route + document title under the subpath | `v0lt · Ascendant push — … · VANTA` |
| Chat rendered | 232 rows |
| `favicon.svg`, `.nojekyll` | 200 |

Screenshot: `docs/screens/pages-build-subpath.png`.

One code change was required for this: media URLs were root-absolute
(`/media/...`) which 404s under `/repo/`. `src/api/seed.ts` now derives the base
from `import.meta.env.BASE_URL`, so no environment-specific configuration is
needed. A clean extraction of the delivered archive was installed with
`npm ci` and re-verified end to end (typecheck, 54/54 tests, build) before the
archive was handed over.

## 10. Evidence index

- Unit/component tests: `tests/` (run `npm test`).
- Browser scripts used above: `qa/` (`interactions.js`, `roles.js`, `states.js`,
  `mobile.js`, `a11y.js`, `keyboard2.js`, `quality.js`, `player2.js`, `flows.js`).
- Screenshots: `docs/screens/` — `stream-playing-1440`, `stream-1024`,
  `tablet-768`, `mobile-390`, `home-1440`, `browse-1440`, `state-offline`,
  `demo-panel`.
- Asset provenance: `tools/gen_assets.py` (deterministic; regenerates every
  video, caption track, avatar, thumbnail and emote used here).

All measurements above were produced by running the app in Chromium against the
dev server in this workspace. Where a result could not be produced that way, it
is listed under limitations rather than assumed.
