# VANTA — architecture

## 1. Why this shape

The brief asked for a page that behaves like a product, keeps playback reliable
first, and never fakes a capability. Three decisions follow from that:

1. **The service layer is the only thing that knows about data.** Components
   never import seed data. They call `api.*` and receive the types in
   `src/types.ts`. Swapping `mockApi` for a real client is a single-file change.
2. **Playback state is isolated from page state.** The player has its own state
   machine and its own context, so a chat re-render, a scroll, or a follow
   mutation can never interrupt or restart the video.
3. **Permissions live in the service, not the UI.** Hiding a moderation button
   is a UX affordance; the service refuses the call regardless. Tests assert the
   refusal, not the hidden button.

## 2. Layers

```
┌──────────────────────────────────────────────────────────────┐
│ pages/            StreamPage · HomePage · BrowsePage · FollowingPage
├──────────────────────────────────────────────────────────────┤
│ components/       player · chat · stream · discovery · widgets · dialogs · ui
├──────────────────────────────────────────────────────────────┤
│ state/            useAsync (resource) · useChat (transport) · useDemo
├──────────────────────────────────────────────────────────────┤
│ api/              mockApi (contract + rules) · demo (switches) · seed (data)
├──────────────────────────────────────────────────────────────┤
│ types.ts          domain contract shared with the backend
└──────────────────────────────────────────────────────────────┘
```

Cross-cutting: `lib/utils.ts` (formatting + hooks), `lib/router.ts` (hash
router), `styles/*` (tokens → primitives → feature styles).

## 3. Component map

### Shell
- `App` — providers (`ToastProvider`), shell layout, route switch, mobile nav.
- `layout/AppHeader` — brand, primary nav, search with autocomplete,
  notifications, account menu, go-live entry.
- `layout/Sidebar` — following, recommended, recently watched, categories.
  Rendered in-flow at ≥1400px, as a drawer below that.
- `ui/Toast` — `ToastProvider`, `useToast`, and the focus-trapped `Dialog`.

### Player (`components/player/`)
| File | Responsibility |
| --- | --- |
| `PlayerContext.tsx` | State machine + media element bindings + reconnect. Exposes three contexts: state, time, actions. |
| `VideoPlayer.tsx` | The `<video>` element, overlays, non-playable screens, keyboard map. |
| `PlayerControls.tsx` | Timeline (pointer + keyboard), volume, quality menu, settings, theater/fullscreen/PiP. |

The state machine (`PlaybackPhase`): `idle → connecting → playing ⇄ paused /
buffering`, plus `interrupted` (recovering) and `error` (terminal, with retry),
and `ended`.

**Why three contexts?** The playback clock ticks ~4×/s. Putting it in the same
context as the rest of the player would re-render every control on every tick.
`usePlayerTime()` is consumed only by the timeline and the readout.

**Reconnect policy:** media errors and stalls during playback enter
`interrupted`, reload the element, and retry with exponential backoff
(1.2s → 2.4s → 4.8s, max 3 attempts), then fall to `error` with a manual retry.
A user-initiated failure is never misreported as a network problem.

### Chat (`components/chat/`)
- `ChatPanel` — history, pin banner, pause/resume with unread count, moderation
  sheet, connection banner, composer. Owns scroll-follow behaviour.
- `ChatMessageRow` — one message. **User content is rendered as text nodes.**
  Emotes and mentions are resolved into React elements; nothing is ever passed
  to `dangerouslySetInnerHTML`.
- `ChatComposer` — auto-growing textarea, emote picker, slow-mode cooldown
  countdown, reply context, length guard.
- `state/useChat.ts` — owns the message list, optimistic sends, de-duplication,
  reconnect, and paging older history.

### Stream surface (`components/stream/`)
- `StreamHeader` — identity, follow + notification prefs, subscribe, share/copy,
  report, clip. Follow is optimistic with rollback and a double-submit guard.
- `StreamTabs` — About / Schedule / Clips / Past broadcasts / Community, with
  roving-tabindex arrow navigation.

### Widgets (`components/widgets/Community.tsx`)
Poll strip (contextual, above chat), prediction, goals, leaderboard with privacy
opt-out, rewards, support alerts. Each is mounted only inside the Community tab,
so the initial viewport is never cluttered — the brief's explicit requirement.

## 4. Layout system

Content-driven breakpoints:

| Width | Shell | Watch layout |
| --- | --- | --- |
| 320–479 | header + bottom nav | player, header, chat/details tabs |
| 480–767 | header + bottom nav | same, more breathing room |
| 768–1023 | drawer sidebar | single column, tabs below player |
| 1024–1279 | drawer sidebar | **player + 340px sticky chat** |
| 1280–1399 | drawer sidebar | same, wider player (≈876px) |
| ≥1400 | inline 244px sidebar | player + chat with sidebar |

The sidebar only takes grid space at ≥1400px. At 1280px it would have squeezed
the player to 632px, which is worse than leaving it in a drawer — measured, not
guessed.

**Theater mode** sets `html[data-theater="true"]`, collapsing the sidebar and
widening the player (measured 792 → 1036px at 1440).

**Mobile tabs** (`Chat` / `Details`) swap panels *without unmounting the
player*: verified by asserting `currentTime` advances and `paused === false`
across a tab switch.

## 5. Design tokens

`styles/tokens.css` defines surfaces, text, lines, accents, radii, a 4px spacing
scale, type scale, elevation, motion, layout, and z-index. Highlights:

- Surfaces: `#08090d` → `#0f1218` → `#151a22` → `#1c222d` → `#242b38`.
- Accent violet `#8b7cff` for signals; `--accent-solid` (`#6a4df0`) when violet is
  a button *fill*, because white text needs the darker value to clear 4.5:1.
- Trust teal `#46e0c0` for positive/live-adjacent data; live red `#f04452` for
  status, with `--live-strong` for white-on-red labels.
- Type: 13px UI base, one display weight for stream titles, uppercase
  letter-spaced eyebrows, monospace tabular numerals for all live data
  (viewers, countdowns, durations).

Palette validation was done against the brief's tokens and then adjusted where
they failed contrast (documented in the implementation report).

## 6. Rendering and performance

- **Chat DOM is bounded.** Only the last 90 messages are mounted; older pages
  load on scroll. A full virtual scroller was rejected as unnecessary
  complexity for a 300–400 message room — see limitations.
- **Message de-duplication is by id**, so the optimistic copy and the transport
  echo cannot double-render. This was a real bug found in testing (duplicate
  React keys) and fixed in `useChat`.
- **High-frequency state is throttled by separation**, not by timers: the player
  clock is its own context; the "now" clock (`useNow`) pauses when the tab is
  hidden.
- **Lazy loading**: every thumbnail is `loading="lazy"` with an explicit
  aspect ratio (no layout shift); below-the-fold discovery data loads per rail.
- **Skeletons everywhere**: page, rails, chat history, clip/VOD grids — no
  abrupt empty layouts.
- **Cleanup**: every listener, interval, media element binding, and observer is
  removed in its effect teardown. `useAsync` ignores stale responses by request
  id so late replies cannot overwrite fresher ones.

## 7. Accessibility implementation

- Skip link, landmark structure, one `<h1>` per page.
- Focus-visible ring on every interactive control; measured during keyboard QA.
- Timeline is a real `role="slider"` with `aria-valuetext` and arrow/Home/End keys.
- Dialogs: `aria-modal`, focus moved in, Tab cycled, Escape closes, focus
  restored (with an rAF deferral so a closing popover can't steal it back).
- Popovers: Escape closes, outside pointer dismisses, first item focused.
- Chat log is `role="log" aria-live="polite" aria-relevant="additions"`, and
  connection status changes announce through a polite live region rather than
  per-message chatter.
- `prefers-reduced-motion` is honoured globally and can also be forced with
  `html[data-motion="reduced"]`.
- Status is never colour-only: "LIVE" is a word, "OFFLINE" is a word, chat
  connection has a text label for assistive tech, roles carry `aria-label`s.

## 8. Security posture

- No `innerHTML` anywhere in the message pipeline; XSS payloads are asserted to
  render as text in `tests/chatRender.test.tsx`.
- Validation, rate limiting, duplicate detection, link and banned-word blocking
  all live in the service layer (`api/mockApi.ts`), which is what the tests hit.
- No credentials, stream keys, or playback tokens exist in the client; the
  integration doc states where the real implementation must keep them server-side.
- CSRF is not applicable to the mock (no cookies); the integration doc calls out
  where it becomes mandatory.
