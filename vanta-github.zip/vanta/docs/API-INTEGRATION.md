# VANTA — API integration contract

Everything the UI expects from a backend, in one place. The mock service
(`src/api/mockApi.ts`) implements this contract exactly, so replacing it is a
matter of implementing these methods against real HTTP/WebSocket endpoints.

**Ground rules**

1. Permissions are decided server-side from the authenticated session. The client
   never sends its own role.
2. Failures use the `ApiError` code set below so UI handling does not change.
3. Mutations are idempotent or guarded — a duplicate follow, vote, or send is a
   `conflict`, never a silent double-apply.
4. Money, points balances, and entitlements are server-owned values. The client
   renders them; it never computes them.

---

## Error model

```ts
class ApiError {
  code: "unauthenticated" | "forbidden" | "not_found" | "rate_limited"
      | "conflict" | "validation_failed" | "network" | "server_error" | "unsupported";
  status: number;
  message: string;               // safe to show the user
  retryAfter?: number;           // seconds, for rate limits
  details?: Record<string, string>;
}
```

`unsupported` is the code used when a capability depends on a service that is
not deployed (points economy, payments, clip pipeline). It is what keeps the UI
honest instead of decorative.

---

## Session

| Method | Contract |
| --- | --- |
| `GET /api/session` → `AppSession` | `{ user: User \| null, canGoLive: boolean }`. `user.roles` is authoritative. |

`User` carries `id, login, displayName, avatarUrl, color, roles[], verified`.

---

## Streams

`GET /api/streams/:slug` → `Stream`

```ts
Stream {
  id; slug; title;
  channel: Channel;
  category: Category | null;
  state: "live" | "offline" | "scheduled" | "ended" | "restricted" | "unavailable";
  startedAt; scheduledFor; endedAt;
  viewerCount; language; tags[]; isMature;
  playback: PlaybackSource | null;
  stats: { peakViewers; followerGain; viewerTrend: number[] };  // 30 one-minute samples
  chatSettings: { slowModeSeconds; subscribersOnly; followersOnly; requiresVerifiedEmail };
  stateReason: string | null;          // human copy for non-playable states
  viewerCanModerate; viewerCanCreateClip;   // computed per viewer, per request
}
```

`playback` is `null` for any state that cannot be played. The client renders the
matching empty state from `state` + `stateReason` and never invents a source.

### Playback source

```ts
PlaybackSource {
  kind: "progressive" | "hls";
  hlsUrl?: string;               // required when kind === "hls"
  renditions: { id; label; height; src; bitrateKbps }[];
  captions: { id; label; language; src; default? }[];
  posterUrl: string | null;
  dvr: { enabled: boolean; windowSeconds: number };
  lowLatency: boolean;
  aspectRatio?: string;
}
```

**Integration notes**

- `progressive` is what the demo ships: the quality menu swaps `video.src` and
  restores `currentTime`. This is real source switching, not a label change.
- `hls` requires an HLS engine (e.g. `hls.js` or native Safari). Wire it inside
  `VideoPlayer`'s element ref; the quality menu must then delegate to
  `levels`/`currentLevel` rather than swapping `src`. The menu already labels the
  mode as "Adaptive" and explains itself.
- **Playback tokens must not be long-lived or client-inspectable.** Sign the
  manifest URL per viewer with a short TTL, and keep stream keys server-side
  only. Nothing in this client needs a stream key.
- DVR: `goLive()` seeks to `duration - 1.2s` for the looping demo source. With
  HLS, seek to `video.seekable.end(seekable.length - 1)` instead — that is the
  one line that must change (`PlayerContext.goLive`).

---

## Channel & following

| Method | Contract |
| --- | --- |
| `GET /api/channels/:slug` → `Channel` | Includes the viewer's own follow state and alert preference. |
| `PUT /api/channels/:id/follow` `{ following }` → `{ following, followerCount }` | `409 conflict` if already in that state; `422` past the follow limit; `401` when signed out. |
| `PUT /api/channels/:id/follow/alerts` `{ alerts: "all" \| "live" \| "none" }` | `422` unless currently following. |
| `POST /api/channels/:id/watched` | Fire-and-forget "recently watched" update. |

The client updates optimistically and **rolls back to server-confirmed values**
on failure — the rollback path is tested.

---

## Chat

**REST**

| Method | Contract |
| --- | --- |
| `GET /api/streams/:id/chat?before=<cursor>&limit=25` → `{ messages[], olderCursor }` | Newest-last page shape. `olderCursor: null` means the start is reached. |
| `POST /api/streams/:id/chat` `{ text, replyTo? }` → `ChatMessage` | Validation, rate limits, duplicate detection, banned words, link blocking, slow mode, subscriber-only mode. |
| `DELETE /api/messages/:id` | Author may delete own; moderators may delete any; otherwise `403`. |
| `POST /api/streams/:id/chat/clear` | Moderator/broadcaster only. Leaves a tombstone notice — history is not silently wiped. |
| `PUT /api/streams/:id/chat/pin` `{ messageId \| null }` | Moderator/broadcaster only. |
| `POST /api/streams/:id/moderation/timeout` `{ userId, seconds, reason? }` | 1s–14 days. Cannot target a peer moderator or the broadcaster (`403`). |
| `POST /api/streams/:id/moderation/ban` `{ userId }` | Same peer restriction. |

**Transport (WebSocket)**

The demo's `MockChatTransport` is the exact seam to replace. It exposes:

```ts
connect(streamId): void;
disconnect(): void;
onEvent(cb: (e: ChatEvent) => void): () => void;   // returns unsubscribe
onStatus(cb: (s: "connecting" | "connected" | "reconnecting" | "disconnected") => void): () => void;
```

`ChatEvent` is one of `message | update | remove | clear | pin | poll | alert |
connection`. A real implementation maps server frames onto these and nothing in
the UI changes.

**Rules the server must own** (implemented in the mock, asserted by tests):

- `maxLength: 500`, non-empty after trim.
- Minimum 0.7s between messages from one user; channel slow mode on top of that
  (moderators and the broadcaster bypass slow mode, not the flood limit).
- Identical text within 20s → `409 conflict`.
- Links blocked when the channel disables them; banned-term list configurable.
- Subscriber-only mode → `403` for non-subscribers.
- Verification requirement belongs to the auth service; the client only displays
  the rejection reason.

**Client-side obligations** (already implemented): optimistic send with
`sending → sent | failed`, inline failure reason, retry, de-duplication by id,
pause/resume with unread count, independent reconnect from playback.

---

## Discovery & search

| Method | Contract |
| --- | --- |
| `GET /api/discovery` → `{ following, recommended, recentlyWatched, categories }` | One call for the sidebar and home rails. |
| `GET /api/search?q=` → `{ channels, categories, streams }` | Debounced at 220ms, minimum 2 characters. |

---

## Community widgets

| Method | Contract | Status in this build |
| --- | --- | --- |
| `GET /api/streams/:id/poll` → `Poll` | Includes `viewerVote`, `canClose`. | Implemented |
| `POST /api/polls/:id/vote` `{ optionId }` | `409` on duplicate or closed; `422` unknown option. | Implemented |
| `POST /api/polls/:id/close`, `POST /api/streams/:id/polls` | Broadcaster only (`403` for moderators). | Implemented |
| `GET /api/streams/:id/prediction` → `Prediction` | `spendEnabled` flag. | Read-only |
| `POST /api/predictions/:id/enter` | Requires the points economy. | **`501 unsupported`** |
| `GET /api/streams/:id/goals` → `StreamGoal[]` | Server filters non-public goals. | Implemented (read-only) |
| `GET /api/streams/:id/leaderboard` → `Leaderboard` | Must apply viewer privacy opt-out. | Implemented |
| `PUT /api/leaderboard/privacy` `{ optOut }` | | Implemented |
| `GET /api/streams/:id/rewards` → `RewardsState` | `balance` may be `null` if not disclosable. | Implemented (read-only) |
| `POST /api/rewards/:id/redeem` | Needs transaction + inventory service. | **`501 unsupported`** |
| `GET /api/streams/:id/alerts` → `SupportAlert[]` | Amounts are **display strings** from the server. | Implemented (read-only) |

**Do not** build a points balance, price, or reward inventory in the client.
`RewardsState.balance` is rendered, never derived; `SupportAlert.amountLabel` is a
string because currency formatting and totals must be server-authoritative.

---

## Content

| Method | Contract |
| --- | --- |
| `GET /api/channels/:id/clips` → `Clip[]` | Empty array is a valid, expected response. |
| `GET /api/channels/:id/vods` → `Vod[]` | Empty array for channels with no public VODs. |
| `POST /api/clips` `{ streamId, startSeconds, endSeconds, title }` → `Clip` | 5–60s, title ≥3 chars, requires a DVR window (`501` otherwise). In production this must enqueue a real transcoding job and return a pending clip. |
| `GET /api/emotes` → `Emote[]` | `subscriberOnly` is enforced at send time, not by hiding the emote. |

---

## Safety

`POST /api/reports` `{ targetType: "stream" | "channel" | "chat_message", targetId, reason, details }` → `{ id }`

Reason is required; details ≤500 chars. Must be rate limited server-side.

---

## What a real deployment must add

1. **Auth** — replace `demoStore.persona`. The session endpoint must derive roles;
   sign-in must not be a client switch (the demo panel is deleted).
2. **CSRF** — required once auth uses cookies. Send a same-site token on all
   mutations, or use `SameSite=Lax` cookies with an origin check.
3. **Rate limiting** — per-user and per-IP, at the edge, not just in handlers.
4. **Playback security** — signed, short-TTL manifest URLs; no keys in the client;
   optional watermarking per viewer.
5. **Chat scale** — a real fan-out (pub/sub) with per-room backpressure; the
   client already caps mounted messages.
6. **Clip pipeline** — transcoding queue, storage, thumbnails, moderation queue.
7. **Economy** — points ledger, idempotent redemption, inventory, cooldowns.
8. **Billing** — subscription tiers and entitlements from a payments provider;
   the UI must consume server prices only.
