import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  // Relative base: the build works from a domain root AND from a project
  // subpath like https://<user>.github.io/<repo>/, with no rebuild needed.
  // Hash routing means there are no server-side rewrite rules to configure.
  base: './',
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 3000,
    // The hosted preview proxies the dev server from a dynamic *.e2b.app host,
    // so the allowlist has to accept any preview origin rather than a fixed one.
    allowedHosts: ['.e2b.app', 'localhost', '127.0.0.1'],
    strictPort: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: ['.e2b.app', 'localhost', '127.0.0.1'],
  },
  build: {
    // keep the initial payload lean; the player and chat are the critical path
    chunkSizeWarningLimit: 700,
  },
})
