# VANTA — premium gaming livestream page

A production-oriented livestream watch page: real video playback with real
renditions, real-time-style chat with server-enforced moderation, channel
identity, discovery, and a documented boundary for every capability this build
does **not** have.

![Watch page at 1440×900](docs/screens/stream-playing-1440.png)

---

## Quick start

```bash
npm install --legacy-peer-deps   # see "Why --legacy-peer-deps" below
npm run dev                      # http://localhost:3000
npm test                         # 54 unit/component tests
npm run typecheck                # strict TypeScript, zero errors
npm run build                    # production bundle
```

Optional: regenerate the demo media (video renditions, captions, artwork):

```bash
python3 -m pip install pillow numpy imageio-ffmpeg
npm run assets
```

> **Why `--legacy-peer-deps`?** The scaffold pins React 19 while some tooling in
> this environment still declares React 18 peers. It is a dependency-resolution
> workaround only; nothing in the app depends on it.

---

## What is actually wired up

| Area | State |
| --- | --- |
| Video playback | **Real.** Three genuine H.264/AAC renditions (720p/480p/360p), poster, WebVTT captions, DVR seeking, looping "live" source. Quality switching reloads the source and preserves the playhead. |
| Player controls | **Real.** Play/pause, mute/volume, quality, captions, PiP, fullscreen, theater, keyboard shortcuts, auto-hide, reconnect with backoff. |
| Chat | **Real** message flow over a mock transport that mirrors a WebSocket (`connect`/`onEvent`/`onStatus`). Send, retry, moderation, pin, clear, timeouts, ban, reconnect with exponential backoff. |
| Moderation | **Enforced in the service layer**, not the UI. A viewer calling `clearChat` gets `403`. |
| Follow + notifications | **Real**, persisted to storage, with conflict detection and rollback on failure. |
| Polls | **Real** vote flow with duplicate + closed-state rejection. |
| Clips | **Real** creation path with DVR validation; new clips appear in the Clips tab. |
| Predictions / rewards | **Deliberately disabled.** The service returns `501 unsupported` because no points economy exists. The UI says so instead of faking it. |
| Subscriptions / payments | **Deliberately disabled.** Tiers are shown read-only; checkout is disabled with an explanation. No prices are invented. |
| Notifications, search | **Real** front-end behaviour over the mock contract (search is debounced, keyboard-navigable). |

Anything marked "deliberately disabled" is a documented integration boundary,
not a claim of completed work — see [docs/API-INTEGRATION.md](docs/API-INTEGRATION.md).

---

## Project layout

```
src/
  api/            service layer — the seam between UI and backend
    demo.ts       demo switches (network profile, persona, forced stream state)
    seed.ts       seeded dataset shaped exactly like the API contract
    mockApi.ts    API implementation: permissions, validation, rate limits
  components/
    player/       PlayerContext (state machine) + VideoPlayer + PlayerControls
    chat/         ChatPanel, ChatMessageRow, ChatComposer
    stream/       StreamHeader, StreamTabs (about/schedule/clips/vods/community)
    discovery/    card components (stream, category, channel row, clip, VOD)
    layout/       AppHeader, Sidebar
    widgets/      poll, prediction, goals, leaderboard, rewards, support alerts
    dialogs/      report, clip, subscribe, shortcuts, demo panel, sign-in
    ui/           primitives: Avatar, Thumb, LiveBadge, EmptyState, Toast, Dialog, Popover
  state/          useAsync, useChat, useDemo, playerBridge
  lib/            utils (formatting, hooks), hash router
  styles/         tokens.css, base.css, layout.css, player.css, chat.css, components.css
  types.ts        the domain contract shared with the future backend
tests/            vitest suites (service rules, rendering, XSS, player defaults)
qa/               Playwright scripts used for the browser verification in the report
tools/            media generator (deterministic, offline)
docs/             architecture, API integration, implementation report, screenshots
```

---

## Documentation

| Document | Contents |
| --- | --- |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Component map, state model, layout system, design tokens, rendering and performance decisions. |
| [docs/API-INTEGRATION.md](docs/API-INTEGRATION.md) | Every endpoint the UI expects, its contract, error codes, and exactly what must be built server-side. |
| [docs/IMPLEMENTATION-REPORT.md](docs/IMPLEMENTATION-REPORT.md) | What was built, the test matrix with measured results, known limitations, and remaining work. |

## Demo controls

The floating **Demo** button switches the session persona (guest → subscriber →
moderator → broadcaster), the network profile (fast / slow / flaky / offline),
the forced stream state (live / offline / scheduled / ended / restricted), and
triggers playback or chat faults.

These switches exist **because** there is no backend in this workspace: they are
how the documented failure paths get exercised. They are removed in a real
deployment.

## Deploy to GitHub Pages

The build is static and uses hash routing, so it drops onto GitHub Pages with no
server configuration. `vite.config.ts` sets `base: './'`, which means the same
build works at `https://<user>.github.io/` **and** at
`https://<user>.github.io/<repo>/` without editing anything. A workflow at
`.github/workflows/deploy.yml` typechecks, tests, builds and publishes on every
push to `main`.

```bash
# 1. push the project
git init && git add . && git commit -m "VANTA"
git branch -M main
git remote add origin git@github.com:<user>/<repo>.git
git push -u origin main
```

Then in the repository: **Settings → Pages → Build and deployment → Source:
"GitHub Actions"**. The workflow runs on the push (or from the Actions tab →
*Deploy to GitHub Pages* → *Run workflow*) and the site appears at
`https://<user>.github.io/<repo>/` in about a minute.

Notes:

- `.nojekyll` is copied into the build so nothing is filtered by Jekyll.
- Assets and `public/media` are resolved through `import.meta.env.BASE_URL`, so
  thumbnails, avatars and the demo renditions load from the project subpath.
- If Pages is instead configured to serve from a branch (`gh-pages`), run
  `npm run build` and publish the `dist/` directory — it is self-contained
  (5.5 MB, mostly the demo video).
- The `og:image` meta tag uses a relative path so it works at either base; for
  rich link previews elsewhere, point it at the absolute deployed URL.

To check the production build locally the way Pages serves it:

```bash
npm run build
python3 -m http.server 8099 --directory dist   # http://localhost:8099/
```

## Accessibility

Verified with axe-core against WCAG 2.1 A/AA: **0 violations** on the watch page
(desktop + mobile) and the home page. Full keyboard operation, visible focus on
every stop, focus trapping and restoration in dialogs, `prefers-reduced-motion`
honoured, and no status conveyed by colour alone.

## Branding

`index.html` carries the product identity: title, description, Open Graph and
Twitter card tags, `theme-color` (#0B0D12), a light/dark `color-scheme`, a
`viewport-fit=cover` viewport for safe-area insets, and a `<noscript>` message.
The document title follows the route (`Browse live channels · VANTA`,
`Following · VANTA`, `<channel> · <title> · VANTA`), so tabs and history entries
are identifiable. `public/favicon.svg` is the VANTA mark and `public/og-card.png`
is the 1200×630 share card (both generated locally, no external requests).

## License / media

All video, audio, artwork, and emote assets are procedurally generated by
`tools/gen_assets.py` for this project. No third-party footage, fonts, or brand
assets are included. The UI font stack falls back to system fonts because the
preview sandbox has no network access.
