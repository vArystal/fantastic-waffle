async (page) => {
  const results = {};
  const runAxe = async (label) => {
    await page.addScriptTag({ path: '/home/user/vanta/node_modules/axe-core/axe.min.js' });
    const r = await page.evaluate(async () => {
      const res = await window.axe.run(document, {
        runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] },
      });
      return res.violations.map((v) => ({
        id: v.id,
        impact: v.impact,
        help: v.help,
        nodes: v.nodes.slice(0, 3).map((n) => ({ target: n.target, summary: (n.failureSummary || '').slice(0, 160) })),
        count: v.nodes.length,
      }));
    });
    results[label] = r;
  };

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2600);
  await runAxe('stream-desktop');

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2400);
  await runAxe('stream-mobile');

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2400);
  await runAxe('home-desktop');

  return JSON.stringify(results, null, 1);
}
