async (page) => {
  const out = {};
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  await page.evaluate(() => localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false })));
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.player', { timeout: 10000 });
  await page.waitForTimeout(1500);
  await page.locator('.player__big-play').click({ force: true });
  await page.waitForTimeout(2600);

  // captions
  await page.mouse.move(600, 400);
  await page.locator('button[aria-label^="Captions"]').click({ force: true });
  await page.waitForTimeout(600);
  out.captions = await page.evaluate(() => {
    const v = document.querySelector('video');
    return { tracks: [...v.textTracks].map((t) => ({ lang: t.language, mode: t.mode })), pressed: document.querySelector('button[aria-label^="Captions"]')?.getAttribute('aria-pressed') };
  });

  // DVR seek through the timeline keyboard handler
  await page.locator('.timeline').focus();
  await page.keyboard.press('Home');
  await page.waitForTimeout(500);
  const atStart = await page.evaluate(() => +document.querySelector('video').currentTime.toFixed(1));
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(600);
  const afterSeek = await page.evaluate(() => +document.querySelector('video').currentTime.toFixed(1));
  out.seek = { atStart, afterSeek };

  // "go live" appears when behind the live edge
  await page.waitForTimeout(900);
  out.goLiveVisible = await page.locator('.live-edge-btn').count();
  if (out.goLiveVisible) {
    await page.locator('.live-edge-btn').click({ force: true });
    await page.waitForTimeout(900);
  }
  out.afterGoLive = await page.evaluate(() => {
    const v = document.querySelector('video');
    return { t: +v.currentTime.toFixed(1), dur: +v.duration.toFixed(1), behind: +(v.duration - v.currentTime).toFixed(1) };
  });

  // picture-in-picture support probe (headless may refuse; we only assert graceful handling)
  await page.mouse.move(600, 400);
  await page.locator('button[aria-label="Picture in picture"]').click({ force: true });
  await page.waitForTimeout(800);
  out.pip = await page.evaluate(() => ({ inPip: !!document.pictureInPictureElement, error: document.querySelector('.player__overlay--error .player__overlay-title')?.textContent ?? null }));

  // interruption → reconnect overlay
  await page.evaluate(() => {
    localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false }));
  });
  return JSON.stringify(out, null, 1);
}
