async (page) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2600);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(400);
  await page.screenshot({ path: '/home/user/shot-mobile.png' });

  await page.evaluate(() => window.scrollTo(0, 420));
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/home/user/shot-mobile-chat.png' });

  await page.locator('.mobile-switcher__tab:has-text("Details")').click({ force: true });
  await page.waitForTimeout(600);
  await page.locator('.tabs__tab:has-text("Community")').click({ force: true });
  await page.waitForTimeout(1800);
  await page.evaluate(() => document.querySelector('.tabs').scrollIntoView());
  await page.waitForTimeout(600);
  await page.screenshot({ path: '/home/user/shot-mobile-community.png' });

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2600);
  await page.screenshot({ path: '/home/user/shot-home.png' });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2600);
  await page.screenshot({ path: '/home/user/shot-desktop-full.png', fullPage: true });
  return 'ok';
}
