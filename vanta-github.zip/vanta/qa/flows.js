async (page) => {
  const out = {};
  const setDemo = (patch) => page.evaluate((p) => {
    const cur = JSON.parse(localStorage.getItem('vanta.demo.v1') || '{}');
    localStorage.setItem('vanta.demo.v1', JSON.stringify({ ...{ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false }, ...cur, ...p }));
  }, patch);

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/brk', { waitUntil: 'load' });
  await setDemo({ persona: 'subscriber' });
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.follow__btn', { timeout: 10000 });
  await page.waitForTimeout(1200);

  // follow → reload → still following (persistent account state)
  const before = await page.locator('.follow__btn').getAttribute('aria-pressed');
  await page.locator('.follow__btn').click({ force: true });
  await page.waitForTimeout(1500);
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.follow__btn');
  await page.waitForTimeout(1200);
  out.followPersistence = { before, afterReload: await page.locator('.follow__btn').getAttribute('aria-pressed') };

  // report dialog: validation + submission
  await page.locator('.stream-head__more').click({ force: true });
  await page.waitForTimeout(400);
  await page.locator('.menu__item:has-text("Report stream")').click({ force: true });
  await page.waitForTimeout(600);
  out.reportDisabledWithoutReason = await page.locator('.dialog__footer .btn--danger').isDisabled();
  await page.locator('.report__option').nth(1).click({ force: true });
  await page.locator('.dialog__body textarea').fill('automated verification run');
  await page.locator('.dialog__footer .btn--danger').click({ force: true });
  await page.waitForTimeout(1400);
  out.reportSubmitted = await page.locator('.toast__title').first().innerText().catch(() => 'none');
  out.dialogClosed = (await page.locator('[role="dialog"][aria-modal="true"]').count()) === 0;

  // clip flow as the broadcaster
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  await setDemo({ persona: 'streamer' });
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.player', { timeout: 10000 });
  await page.waitForTimeout(1500);
  await page.locator('.player__big-play').click({ force: true });
  await page.waitForTimeout(2500);
  await page.locator('.stream-head__more').click({ force: true });
  await page.waitForTimeout(400);
  await page.locator('.menu__item:has-text("Create clip")').click({ force: true });
  await page.waitForTimeout(700);
  out.clip = {
    open: await page.locator('[role="dialog"]').count(),
    playbackPausedOnOpen: await page.evaluate(() => document.querySelector('video')?.paused),
    submitDisabledWithoutTitle: await page.locator('.dialog__footer .btn--primary').isDisabled(),
  };
  await page.locator('.dialog__body input').fill('automated clip');
  await page.locator('.dialog__footer .btn--primary').click({ force: true });
  await page.waitForTimeout(1500);
  out.clip.created = await page.locator('.toast__title').first().innerText().catch(() => 'none');

  // new clip appears in the Clips tab
  await page.locator('.tabs__tab:has-text("Clips")').click({ force: true });
  await page.waitForTimeout(1600);
  out.clip.inTab = await page.locator('.clip-tile__title', { hasText: 'automated clip' }).count();

  // ended stream shows the replay + ended notice
  await page.goto('http://localhost:3000/#/c/velocity', { waitUntil: 'load' });
  await page.waitForTimeout(2200);
  out.ended = {
    replayPill: await page.locator('.live-pill--muted').innerText().catch(() => 'none'),
    hasVideo: await page.locator('video').count(),
    stateChip: await page.locator('.stream-head__meta .chip').first().innerText().catch(() => 'none'),
  };

  // subscribe dialog states billing is unavailable
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  await page.locator('.subscribe-btn').click({ force: true });
  await page.waitForTimeout(600);
  out.subscribe = {
    tiers: await page.locator('.tier').count(),
    checkoutDisabled: await page.locator('.tier .btn').first().isDisabled(),
  };

  await setDemo({ persona: 'subscriber' });
  return JSON.stringify(out, null, 1);
}
