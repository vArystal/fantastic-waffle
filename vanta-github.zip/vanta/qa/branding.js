async () => {
  const res = {};
  await page.goto('http://localhost:3000/', { waitUntil: 'load' });
  await page.waitForSelector('.app__main > *');
  res.homeTitle = await page.title();
  res.favicon = await page.evaluate(() => {
    const l = document.querySelector('link[rel="icon"]');
    return l ? l.getAttribute('href') : null;
  });
  res.faviconStatus = await page.evaluate(async () => {
    const r = await fetch('/favicon.svg'); return r.status;
  });
  res.ogStatus = await page.evaluate(async () => {
    const r = await fetch('/og-card.png'); return r.status + ' ' + (r.headers.get('content-type')||'');
  });
  res.ogTags = await page.evaluate(() =>
    [...document.querySelectorAll('meta[property^="og:"], meta[name="twitter:card"]')]
      .map(m => m.getAttribute('property') || m.getAttribute('name')).join(',')
  );
  res.themeColor = await page.evaluate(() => document.querySelector('meta[name="theme-color"]')?.content);

  await page.goto('http://localhost:3000/#/browse', { waitUntil: 'load' });
  await page.waitForSelector('.app__main > *');
  res.browseTitle = await page.title();

  await page.goto('http://localhost:3000/#/following', { waitUntil: 'load' });
  await page.waitForSelector('.app__main > *');
  res.followingTitle = await page.title();

  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  await page.waitForSelector('.player');
  await page.waitForTimeout(700);
  res.streamTitle = await page.title();

  // nav back to home must reset the title
  await page.goto('http://localhost:3000/', { waitUntil: 'load' });
  await page.waitForSelector('.app__main > *');
  res.homeTitleAgain = await page.title();
  return res;
}