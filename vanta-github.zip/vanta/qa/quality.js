async (page) => {
  const out = {};
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  await page.evaluate(() => localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false })));
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.player', { timeout: 10000 });
  await page.waitForTimeout(1500);

  await page.locator('.player__big-play').click({ force: true });
  await page.waitForTimeout(2500);
  out.before = await page.evaluate(() => {
    const v = document.querySelector('video');
    return { width: v.videoWidth, src: v.currentSrc.split('/').pop(), t: +v.currentTime.toFixed(1) };
  });

  await page.locator('.player__hover-surface').count().catch(() => 0);
  await page.mouse.move(600, 400);
  await page.waitForTimeout(300);
  await page.locator('button[aria-label^="Quality:"]').click({ force: true });
  await page.waitForTimeout(400);
  await page.locator('[role="menuitemradio"]').filter({ hasText: '360p' }).first().click({ force: true });
  await page.waitForTimeout(4000);
  out.after = await page.evaluate(() => {
    const v = document.querySelector('video');
    return {
      width: v.videoWidth,
      src: v.currentSrc.split('/').pop(),
      t: +v.currentTime.toFixed(1),
      paused: v.paused,
      label: document.querySelector('.quality-label')?.textContent,
    };
  });

  // chat send diagnostics
  await page.locator('.composer__input').fill('diagnostic message');
  out.sendState = await page.evaluate(() => {
    const b = document.querySelector('.composer__send');
    return { disabled: b.disabled, value: document.querySelector('.composer__input').value };
  });
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(2000);
  out.chat = await page.evaluate(() => ({
    selfRows: document.querySelectorAll('.chat-row--self').length,
    failed: document.querySelectorAll('.chat-row--failed').length,
    lastText: document.querySelector('.chat-row:last-of-type')?.textContent?.slice(0, 60),
    toast: document.querySelector('.toast__desc')?.textContent ?? null,
    composerValue: document.querySelector('.composer__input').value,
  }));
  return JSON.stringify(out, null, 1);
}
