async (page) => {
  const base = 'http://localhost:3000';
  const reset = { network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false };
  const shot = async (name, w, h, path) => {
    await page.setViewportSize({ width: w, height: h });
    await page.goto(base + path, { waitUntil: 'load' });
    await page.evaluate((r) => localStorage.setItem('vanta.demo.v1', JSON.stringify(r)), reset);
    await page.reload({ waitUntil: 'load' });
    await page.waitForSelector('.app__main > *', { timeout: 12000 });
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(2200);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(300);
    await page.screenshot({ path: `/home/user/vanta/docs/screens/${name}.png` });
  };

  await shot('stream-1440', 1440, 900, '/#/c/v0lt');
  // play so the evidence shows a real frame
  await page.locator('.player__big-play').click({ force: true }).catch(() => {});
  await page.waitForTimeout(2200);
  await page.mouse.move(600, 400);
  await page.waitForTimeout(400);
  await page.screenshot({ path: '/home/user/vanta/docs/screens/stream-playing-1440.png' });

  await shot('stream-1024', 1024, 780, '/#/c/v0lt');
  await shot('tablet-768', 768, 900, '/#/c/v0lt');
  await shot('mobile-390', 390, 844, '/#/c/v0lt');
  await shot('home-1440', 1440, 900, '/#/');
  await shot('browse-1440', 1440, 900, '/#/browse');

  // offline state evidence
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(base + '/#/c/v0lt', { waitUntil: 'load' });
  await page.evaluate(() => localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'offline', chatOffline: false })));
  await page.reload({ waitUntil: 'load' });
  await page.waitForTimeout(2400);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.screenshot({ path: '/home/user/vanta/docs/screens/state-offline.png' });

  // demo panel
  await page.evaluate(() => localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false })));
  await page.reload({ waitUntil: 'load' });
  await page.waitForTimeout(2000);
  await page.locator('.demo-trigger').click({ force: true });
  await page.waitForTimeout(700);
  await page.screenshot({ path: '/home/user/vanta/docs/screens/demo-panel.png' });

  return 'ok';
}
