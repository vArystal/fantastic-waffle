async (page) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2600);
  await page.screenshot({ path: '/home/user/shot-home.png' });
  const hero = await page.evaluate(() => {
    const h = document.querySelector('.hero');
    const art = document.querySelector('.hero__art');
    return { heroH: Math.round(h.getBoundingClientRect().height), artPos: getComputedStyle(art).position, artH: Math.round(art.getBoundingClientRect().height) };
  });
  return JSON.stringify(hero);
}
