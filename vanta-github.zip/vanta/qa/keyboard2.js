async (page) => {
  const log = [];
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  // reset leftover demo switches from earlier runs
  await page.evaluate(() => localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false })));
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.player', { timeout: 10000 });
  await page.waitForTimeout(1800);

  const look = () => page.evaluate(() => {
    const el = document.activeElement;
    if (!el) return { tag: 'none' };
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return {
      label: (el.getAttribute('aria-label') || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 28),
      outline: cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0,
      visible: r.width > 1 && r.height > 1,
    };
  });

  // start from a clean focus position
  await page.evaluate(() => { document.activeElement?.blur?.(); document.body.setAttribute('tabindex', '-1'); document.body.focus(); });
  const order = [];
  for (let i = 0; i < 10; i++) { await page.keyboard.press('Tab'); order.push(await look()); }
  log.push(['tab-order', order]);

  // an invisible focusable control is a defect: none of the stops may be hidden
  log.push(['hidden-focus-stops', order.filter((o) => o.visible === false).length]);

  // volume slider expands when focused
  await page.evaluate(() => { document.activeElement?.blur?.(); document.body.focus(); });
  const vol = page.locator('input[aria-label="Volume"]');
  await page.evaluate(() => {
    const b = document.querySelector('button[aria-label="Unmute"], button[aria-label="Mute"]');
    b?.focus();
  });
  for (let i = 0; i < 3; i++) { await page.keyboard.press('Tab'); if (await page.evaluate(() => document.activeElement?.getAttribute('aria-label') === 'Volume')) break; }
  await page.waitForTimeout(500);
  log.push(['volume-slider-when-focused', await page.evaluate(() => {
    const s = document.querySelector('.volume__slider');
    return {
      exists: !!s,
      hash: location.hash,
      player: !!document.querySelector('.player'),
      width: s ? Math.round(s.getBoundingClientRect().width) : null,
      opacity: s ? getComputedStyle(s).opacity : null,
      focused: document.activeElement?.getAttribute('aria-label'),
    };
  })]);

  // dialog opened from a menu returns focus to a stable control
  await page.evaluate(() => [...document.querySelectorAll('button')].find((b) => b.getAttribute('aria-label') === 'More stream actions')?.click());
  await page.waitForTimeout(400);
  await page.evaluate(() => [...document.querySelectorAll('.menu__item')].find((b) => b.textContent.includes('Report stream'))?.click());
  await page.waitForTimeout(600);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(700);
  log.push(['focus-after-dialog', await page.evaluate(() => ({
    label: document.activeElement?.getAttribute('aria-label'),
    tag: document.activeElement?.tagName,
    cls: document.activeElement?.className,
  }))]);

  // Escape also clears an open popover
  await page.evaluate(() => [...document.querySelectorAll('button')].find((b) => b.getAttribute('aria-label') === 'More stream actions')?.click());
  await page.waitForTimeout(300);
  const before = await page.locator('.popover').count();
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  log.push(['popover-escape', { before, after: await page.locator('.popover').count() }]);

  return JSON.stringify({ log }, null, 1);
}
