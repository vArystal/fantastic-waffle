async (page) => {
  const log = []; const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2200);

  log.push(['layout', await page.evaluate(() => {
    const q = (s) => document.querySelector(s);
    const cs = (s) => q(s) && getComputedStyle(q(s));
    return {
      overflow: document.documentElement.scrollWidth - window.innerWidth,
      bottomNav: cs('.mobile-nav')?.display,
      mobileSwitcher: !!q('.mobile-switcher'),
      sideChat: !!q('.watch__chat'),
      playerW: Math.round(q('.player').getBoundingClientRect().width),
      tabsVisible: cs('.mobile-switcher__tabs')?.position,
      composerMinH: Math.round(q('.composer__row').getBoundingClientRect().height),
      sendBtn: Math.round(q('.composer__send').getBoundingClientRect().height),
    };
  })]);

  // switching to the details tab must not reset playback
  await page.locator('.player__big-play').click({ force: true });
  await page.waitForTimeout(1500);
  const t1 = await page.evaluate(() => document.querySelector('video').currentTime);
  await page.locator('.mobile-switcher__tab:has-text("Details")').click({ force: true });
  await page.waitForTimeout(1200);
  const t2 = await page.evaluate(() => ({ t: document.querySelector('video').currentTime, paused: document.querySelector('video').paused, tabs: !!document.querySelector('.tabs') }));
  log.push(['tab-switch-keeps-playing', { before: +t1.toFixed(2), after: +t2.t.toFixed(2), paused: t2.paused, detailsVisible: t2.tabs }]);

  // chat tab still reachable, composer usable
  await page.locator('.mobile-switcher__tab:has-text("Chat")').click({ force: true });
  await page.waitForTimeout(800);
  await page.locator('.composer__input').click();
  await page.locator('.composer__input').fill('mobile message');
  log.push(['composer-focus', await page.evaluate(() => ({
    activeIsInput: document.activeElement?.className.includes('composer__input'),
    inputFontSize: getComputedStyle(document.querySelector('.composer__input')).fontSize,
  }))]);
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1400);
  log.push(['mobile-send', await page.locator('.chat-row--self').count()]);

  // horizontal overflow through the detail tabs
  for (const tab of ['About', 'Schedule', 'Clips', 'Past broadcasts', 'Community']) {
    await page.locator('.mobile-switcher__tab:has-text("Details")').click({ force: true });
    await page.locator(`.tabs__tab:has-text("${tab}")`).click({ force: true });
    await page.waitForTimeout(700);
    const ov = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    log.push([`overflow-${tab}`, ov]);
  }

  // search from the mobile header
  await page.locator('button[aria-label="Search"]').click({ force: true });
  await page.waitForTimeout(400);
  await page.locator('.header__mobile-search input').fill('neon');
  await page.waitForTimeout(1200);
  log.push(['mobile-search', await page.locator('.search__item').count()]);

  return JSON.stringify({ log, errs: errs.slice(0, 5) }, null, 1);
}
