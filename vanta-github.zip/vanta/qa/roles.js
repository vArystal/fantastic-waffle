async (page) => {
  const log = []; const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  const rec = (k, v) => log.push([k, v]);
  const setPersona = async (p) => {
    await page.evaluate((persona) => {
      localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona, forcedStreamState: 'auto', chatOffline: false }));
    }, p);
    await page.reload({ waitUntil: 'networkidle' });
    await page.waitForTimeout(1800);
  };

  await page.setViewportSize({ width: 1440, height: 900 });

  // ---- guest: composer locked, no moderation, follow requires auth
  await setPersona('guest');
  rec('guest', {
    lockedComposer: await page.locator('.composer--locked').count(),
    modButtons: await page.locator('.chat-row__mod').count(),
    signInBtn: await page.locator('.composer--locked .btn').innerText().catch(() => 'none'),
  });

  // ---- viewer: can chat, cannot moderate
  await setPersona('viewer');
  rec('viewer', {
    lockedComposer: await page.locator('.composer--locked').count(),
    modButtons: await page.locator('.chat-row__mod').count(),
  });

  // ---- moderator: moderation UI appears and the action is accepted
  await setPersona('moderator');
  await page.locator('.chat-row').nth(3).hover();
  const modCount = await page.locator('.chat-row__mod').count();
  let timeoutResult = 'not-run';
  if (modCount) {
    await page.locator('.chat-row__mod button:has-text("Timeout")').first().click({ force: true }).catch(() => {});
    await page.waitForTimeout(400);
    await page.locator('.chat__mod-actions .btn:has-text("Timeout 10m")').click({ force: true }).catch(() => {});
    await page.waitForTimeout(1200);
    timeoutResult = await page.locator('.chat-sys--moderation').last().innerText().catch(() => 'no-notice');
  }
  rec('moderator', { modButtons: modCount, timeout: timeoutResult });

  // ---- streamer: poll close tooling is permitted; picks up clear-chat too
  await setPersona('streamer');
  await page.locator('.chat__tools button[aria-label="Chat options"]').click({ force: true });
  await page.waitForTimeout(400);
  rec('streamer', {
    clearChatItem: await page.locator('.menu__item:has-text("Clear chat")').count(),
  });
  await page.keyboard.press('Escape');

  return JSON.stringify({ log, errs: errs.slice(0, 6) }, null, 1);
}
