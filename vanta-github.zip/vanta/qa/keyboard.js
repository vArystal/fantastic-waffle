async (page) => {
  const log = [];
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);

  // tab order: focus must always be visible and stay inside the document
  const order = [];
  for (let i = 0; i < 12; i++) {
    await page.keyboard.press('Tab');
    order.push(await page.evaluate(() => {
      const el = document.activeElement;
      if (!el) return 'none';
      const cs = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return {
        tag: el.tagName.toLowerCase(),
        label: (el.getAttribute('aria-label') || el.textContent || '').trim().slice(0, 34),
        outline: cs.outlineStyle !== 'none' && cs.outlineWidth !== '0px',
        visible: rect.width > 0 && rect.height > 0,
      };
    }));
  }
  log.push(['tab-order', order]);

  // skip link is the first stop
  await page.evaluate(() => document.body.focus());
  await page.keyboard.press('Tab');
  log.push(['first-focus', await page.evaluate(() => document.activeElement?.className)]);

  // dialog: focus moves in, Escape closes and restores focus
  await page.evaluate(() => {
    const btn = [...document.querySelectorAll('button')].find((b) => b.getAttribute('aria-label') === 'More stream actions');
    btn?.focus();
    btn?.click();
  });
  await page.waitForTimeout(400);
  await page.evaluate(() => {
    const item = [...document.querySelectorAll('.menu__item')].find((b) => b.textContent.includes('Report stream'));
    item?.click();
  });
  await page.waitForTimeout(600);
  const dialogOpen = await page.locator('[role="dialog"][aria-modal="true"]').count();
  const focusInDialog = await page.evaluate(() => !!document.activeElement?.closest('[role="dialog"]'));
  await page.keyboard.press('Escape');
  await page.waitForTimeout(400);
  log.push(['dialog', {
    opened: dialogOpen,
    focusMovedInside: focusInDialog,
    closed: (await page.locator('[role="dialog"][aria-modal="true"]').count()) === 0,
    focusRestored: await page.evaluate(() => document.activeElement?.getAttribute('aria-label')),
  }]);

  // reduced motion honoured
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2200);
  log.push(['reduced-motion', await page.evaluate(() => {
    const dot = document.querySelector('.live-dot');
    const cs = dot && getComputedStyle(dot);
    return { animationDuration: cs?.animationDuration, animationIterationCount: cs?.animationIterationCount };
  })]);

  return JSON.stringify({ log }, null, 1);
}
