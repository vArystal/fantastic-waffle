async (page) => {
  const log = []; const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.waitForTimeout(1500);

  // send a message
  await page.locator('.composer__input').fill('first message from the qa run :pog:');
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1600);
  log.push(['rows-matching-text', await page.locator('.chat-row', { hasText: 'first message from the qa run' }).count()]);
  log.push(['own-row-count', await page.locator('.chat-row--self').count()]);

  // duplicate message must be rejected (rate limit / duplicate detection)
  await page.locator('.composer__input').fill('first message from the qa run :pog:');
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1600);
  log.push(['dupe-toast', await page.locator('.toast__title').first().innerText().catch(() => 'none')]);
  log.push(['failed-rows', await page.locator('.chat-row--failed').count()]);

  // slow mode feedback on a quick second, different message
  await page.locator('.composer__input').fill('second message immediately after');
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1200);
  log.push(['slowmode', await page.locator('.composer__cooldown').innerText().catch(() => 'no-cooldown-shown')]);

  // links must be blocked server-side
  await page.locator('.composer__input').fill('go to https://spam.example for free stuff');
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1400);
  log.push(['link-blocked', await page.locator('.toast__desc').first().innerText().catch(() => 'none')]);

  // theater via keyboard shortcut (controls may have faded)
  await page.evaluate(() => window.dispatchEvent(new KeyboardEvent('keydown', { key: 't', bubbles: true })));
  await page.waitForTimeout(600);
  log.push(['theater', await page.evaluate(() => ({ attr: document.documentElement.dataset.theater, w: Math.round(document.querySelector('.player').getBoundingClientRect().width) }))]);
  await page.evaluate(() => window.dispatchEvent(new KeyboardEvent('keydown', { key: 't', bubbles: true })));

  return JSON.stringify({ log, errs: errs.slice(0, 5) }, null, 1);
}
