async (page) => {
  const log = [];
  const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  const rec = (k, v) => log.push([k, v]);

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'load' });
  await page.evaluate(() => localStorage.setItem('vanta.demo.v1', JSON.stringify({ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false })));
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('.player', { timeout: 10000 });
  await page.waitForTimeout(1800);

  // 1 — playback starts with a real source
  await page.locator('.player__big-play').click({ force: true });
  await page.waitForTimeout(1600);
  rec('playback', await page.evaluate(() => {
    const el = document.querySelector('video');
    return { paused: el.paused, time: +el.currentTime.toFixed(2), duration: +el.duration.toFixed(1), muted: el.muted, videoWidth: el.videoWidth };
  }));

  // 2 — audio is muted until the viewer asks for it
  rec('muted-on-start', await page.evaluate(() => document.querySelector('video').muted));
  await page.locator('button[aria-label="Unmute"]').click({ force: true }).catch(() => {});
  await page.waitForTimeout(250);
  rec('muted-after-unmute', await page.evaluate(() => document.querySelector('video').muted));

  // 3 — quality selector swaps the real rendition
  await page.locator('button[aria-label^="Quality:"]').click({ force: true });
  await page.waitForTimeout(400);
  await page.locator('.menu__item, [role="menuitemradio"]').filter({ hasText: '360p' }).first().click({ force: true });
  await page.waitForTimeout(2200);
  rec('quality', await page.evaluate(() => ({
    src: document.querySelector('video source') && document.querySelector('video source').getAttribute('src'),
    videoWidth: document.querySelector('video').videoWidth,
  })));

  // 4 — emotes decode
  rec('emote-widths', await page.evaluate(() => [...document.querySelectorAll('.chat-emote')].map((i) => i.naturalWidth)));

  // 5 — follow toggle round-trip, double-click guarded
  const fbtn = page.locator('.follow__btn');
  const before = await fbtn.getAttribute('aria-pressed');
  await fbtn.click({ force: true });
  await page.waitForTimeout(1400);
  const after = await fbtn.getAttribute('aria-pressed');
  await fbtn.click({ force: true });
  await page.waitForTimeout(1400);
  const restored = await fbtn.getAttribute('aria-pressed');
  rec('follow', { before, after, restored });

  // 6 — chat send
  await page.locator('.composer__input').fill('testing the composer :pog:');
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1500);
  rec('own-message', await page.locator('.chat-row--self').last().innerText().catch(() => 'none'));

  // 7 — duplicate message rejected by the service layer
  await page.locator('.composer__input').fill('testing the composer :pog:');
  await page.locator('.composer__send').click({ force: true });
  await page.waitForTimeout(1500);
  rec('duplicate-blocked', await page.locator('.composer__status, .toast--error').first().innerText().catch(() => 'no-error-shown'));

  // 8 — poll vote + duplicate guard
  const pollBtn = page.locator('.poll-opt').first();
  await pollBtn.click({ force: true });
  await page.waitForTimeout(1200);
  rec('poll-locked', await pollBtn.isDisabled());

  // 9 — viewer cannot moderate
  rec('viewer-mod-buttons', await page.locator('.chat-row__mod').count());

  // 10 — theater mode hides sidebar and widens the player
  const wBefore = await page.evaluate(() => Math.round(document.querySelector('.player').getBoundingClientRect().width));
  await page.locator('button[aria-label="Theater mode"]').click({ force: true });
  await page.waitForTimeout(700);
  rec('theater', await page.evaluate((wb) => ({
    attr: document.documentElement.dataset.theater,
    playerW: Math.round(document.querySelector('.player').getBoundingClientRect().width),
    before: wb,
  }), wBefore));
  await page.locator('button[aria-label="Theater mode"]').click({ force: true });

  // 11 — keyboard shortcuts
  await page.keyboard.press('m');
  await page.waitForTimeout(200);
  rec('keyboard-m-muted', await page.evaluate(() => document.querySelector('video').muted));
  await page.keyboard.press('k');
  await page.waitForTimeout(500);
  rec('keyboard-k-paused', await page.evaluate(() => document.querySelector('video').paused));

  return JSON.stringify({ log, errs }, null, 1);
}
