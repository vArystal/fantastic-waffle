async (page) => {
  const log = []; const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !m.text().includes('Failed to load resource')) errs.push('console: ' + m.text()); });
  const setDemo = async (patch) => {
    await page.evaluate((p) => {
      const cur = JSON.parse(localStorage.getItem('vanta.demo.v1') || '{}');
      localStorage.setItem('vanta.demo.v1', JSON.stringify({ ...{ network: 'fast', persona: 'subscriber', forcedStreamState: 'auto', chatOffline: false }, ...cur, ...p }));
    }, patch);
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2200);
  };

  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('http://localhost:3000/#/c/v0lt', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);

  for (const state of ['offline', 'scheduled', 'ended', 'restricted']) {
    await setDemo({ forcedStreamState: state });
    log.push([state, await page.evaluate(() => ({
      screen: document.querySelector('.player__screen-title')?.textContent ?? null,
      body: document.querySelector('.player__screen-body')?.textContent?.slice(0, 70) ?? null,
      hasVideo: !!document.querySelector('video'),
      action: document.querySelector('.player__screen-actions .btn')?.textContent ?? null,
    }))]);
  }

  // offline network: the page must show an error state with a retry
  await setDemo({ forcedStreamState: 'auto', network: 'offline' });
  log.push(['network-offline', await page.evaluate(() => ({
    errorTitle: document.querySelector('.empty__title')?.textContent ?? null,
    retry: document.querySelector('.empty__action .btn')?.textContent ?? null,
  }))]);

  // slow network: skeletons, then content
  await setDemo({ forcedStreamState: 'auto', network: 'slow' });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(250);
  log.push(['slow-skeleton', await page.evaluate(() => document.querySelectorAll('.skeleton').length)]);
  await page.waitForTimeout(3500);
  log.push(['slow-resolved', await page.evaluate(() => ({ skeletons: document.querySelectorAll('.skeleton').length, chat: !!document.querySelector('.chat') }))]);

  await setDemo({ network: 'fast' });
  return JSON.stringify({ log, errs: errs.slice(0, 6) }, null, 1);
}
